use super::program::{BlockStatement, RecordParameterField};
use super::{
    dispatch,
    continuation::{ResumeTemplate, TemplateHandle, TemplateNode},
    literal,
    program::{
        Binder, CasePattern, Code, ExecutionRoot, Instruction, Label, NameConsumption, ParameterRole,
        RuntimeProgram, RuntimeUnavailable, SourceSite,
    },
    receiving::{
        CallbackResultSchema, CallbackUseHandle, ExecutionView,
        Observation, Receiving, RootCompSchema, ViewHandle,
    },
};
use std::{
    collections::{HashMap, HashSet},
    sync::Arc,
};
use yu_hir::shadow::{
    LocalSourceCatchPattern, LocalSourceCatchPayloadPattern, LocalSourceCatchValuePattern,
    LocalSourceResolution, SourceAnnotationValue, SourceOperationDeclaration, SourceOperationId,
    SourceOperationResolution,
};
use yu_hir::{DefId, ExpressionRootId, HirParameterId};

/// Explicit source small-step state. Source recursion grows arenas/frames, never
/// the Rust call stack. Environments and cells contain integer arena references,
/// so recursive closures do not construct reference-counted ownership cycles.
pub struct Machine {
    program: Arc<RuntimeProgram>,
    state: State,
    frames: Vec<Frame>,
    values: Vec<RuntimeValue>,
    executables: HashMap<usize, ExecutableValue>,
    environments: Vec<Environment>,
    cells: Vec<Option<ReceivedValue>>,
    execution_roots: Vec<ScheduledRoot>,
    initializing_globals: HashSet<usize>,
    selected: Option<usize>,
    steps: usize,
    next_receiver: usize,
    current_owner: ExecutionOwner,
    invocations: Vec<InvocationDescriptor>,
    resume_templates: Vec<ResumeTemplate>,
    next_handler: usize,
    next_request: usize,
    active_receivers: Vec<usize>,
    continuations: Vec<SavedContinuation>,
    receiving: Receiving,
    executing_views: Vec<ExecutionView>,
    operation_v1_trace: Option<OperationV1Trace>,
    tuple_prefixes: Vec<TuplePrefix>,
    dispatch: dispatch::Machine,
    name_entry_trace: Option<NameEntryCorrespondenceTrace>,
    name_entry_value_entry_attempts: Vec<NameEntryValueEntryAttempt>,
    pending_name_entry: Option<PendingNameEntry>,
    name_entry_return_token: Option<PendingNameEntry>,
    name_entry_return_observations: Vec<NameEntryReturnObservation>,
    pending_name_observation: Option<PendingNameObservation>,
    pending_name_return_observation: Option<CompletedNameObservation>,
    name_entry_name_return_observations: Vec<NameEntryNameReturnObservation>,
    #[cfg(test)]
    hygiene_trace: HygieneTrace,
}

/// Provisional research observation joining an actual lexical Name receipt to
/// the subsequent fresh ValueEntry parameter cell. This record grants no
/// runtime permission and is never read by execution decisions.
#[derive(Clone, Debug)]
pub struct NameEntryCorrespondenceTrace {
    pub invocation: usize,
    pub name_site: SourceSite,
    pub returned_value_origin_site: SourceSite,
    pub source_parameter: HirParameterId,
    pub entry_parameter: HirParameterId,
    pub source_cell: usize,
    pub value: usize,
    pub view: usize,
    pub receipt_index: usize,
    pub cells_before_bind: usize,
    pub bound_cell: usize,
    pub cells_after_bind: usize,
}

/// Per-attempt target evidence, independent of the sticky correspondence trace.
#[derive(Clone, Debug)]
pub struct NameEntryValueEntryAttempt {
    pub invocation: usize,
    pub entry_parameter_ordinal: u32,
    pub value: usize,
    pub view: usize,
    pub cells_before_bind: usize,
    pub bound_cell: usize,
    pub cells_after_bind: usize,
    pub token_receipt_index: Option<usize>,
    pub token_source_parameter_ordinal: Option<u32>,
    pub token_name_site_ordinal: Option<u32>,
    pub token_accepted: bool,
}

#[derive(Clone, Debug)]
pub struct NameEntryReturnObservation {
    pub frame: &'static str,
    pub invocation: Option<usize>,
    pub token_receipt_index: Option<usize>,
    pub token_source_parameter_ordinal: Option<u32>,
    pub token_name_site_ordinal: Option<u32>,
    pub token_value: Option<usize>,
    pub token_view: Option<usize>,
    pub token_cells_before_bind: Option<usize>,
    pub returned_value: usize,
    pub returned_view: usize,
    pub cells_at_return: usize,
}

#[derive(Clone, Debug)]
pub struct NameEntryNameReturnObservation {
    pub resolution: &'static str,
    pub name_site_ordinal: u32,
    pub source_cell: usize,
    pub value: usize,
    pub view: usize,
    pub receipt_index: usize,
    pub cells_before_observe: usize,
    pub return_frame: &'static str,
}

struct PendingNameObservation {
    resolution: &'static str,
    site: SourceSite,
    cell: usize,
}

struct CompletedNameObservation {
    resolution: &'static str,
    site: SourceSite,
    cell: usize,
    value: ValueHandle,
    view: ViewHandle,
    receipt_index: usize,
    cells_before_observe: usize,
}

struct PendingNameEntry {
    invocation: usize,
    site: SourceSite,
    source_parameter: HirParameterId,
    source_cell: usize,
    value: ValueHandle,
    view: ViewHandle,
    cells_before_bind: usize,
    receipt_index: Option<usize>,
}
#[derive(Default)]
struct OperationV1Trace {
    initializer_catch_owner: Option<ExecutionOwner>,
    installed_local_cell: Option<(usize, ValueHandle, usize, ExecutionOwner)>,
    read_local_cell: Option<(usize, ValueHandle, ExecutionOwner)>,
    local_invocation_owner: Option<ExecutionOwner>,
    response_definition_read: Option<(ValueHandle, usize, SourceSite)>,
    selected_closure: Option<(ValueHandle, usize)>,
    applied_response_invocation: Option<(SourceSite, ExecutionOwner)>,
    request_operation_seen: bool,
    callback_operation_seen: bool,
    callback_operation_owner: Option<ExecutionOwner>,
    callback_request_event: Option<usize>,
    callback_request: Option<(usize, SourceSite)>,
    live_handler: Option<(SourceSite, yu_hir::shadow::SourceNodeKey, usize, SourceSite)>,
}

#[cfg(test)]
#[derive(Clone, Debug)]
struct HygieneExecutionEvidence {
    event: usize,
    view: ViewHandle,
    receipt: super::receiving::ReceiptHandle,
    occurrence: usize,
    owner: ExecutionOwner,
    slot: SourceSite,
    formal: Option<HirParameterId>,
}

#[cfg(test)]
#[derive(Clone, Debug)]
struct HygieneSuffixEvidence {
    owners: Vec<ExecutionOwner>,
    handlers: Vec<(usize, ExecutionOwner, SourceSite)>,
    pending_cells: Vec<usize>,
}

/// Test-only records are emitted at the constructor or consumer that owns each
/// identity. The trace never participates in runtime decisions.
#[cfg(test)]
#[derive(Clone, Debug)]
enum HygieneObservation {
    Permission {
        lambda: SourceSite,
        formal: HirParameterId,
        families: Vec<yu_hir::shadow::SourceEffectId>,
    },
    OwnerOpen {
        owner: ExecutionOwner,
        parent: ExecutionOwner,
        call: SourceSite,
        provider: SourceSite,
    },
    OwnerClose {
        owner: ExecutionOwner,
        call: SourceSite,
        provider: SourceSite,
        returned: Option<(ValueHandle, ViewHandle)>,
    },
    CarrierConstructed {
        carrier: ValueHandle,
        owner: ExecutionOwner,
        source: SourceSite,
    },
    CallbackEntry {
        entry: super::receiving::CallbackEntryHandle,
        owner: ExecutionOwner,
        lambda: SourceSite,
        formal: HirParameterId,
        incoming: ViewHandle,
        view: ViewHandle,
        formal_receipt: super::receiving::ReceiptHandle,
    },
    NameReceipt {
        owner: ExecutionOwner,
        name: SourceSite,
        formal: HirParameterId,
        view: ViewHandle,
        receipt: super::receiving::ReceiptHandle,
    },
    CallbackUse {
        entry: super::receiving::CallbackEntryHandle,
        use_handle: CallbackUseHandle,
        owner: ExecutionOwner,
        name: SourceSite,
        apply: SourceSite,
        formal: HirParameterId,
        name_view: ViewHandle,
        result_view: ViewHandle,
        formal_receipt: super::receiving::ReceiptHandle,
        name_receipt: super::receiving::ReceiptHandle,
        use_receipt: super::receiving::ReceiptHandle,
    },
    CallbackExecution {
        use_handle: CallbackUseHandle,
        owner: ExecutionOwner,
        apply: SourceSite,
        result_view: ViewHandle,
        result_receipt: super::receiving::ReceiptHandle,
        occurrence: usize,
    },
    Request {
        event: usize,
        owner: ExecutionOwner,
        source: SourceSite,
        carrier: ValueHandle,
        operation: SourceOperationId,
        payload: ValueHandle,
        payload_view: ViewHandle,
        callback_use: Option<CallbackUseHandle>,
        executions: Vec<HygieneExecutionEvidence>,
        continuation: Option<TemplateHandle>,
    },
    CatchCandidate {
        event: usize,
        request_owner: ExecutionOwner,
        owner: ExecutionOwner,
        handler_occurrence: usize,
        handler: SourceSite,
        arm: yu_hir::shadow::SourceNodeKey,
        arm_range: std::ops::Range<usize>,
        operation: SourceOperationId,
        payload: ValueHandle,
    },
    CatchCommit {
        event: usize,
        request_owner: ExecutionOwner,
        owner: ExecutionOwner,
        handler_occurrence: usize,
        handler: SourceSite,
        arm: yu_hir::shadow::SourceNodeKey,
        arm_range: std::ops::Range<usize>,
        operation: SourceOperationId,
        payload: ValueHandle,
        callback_use: Option<CallbackUseHandle>,
        lifetime: HygieneLifetime,
        result: Option<(ValueHandle, ViewHandle)>,
        continuation: Option<TemplateHandle>,
        retirement: Option<Vec<usize>>,
    },
    ContinuationCapture {
        template: TemplateHandle,
        event: usize,
        request_owner: ExecutionOwner,
        operation: SourceOperationId,
        source: SourceSite,
        containing: ExecutionOwner,
        suffix: HygieneSuffixEvidence,
    },
    ContinuationApply {
        template: TemplateHandle,
        owner: ExecutionOwner,
        parent: ExecutionOwner,
        call: SourceSite,
        provider: SourceSite,
    },
    ContinuationResponse {
        template: TemplateHandle,
        owner: ExecutionOwner,
        source: SourceSite,
        value: ValueHandle,
        view: ViewHandle,
    },
    ContinuationClose {
        template: TemplateHandle,
        owner: ExecutionOwner,
        returned: ValueHandle,
        view: ViewHandle,
    },
    ShallowRetirement {
        event: usize,
        request_owner: ExecutionOwner,
        handler_owner: ExecutionOwner,
        handler_occurrence: usize,
        suffix: HygieneSuffixEvidence,
        pending_before: Vec<usize>,
        retired_cells: Vec<usize>,
        pending_after: Vec<usize>,
    },
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum HygieneLifetime {
    CapturedContinuation,
    ShallowDiscard,
}

#[cfg(test)]
#[derive(Clone, Debug)]
struct HygieneRecord {
    ordinal: usize,
    transition: HygieneObservation,
}

#[cfg(test)]
#[derive(Clone, Default)]
struct HygieneTrace {
    observations: Vec<HygieneRecord>,
    active_continuations: Vec<(TemplateHandle, ExecutionOwner)>,
    active_catches: Vec<(usize, usize)>,
}

#[cfg(test)]
impl HygieneTrace {
    fn record(&mut self, transition: HygieneObservation) -> usize {
        let ordinal = self.observations.len();
        self.observations.push(HygieneRecord { ordinal, transition });
        ordinal
    }

    fn valid_ordinals(&self) -> bool {
        self.observations.iter().enumerate().all(|(i, record)| record.ordinal == i)
    }

    fn site_eq(left: &SourceSite, right: &SourceSite) -> bool {
        left.source_root == right.source_root && left.occurrence == right.occurrence && left.range == right.range
    }

    fn invocation(owner: ExecutionOwner) -> Option<usize> {
        match owner { ExecutionOwner::Invocation(id) => Some(id), ExecutionOwner::ModuleRun => None }
    }

    fn request_owner(&self, event: usize) -> Option<ExecutionOwner> {
        self.observations.iter().find_map(|record| match &record.transition {
            HygieneObservation::Request { event: seen, owner, .. } if *seen == event => Some(*owner),
            _ => None,
        })
    }

    fn callback_use(&self, event: usize) -> Option<CallbackUseHandle> {
        self.observations.iter().find_map(|record| match &record.transition {
            HygieneObservation::Request { event: seen, callback_use, .. } if *seen == event => *callback_use,
            _ => None,
        })
    }

    fn suffix_evidence(suffix: &[SavedFrame]) -> HygieneSuffixEvidence {
        let mut evidence = HygieneSuffixEvidence { owners: Vec::new(), handlers: Vec::new(), pending_cells: Vec::new() };
        for frame in suffix {
            match frame {
                SavedFrame::AmbientBoundary => evidence.owners.push(ExecutionOwner::ModuleRun),
                SavedFrame::ReceiverBoundary { original_activation } =>
                    evidence.owners.push(ExecutionOwner::Invocation(*original_activation)),
                SavedFrame::HandlerBoundary { handler, installation, .. } => {
                    evidence.handlers.push((installation.occurrence, installation.owner, handler.site.clone()));
                    evidence.owners.push(installation.owner);
                }
                SavedFrame::Ordinary(Frame::GlobalRead { cell, .. } | Frame::Root { cell, .. }) =>
                    evidence.pending_cells.push(*cell),
                _ => {}
            }
        }
        evidence.pending_cells.sort_unstable();
        evidence.pending_cells.dedup();
        evidence
    }

    fn request_carrier_construction(
        &self,
        request_owner: ExecutionOwner,
        source: &SourceSite,
        carrier: ValueHandle,
        request_ordinal: usize,
    ) -> bool {
        let Some((constructed, owner)) = self.observations.iter().enumerate().find_map(|(i, r)| match &r.transition {
            HygieneObservation::CarrierConstructed { carrier: seen, owner, source: site }
                if *seen == carrier && Self::site_eq(site, source) => Some((i, *owner)),
            _ => None,
        }) else { return false; };
        let opened = self.observations.iter().enumerate().find_map(|(i, r)| match &r.transition {
            HygieneObservation::OwnerOpen { owner: opened, parent, call, provider }
                if *opened == owner && *parent == request_owner && Self::site_eq(call, source) =>
                    Some((i, provider)),
            _ => None,
        });
        let Some((open_ordinal, provider)) = opened else { return false; };
        if Self::invocation(owner).is_none() || open_ordinal >= constructed || constructed >= request_ordinal { return false; }
        self.observations.iter().enumerate().any(|(i, r)| matches!(&r.transition,
            HygieneObservation::OwnerClose { owner: closed, call, provider: closed_provider, returned: Some((value, _)) }
                if *closed == owner && Self::site_eq(call, source) && *value == carrier
                    && Self::site_eq(provider, closed_provider)
                    && constructed < i && i < request_ordinal))
    }

    fn validate_callback_route(&self) -> Result<(), &'static str> {
        use HygieneObservation as H;
        if !self.valid_ordinals() { return Err("observation ordinal mismatch"); }
        let unique = |count: usize| if count == 1 { Ok(()) } else { Err("missing or duplicate transition") };
        let mut permission = Vec::new(); let mut entry = Vec::new(); let mut name = Vec::new();
        let mut use_record = Vec::new(); let mut execution = Vec::new(); let mut request = Vec::new();
        let mut candidate = Vec::new(); let mut commit = Vec::new(); let mut retirement = Vec::new();
        let mut owner_open = Vec::new();
        for (i, record) in self.observations.iter().enumerate() {
            match &record.transition {
                H::Permission { .. } => permission.push((i, record)),
                H::CallbackEntry { .. } => entry.push((i, record)),
                H::NameReceipt { .. } => name.push((i, record)),
                H::CallbackUse { .. } => use_record.push((i, record)),
                H::CallbackExecution { .. } => execution.push((i, record)),
                H::Request { callback_use: Some(_), .. } => request.push((i, record)),
                H::CatchCandidate { .. } => candidate.push((i, record)),
                H::CatchCommit { callback_use: Some(_), .. } => commit.push((i, record)),
                H::ShallowRetirement { .. } => retirement.push((i, record)),
                H::OwnerOpen { .. } => owner_open.push((i, record)),
                _ => {}
            }
        }
        for count in [permission.len(), entry.len(), name.len(), use_record.len(), execution.len(), request.len(),
            candidate.len(), commit.len(), retirement.len()] { unique(count)?; }
        let pi = permission[0].0;
        let ei = entry[0].0;
        let ni = name[0].0;
        let ui = use_record[0].0;
        let xi = execution[0].0;
        let ri = request[0].0;
        let ci = candidate[0].0;
        let ki = commit[0].0;
        let di = retirement[0].0;
        let H::Permission { lambda, formal, families } = &permission[0].1.transition else { unreachable!() };
        let H::CallbackEntry { entry: entry_id, owner, lambda: entry_lambda, formal: entry_formal,
            incoming, view, formal_receipt } = &entry[0].1.transition else { unreachable!() };
        let H::NameReceipt { owner: name_owner, name: name_site, formal: name_formal,
            view: name_view, receipt: name_receipt } = &name[0].1.transition else { unreachable!() };
        let H::CallbackUse { entry: use_entry, use_handle, owner: use_owner, name: use_name,
            apply, formal: use_formal, name_view: use_view, result_view, formal_receipt: use_formal_receipt,
            name_receipt: use_name_receipt, use_receipt } = &use_record[0].1.transition else { unreachable!() };
        let H::CallbackExecution { use_handle: executed_use, owner: execution_owner,
            apply: executed_apply, result_view: executed_view, result_receipt, occurrence } = &execution[0].1.transition else { unreachable!() };
        let H::Request { event, owner: request_owner, source: request_source, carrier, operation, payload,
            callback_use, executions, continuation, .. } = &request[0].1.transition else { unreachable!() };
        let H::CatchCandidate { event: candidate_event, request_owner: candidate_request_owner,
            owner: candidate_owner, handler_occurrence: candidate_handler_id, handler: candidate_handler,
            arm: candidate_arm, arm_range: candidate_range, operation: candidate_operation, payload: candidate_payload }
            = &candidate[0].1.transition else { unreachable!() };
        let H::CatchCommit { event: catch_event, request_owner: catch_request_owner, owner: catch_owner,
            handler_occurrence: catch_handler_id, handler: catch_handler, arm: catch_arm, arm_range: catch_range,
            operation: catch_operation, payload: catch_payload, callback_use: catch_use, lifetime, result,
            continuation: catch_continuation, retirement: catch_retired } = &commit[0].1.transition else { unreachable!() };
        let H::ShallowRetirement { event: retired_event, request_owner: retired_request_owner,
            handler_owner: retired_owner, handler_occurrence: retired_handler_id, suffix, pending_before,
            retired_cells, pending_after } = &retirement[0].1.transition else { unreachable!() };
        let ExecutionOwner::Invocation(invocation) = *owner else { return Err("ModuleRun callback owner"); };
        if lambda.source_root != entry_lambda.source_root || lambda.occurrence != entry_lambda.occurrence
            || lambda.range != entry_lambda.range || formal != entry_formal || families.is_empty()
        { return Err("schema/permission mismatch"); }
        if incoming == view || name_owner != owner || name_formal != formal || name_view != view
            || use_owner != owner || use_formal != formal || use_entry != entry_id || use_view != view
            || use_formal_receipt != formal_receipt || use_name_receipt != name_receipt
            || use_receipt == formal_receipt || use_receipt == name_receipt
            || !Self::site_eq(name_site, use_name)
        { return Err("callback entry/Name/use identity mismatch"); }
        if execution_owner != owner || executed_use != use_handle || !Self::site_eq(executed_apply, apply)
            || executed_view != result_view || result_receipt != use_receipt
        { return Err("callback result-view/receipt mismatch"); }
        if callback_use != &Some(*use_handle) || *request_owner != *owner || !Self::site_eq(request_source, apply)
            || !self.request_carrier_construction(*request_owner, request_source, *carrier, ri)
            || !families.contains(&operation.family)
            || candidate_event != event || catch_event != event || candidate_request_owner != request_owner
            || catch_request_owner != request_owner || candidate_owner != owner || catch_owner != owner
            || candidate_handler_id != catch_handler_id || !Self::site_eq(candidate_handler, catch_handler)
            || candidate_operation != operation || catch_operation != operation
            || candidate_payload != payload || catch_payload != payload
            || candidate_arm != catch_arm || candidate_range != catch_range || catch_use != &Some(*use_handle)
            || catch_continuation != continuation
        { return Err("request/Catch typed provenance mismatch"); }
        let executions_match = executions.iter().any(|e| e.event == *event && e.view == *executed_view
            && e.receipt == *result_receipt && e.occurrence == *occurrence && e.owner == *owner
            && Self::site_eq(&e.slot, apply) && e.formal.is_none());
        if !executions_match { return Err("actual request lacks callback result-view evidence"); }
        let matched_close = self.observations.iter().enumerate().find_map(|(i, r)| match &r.transition {
            H::OwnerClose { owner: closed, call, provider, returned: Some((value, view)) }
                if *closed == *owner && i > ki => Some((i, call, provider, value, view)),
            _ => None,
        }).ok_or("callback invocation did not close with a normal result")?;
        let (oi, open) = owner_open.iter().find_map(|(i, r)| match &r.transition {
            H::OwnerOpen { owner: opened, call, provider, .. } if opened == owner => Some((*i, (call, provider))), _ => None,
        }).ok_or("callback owner constructor missing")?;
        if matched_close.0 <= ki || oi >= ei || !Self::site_eq(matched_close.1, open.0)
            || !Self::site_eq(matched_close.2, open.1) || result != &Some((*matched_close.3, *matched_close.4))
        { return Err("Catch result does not flow through normal owner closure"); }
        let expected_retired: Vec<_> = pending_before.iter().copied()
            .filter(|cell| !pending_after.contains(cell)).collect();
        if lifetime != &HygieneLifetime::ShallowDiscard || catch_retired != &Some(retired_cells.clone())
            || retired_event != event || retired_request_owner != request_owner || retired_owner != owner
            || retired_handler_id != catch_handler_id || !retired_cells.iter().all(|cell| suffix.pending_cells.contains(cell))
            || retired_cells != &expected_retired
        { return Err("shallow retirement evidence mismatch"); }
        if !(pi < ei && ei < ni && ni < ui && ui < xi && xi < ri && ri < ci && ci < ki && ki < di && di < matched_close.0)
            || request_source.source_root != apply.source_root
        { return Err("owner transition order/source mismatch"); }
        let _ = invocation;
        Ok(())
    }

    fn validate_companion_route(
        &self,
        signal: &SourceOperationId,
        write: &SourceOperationId,
    ) -> Result<(), &'static str> {
        use HygieneObservation as H;
        if !self.valid_ordinals() { return Err("observation ordinal mismatch"); }
        let requests: Vec<_> = self.observations.iter().enumerate().filter_map(|(i, r)| match &r.transition {
            H::Request { event, owner, source, carrier, operation, payload, payload_view, continuation, .. }
                if operation == signal || operation == write => Some((i,*event,*owner,source,operation,payload,*continuation,*carrier,*payload_view)),
            _ => None,
        }).collect();
        if requests.iter().filter(|r| r.4 == signal).count() != 1
            || requests.iter().filter(|r| r.4 == write).count() != 1
        { return Err("source-anchored signal/write request is missing or duplicated"); }
        let signal_req = requests.iter().find(|r| r.4 == signal).ok_or("signal request missing")?;
        let write_req = requests.iter().find(|r| r.4 == write).ok_or("retained write request missing")?;
        if signal_req.1 == write_req.1 || signal_req.2 == ExecutionOwner::ModuleRun
            || write_req.2 == ExecutionOwner::ModuleRun || signal_req.0 >= write_req.0
            || signal_req.3.source_root != write_req.3.source_root
        { return Err("companion request owner/event/source mismatch"); }
        let signal_commit = self.observations.iter().enumerate().find_map(|(i,r)| match &r.transition {
            H::CatchCommit { event, request_owner, owner, handler_occurrence, handler, arm, arm_range,
                operation, payload, lifetime, continuation, .. } if *event == signal_req.1 =>
                Some((i,*request_owner,*owner,*handler_occurrence,handler,arm,arm_range,operation,payload,*lifetime,*continuation)),
            _ => None,
        }).ok_or("inner signal Catch commit missing")?;
        let write_commit = self.observations.iter().enumerate().find_map(|(i,r)| match &r.transition {
            H::CatchCommit { event, request_owner, owner, handler_occurrence, handler, arm, arm_range,
                operation, payload, lifetime, result, .. } if *event == write_req.1 =>
                Some((i,*request_owner,*owner,*handler_occurrence,handler,arm,arm_range,operation,payload,*lifetime,result)),
            _ => None,
        }).ok_or("outer write receive commit missing")?;
        let signal_candidate = self.observations.iter().any(|r| matches!(&r.transition,
            H::CatchCandidate { event, request_owner, owner, handler_occurrence, handler, arm, arm_range,
                operation, payload } if *event == signal_req.1 && *request_owner == signal_req.2
                && *owner == signal_commit.2 && *handler_occurrence == signal_commit.3
                && Self::site_eq(handler, signal_commit.4) && arm == signal_commit.5
                && arm_range == signal_commit.6 && operation == signal_req.4 && payload == signal_req.5));
        let write_candidate = self.observations.iter().any(|r| matches!(&r.transition,
            H::CatchCandidate { event, request_owner, owner, handler_occurrence, handler, arm, arm_range,
                operation, payload } if *event == write_req.1 && *request_owner == write_req.2
                && *owner == write_commit.2 && *handler_occurrence == write_commit.3
                && Self::site_eq(handler, write_commit.4) && arm == write_commit.5
                && arm_range == write_commit.6 && operation == write_req.4 && payload == write_req.5));
        if !signal_candidate || !write_candidate || signal_commit.7 != signal
            || write_commit.7 != write || signal_commit.8 != signal_req.5 || write_commit.8 != write_req.5
            || signal_commit.1 != signal_req.2 || write_commit.1 != write_req.2
            || signal_commit.4.source_root != write_commit.4.source_root
            || signal_commit.4.occurrence == write_commit.4.occurrence
            || signal_commit.2 == write_commit.2
            || signal_commit.9 != HygieneLifetime::CapturedContinuation
            || signal_commit.10.is_none()
            || write_commit.9 != HygieneLifetime::ShallowDiscard
            || write_commit.10.is_none()
            || signal_req.0 >= signal_commit.0 || signal_commit.0 >= write_req.0 || write_req.0 >= write_commit.0
        { return Err("inner signal to retained write provenance mismatch"); }
        let template = signal_commit.10.unwrap();
        if write_req.6 != Some(template) { return Err("retained write did not execute under the captured continuation"); }
        let capture = self.observations.iter().enumerate().find_map(|(i,r)| match &r.transition {
            H::ContinuationCapture { template: seen, event, request_owner, operation, source, containing, suffix }
                if *seen == template && *event == signal_req.1 && *request_owner == signal_req.2
                    && operation == signal => Some((i, source, *containing, suffix)),
            _ => None,
        });
        let apply = self.observations.iter().enumerate().find_map(|(i,r)| match &r.transition {
            H::ContinuationApply { template: seen, owner, parent, call, provider }
                if *seen == template && *owner == write_req.2
                    && *parent == signal_commit.2 && signal_commit.0 < i && i < write_req.0 =>
                    Some((i, *owner, *parent, call, provider)),
            _ => None,
        });
        let (capture_ordinal, capture_source, containing_owner, captured_suffix) =
            capture.ok_or("signal continuation capture provenance missing")?;
        let (apply_ordinal, apply_owner, apply_parent, apply_call, apply_provider) =
            apply.ok_or("typed continuation application missing")?;
        let signal_carrier = self.request_carrier_construction(signal_req.2,
            signal_req.3, signal_req.7, signal_req.0);
        let write_carrier = self.request_carrier_construction(write_req.2,
            write_req.3, write_req.7, write_req.0);
        let response = self.observations.iter().enumerate().find_map(|(i,r)| match &r.transition {
            H::ContinuationResponse { template: seen, owner, source, value, view }
                if *seen == template && *owner == apply_owner
                    && Self::site_eq(source, apply_call) && *value == *write_req.5
                    && apply_ordinal < i && i < write_req.0 => Some((i, *view)),
            _ => None,
        });
        if !signal_carrier || !write_carrier || apply_parent != signal_commit.2
            || !Self::site_eq(capture_source, signal_req.3)
            || containing_owner != signal_commit.2
            || !captured_suffix.owners.contains(&write_commit.2)
            || apply_provider.source_root != capture_source.source_root
            || capture_ordinal >= signal_commit.0
            || !response.is_some_and(|(_, view)| view == write_req.8)
        { return Err("continuation capture/apply/response is not linked to the retained write invocation"); }
        let write_result = write_commit.10.expect("validated above");
        let normal_close = self.observations.iter().enumerate().find_map(|(i, r)| match &r.transition {
            H::OwnerClose { owner, returned: Some((value, view)), .. }
                if *owner == write_commit.2 && *value == write_result.0 && *view == write_result.1
                    && write_commit.0 < i => Some(i),
            _ => None,
        });
        if normal_close.is_none() { return Err("outer write Catch result did not close its owning invocation"); }
        if self.observations.iter().any(|r| matches!(&r.transition,
            H::ShallowRetirement { event, .. } if *event == signal_req.1))
        { return Err("inner signal retired before continuation write"); }
        let _ = (signal_commit.1, write_commit.1, requests);
        Ok(())
    }
}

/// Resolved machine plan: only definitions index cache cells.
#[derive(Clone)]
enum ScheduledRoot {
    Definition(usize),
    Expression { root: ExpressionRootId, code: Label },
}
// Execution ownership is distinct from receiving-boundary authority. The
// ambient module span never aliases invocation ordinal zero or grants a profile.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash)]
pub(super) enum ExecutionOwner {
    ModuleRun,
    Invocation(usize),
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) struct HandlerInstallation {
    occurrence: usize,
    owner: ExecutionOwner,
}
#[derive(Clone)]
pub(super) struct InvocationDescriptor {
    call: SourceSite,
    provider: SourceSite,
    active: bool,
}
impl InvocationDescriptor {
    pub(super) fn is_active(&self) -> bool {
        self.active
    }
    #[cfg(test)]
    pub(super) fn active_for_test(site: SourceSite) -> Self {
        Self {
            call: site.clone(),
            provider: site,
            active: true,
        }
    }
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ValueHandle(usize);
#[cfg(test)]
impl ValueHandle { fn hygiene_next(self) -> Self { Self(self.0 + 1) } }
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ContinuationHandle(usize);
#[derive(Clone, Debug)]
pub struct RuntimeValue {
    pub source: SourceSite,
    pub kind: RuntimeValueKind,
}
#[derive(Clone, Debug)]
pub enum RuntimeValueKind {
    Unit,
    Integer(Box<str>),
    Boolean(bool),
    String(Box<str>),
    Primitive(yu_hir::shadow::PinnedPrimitiveOp),
    Tuple(Vec<TupleElement>),
    Variant { tag: Box<str>, payloads: Vec<TupleElement> },
    Record(Vec<(Box<str>, TupleElement)>),
    Closure,
    Computation,
    Operation(SourceOperationResolution),
}
/// One evaluated structural element, including the exact source receiving view.
/// The view remains private so callers cannot forge runtime evidence.
#[derive(Clone, Copy, Debug)]
pub struct TupleElement {
    received: ReceivedValue,
}
impl TupleElement {
    pub fn value(&self) -> ValueHandle {
        self.received.value
    }
}
#[derive(Clone, Debug)]
pub enum RuntimeOutcome {
    /// A whole-module schedule with no executable source completes without
    /// manufacturing a value or a source occurrence for an import statement.
    EmptyModuleCompleted,
    Running,
    Completed(ValueHandle),
    UnhandledRequest {
        source: SourceSite,
        operation: SourceOperationId,
        event: usize,
        payload: ValueHandle,
        continuation: ContinuationHandle,
    },
    Unavailable(RuntimeUnavailable),
    ResourceExhausted {
        steps: usize,
    },
}
// The actual value remains distinct from the source interface under which a
// receiver holds it. Later complete-view evidence belongs on ReceivedValue,
// rather than mutating a shared closure or inferring protection from its tag.
#[derive(Clone, Copy, Debug)]
pub(super) struct ReceivedValue {
    value: ValueHandle,
    interface: ParameterRole,
    view: ViewHandle,
    dispatch: Option<usize>,
}
struct TuplePrefix {
    previous: Option<usize>,
    received: ReceivedValue,
}
struct Environment {
    parent: Option<usize>,
    binder: Option<(Binder, usize)>,
    dispatch: dispatch::State,
}
#[derive(Clone)]
enum ExecutableValue {
    Continuation(TemplateHandle),
    Closure {
        parameter: HirParameterId,
        unit_pattern: bool,
        record_pattern: Option<Arc<[RecordParameterField]>>,
        role: ParameterRole,
        root_schema: Option<Arc<RootCompSchema>>,
        callback_schema: Option<Arc<CallbackResultSchema>>,
        body: Label,
        environment: usize,
    },
    Delay {
        code: Label,
        environment: usize,
    },
    Request {
        declaration: Arc<SourceOperationDeclaration>,
        payload: ReceivedValue,
        source: SourceSite,
    },
    Primitive {
        operation: yu_hir::shadow::PinnedPrimitiveOp,
        arguments: Vec<ValueHandle>,
    },
}
enum State {
    Evaluate {
        code: Label,
        environment: usize,
    },
    Return(ReceivedValue),
    EnterTemplate {
        template: TemplateHandle,
        node: usize,
        control: HashMap<usize, usize>,
        response: ReceivedValue,
    },
    Request(PendingRequest),
    IntegerProduct {
        product: super::decimal::Product,
        site: SourceSite,
    },
    Stopped(RuntimeOutcome),
}
#[derive(Clone)]
pub(super) enum Frame {
    ResumeArgument {
        template: TemplateHandle,
        source: SourceSite,
    },
    ResumeReturn,
    OwnerReturn {
        owner: ExecutionOwner,
        owned: bool,
        previous: ExecutionOwner,
    },
    RootCompReturn {
        execution: ExecutionView,
    },
    CatchReturn {
        handler: Arc<Code>,
        environment: usize,
        installation: HandlerInstallation,
    },
    OperationPayload {
        declaration: Arc<SourceOperationDeclaration>,
        source: SourceSite,
    },
    OperationResultConsumer {
        source: SourceSite,
        callback_use: Option<CallbackUseHandle>,
    },
    DiscardToUnit {
        site: SourceSite,
    },
    Callee {
        callee: Option<Label>,
        argument: Label,
        environment: usize,
        site: SourceSite,
    },
    PrimitiveArgument {
        operation: yu_hir::shadow::PinnedPrimitiveOp,
        arguments: Vec<ValueHandle>,
        site: SourceSite,
    },
    ReceiverReturn {
        activation: usize,
        previous: ExecutionOwner,
    },
    ValueEntry {
        parameter: HirParameterId,
        callback_schema: Option<Arc<CallbackResultSchema>>,
        entry_receiver: usize,
        unit_pattern: bool,
        record_pattern: Option<Arc<[RecordParameterField]>>,
        body: Label,
        environment: usize,
    },
    RecordDefault {
        fields: Arc<[RecordParameterField]>,
        index: usize,
        argument: ReceivedValue,
        body: Label,
        environment: usize,
    },
    Local {
        block: Arc<Code>,
        next: usize,
        environment: usize,
        cell: usize,
        recursive: bool,
    },
    Condition {
        conditional: Arc<Code>,
        arm: usize,
        environment: usize,
    },
    BlockExpression {
        block: Arc<Code>,
        next: usize,
        environment: usize,
    },
    Sequence {
        sequence: Arc<Code>,
        next: usize,
        environment: usize,
    },
    Record {
        record: Arc<Code>,
        next: usize,
        environment: usize,
        prefix: Option<usize>,
    },
    Tuple {
        tuple: Arc<Code>,
        next: usize,
        environment: usize,
        prefix: Option<usize>,
    },
    Case {
        case: Arc<Code>,
        environment: usize,
    },
    Root {
        next: usize,
        cell: usize,
    },
    ExpressionReturn {
        root: ExpressionRootId,
        next: usize,
    },
    GlobalRead {
        cell: usize,
        consumption: NameConsumption,
        site: SourceSite,
        environment: usize,
    },
}

struct PendingRequest {
    declaration: Arc<SourceOperationDeclaration>,
    payload: ReceivedValue,
    source: SourceSite,
    event: usize,
    observations: Vec<Observation>,
    suffix: Vec<SavedFrame>,
}
struct SavedContinuation {
    frames: Vec<SavedFrame>,
    template: Option<TemplateHandle>,
    resumed: bool,
    #[allow(
        dead_code,
        reason = "unhandled request observations retained for a future external response consumer"
    )]
    observations: Vec<Observation>,
}
// Capture retains original lineage; template entry resolves a live occurrence
// afresh and never reactivates a historical ID.
enum SavedFrame {
    AmbientBoundary,
    ReceiverBoundary {
        original_activation: usize,
    },
    HandlerBoundary {
        handler: Arc<Code>,
        environment: usize,
        installation: HandlerInstallation,
    },
    Ordinary(Frame),
}

impl RuntimeProgram {
    /// Starts from the original source-order schedule retained by this program.
    pub(crate) fn start_source_schedule(
        self: &Arc<Self>,
        definition: &DefId,
    ) -> Result<Machine, RuntimeUnavailable> {
        self.start(definition, &self.source_schedule)
    }

    pub(crate) fn start_module_schedule(self: &Arc<Self>) -> Result<Machine, RuntimeUnavailable> {
        self.start_with_schedule(None, &self.source_schedule)
    }

    /// The source interface owner supplies computation roots in source order.
    /// Value definitions materialize at first access. Successful definition
    /// materialization is cached; executing a delayed argument is never cached.
    pub fn start(
        self: &Arc<Self>,
        definition: &DefId,
        execution_roots: &[ExecutionRoot],
    ) -> Result<Machine, RuntimeUnavailable> {
        let selected = *self
            .definition_indices
            .get(definition)
            .ok_or(RuntimeUnavailable::MissingDefinition)?;
        self.start_with_schedule(Some(selected), execution_roots)
    }

    fn start_with_schedule(
        self: &Arc<Self>,
        selected: Option<usize>,
        execution_roots: &[ExecutionRoot],
    ) -> Result<Machine, RuntimeUnavailable> {
        let mut seen_definitions = HashSet::new();
        let mut seen_expressions = HashSet::new();
        let mut roots = Vec::new();
        for root in execution_roots {
            match root {
                ExecutionRoot::Definition(id) => {
                    let index = *self
                        .definition_indices
                        .get(id)
                        .ok_or(RuntimeUnavailable::MissingDefinition)?;
                    if !seen_definitions.insert(index) {
                        return Err(RuntimeUnavailable::ModuleInitializationOrder);
                    }
                    roots.push(ScheduledRoot::Definition(index));
                }
                ExecutionRoot::Expression(expression) => {
                    let root = &expression.root;
                    let Some(code) = self.expression_roots.get(root) else {
                        return Err(RuntimeUnavailable::InvalidSourceReference);
                    };
                    if code.0 != expression.code || !self._hir.owns_expression_root(root) {
                        return Err(RuntimeUnavailable::InvalidSourceReference);
                    }
                    if !seen_expressions.insert(root.clone()) {
                        return Err(RuntimeUnavailable::ModuleInitializationOrder);
                    }
                    roots.push(ScheduledRoot::Expression {
                        root: root.clone(),
                        code: *code,
                    });
                }
            }
        }
        let mut machine = Machine {
            program: self.clone(),
            state: State::Stopped(RuntimeOutcome::Running),
            frames: Vec::new(),
            values: Vec::new(),
            executables: HashMap::new(),
            environments: vec![Environment {
                parent: None,
                binder: None,
                dispatch: dispatch::State::default(),
            }],
            cells: vec![None; self.definitions.len()],
            execution_roots: roots,
            initializing_globals: HashSet::new(),
            selected,
            steps: 0,
            next_receiver: 0,
            current_owner: ExecutionOwner::ModuleRun,
            invocations: Vec::new(),
            resume_templates: Vec::new(),
            next_handler: 0,
            next_request: 0,
            active_receivers: Vec::new(),
            continuations: Vec::new(),
            receiving: Receiving::default(),
            executing_views: Vec::new(),
            operation_v1_trace: self.operation_v1.as_ref().map(|_| OperationV1Trace::default()),
            tuple_prefixes: Vec::new(),
            dispatch: dispatch::Machine::default(),
            name_entry_trace: None,
            name_entry_value_entry_attempts: Vec::new(),
            pending_name_entry: None,
            name_entry_return_token: None,
            name_entry_return_observations: Vec::new(),
            pending_name_observation: None,
            pending_name_return_observation: None,
            name_entry_name_return_observations: Vec::new(),
            #[cfg(test)]
            hygiene_trace: HygieneTrace::default(),
        };
        machine.begin_root(0);
        Ok(machine)
    }
}

impl Machine {
    /// Return the provisional source trace, if this run actually joined one
    /// lexical Name/Observe receipt to a fresh ValueEntry parameter bind.
    pub fn name_entry_correspondence(&self) -> Option<&NameEntryCorrespondenceTrace> {
        self.name_entry_trace.as_ref()
    }

    pub fn name_entry_value_entry_attempts(&self) -> Vec<String> {
        self.name_entry_value_entry_attempts.iter().map(|event| format!(
            "invocation={} entry_parameter={} value={} view={} cells_before_bind={} bound_cell={} cells_after_bind={} token_receipt={:?} token_source_parameter={:?} token_name_site={:?} token_accepted={}",
            event.invocation, event.entry_parameter_ordinal, event.value, event.view,
            event.cells_before_bind, event.bound_cell, event.cells_after_bind,
            event.token_receipt_index, event.token_source_parameter_ordinal,
            event.token_name_site_ordinal, event.token_accepted
        )).collect()
    }

    pub fn name_entry_return_observations(&self) -> Vec<String> {
        self.name_entry_return_observations.iter().map(|event| format!(
            "frame={} invocation={:?} token_receipt={:?} token_source_parameter={:?} token_name_site={:?} token_value={:?} token_view={:?} token_cells_before_bind={:?} returned_value={} returned_view={} cells_at_return={}",
            event.frame, event.invocation, event.token_receipt_index,
            event.token_source_parameter_ordinal, event.token_name_site_ordinal,
            event.token_value, event.token_view, event.token_cells_before_bind,
            event.returned_value, event.returned_view, event.cells_at_return
        )).collect()
    }

    pub fn name_entry_name_return_observations(&self) -> Vec<String> {
        self.name_entry_name_return_observations.iter().map(|event| format!(
            "resolution={} name_site={} source_cell={} value={} view={} receipt={} cells_before_observe={} return_frame={}",
            event.resolution, event.name_site_ordinal, event.source_cell, event.value,
            event.view, event.receipt_index, event.cells_before_observe, event.return_frame
        )).collect()
    }

    /// Mint the dynamic receipt after an actual completed run, never from a
    /// partial, exhausted, unhandled, unavailable, or mismatched execution.
    pub fn operation_v1_runtime_receipt(
        &self,
        completed: ValueHandle,
    ) -> Option<crate::OperationV1RuntimeReceipt> {
        let RuntimeOutcome::Completed(handle) = self.state_outcome()? else { return None; };
        if *handle != completed { return None; }
        let value = self.value(completed)?;
        if !matches!(&value.kind, RuntimeValueKind::Integer(text) if text.as_ref() == "42") {
            return None;
        }
        let plan = self.program.operation_v1.as_ref()?;
        let trace = self.operation_v1_trace.as_ref()?;
        if let Some(lineage) = &plan.local_lineage {
            let (local_cell, local_value, local_environment, install_owner) =
                trace.installed_local_cell?;
            let (read_cell, read_value, read_owner) = trace.read_local_cell?;
            let local_invocation_owner = trace.local_invocation_owner?;
            if trace.initializer_catch_owner != Some(install_owner)
                || local_cell != read_cell
                || local_value != read_value
                || install_owner != read_owner
                || !matches!(local_invocation_owner,
                    ExecutionOwner::Invocation(id)
                        if self.invocations.get(id).is_some_and(|invocation|
                            invocation.call.occurrence == lineage.apply.occurrence
                                && !invocation.active))
                || trace.callback_operation_owner != Some(local_invocation_owner)
                || self.executables.get(&local_value.0).is_none_or(|executable| {
                    !matches!(executable,
                        ExecutableValue::Closure { environment, .. }
                            if *environment == local_environment)
                })
            {
                return None;
            }
        }
        let (response_argument_value, response_argument_environment, response_argument_read_source) =
            trace.response_definition_read.clone()?;
        let (response_handle, captured_environment) = trace.selected_closure?;
        if response_argument_value != response_handle
            || response_argument_read_source.occurrence != plan.response_argument.occurrence
            || trace.applied_response_invocation.as_ref().is_none_or(|(site, owner)| {
                site.occurrence != plan.response_invocation_apply.occurrence
                    || site.source_root != plan.response_invocation_apply.source_root
                    || Some(*owner) != trace.callback_operation_owner
            })
            || !trace.callback_operation_seen
        {
            return None;
        }
        let (live_handler_source, selected_arm, callback_request_event, callback_request_source) =
            trace.live_handler.clone()?;
        if trace.callback_request_event != Some(callback_request_event)
            || callback_request_source.occurrence != plan.link.callback_apply
        {
            return None;
        }
        let expected_handler = plan.expected_outer_handler.as_ref()?;
        let expected_arm = plan.expected_outer_arm.as_ref()?;
        if live_handler_source.occurrence != expected_handler.occurrence
            || &selected_arm != expected_arm
            || self.value(response_handle)?.source.occurrence != plan.response_lambda.occurrence
        {
            return None;
        }
        Some(crate::OperationV1RuntimeReceipt {
            field_bound_id: plan.link.field_bound_id,
            request: plan.link.request.clone(),
            callback_apply: plan.link.callback_apply.clone(),
            callback_operation: plan.link.callback_operation.clone(),
            callback_operation_use: plan.link.callback_operation_use.clone(),
            response_definition: plan.link.response_definition.clone(),
            continuation_apply_source: plan.continuation_apply.clone(),
            response_argument_source: plan.response_argument.clone(),
            response_argument_read_source,
            response_argument_environment,
            response_closure_source: self.value(response_handle)?.source.clone(),
            response_closure_handle: response_handle.0,
            captured_environment,
            callback_request_event,
            callback_request_source,
            live_handler_source,
            selected_arm,
            result: "42".into(),
        })
    }

    fn state_outcome(&self) -> Option<&RuntimeOutcome> {
        match &self.state {
            State::Stopped(outcome) => Some(outcome),
            _ => None,
        }
    }
    pub fn value(&self, handle: ValueHandle) -> Option<&RuntimeValue> {
        self.values.get(handle.0)
    }
    pub fn continuation_depth(&self, handle: ContinuationHandle) -> Option<usize> {
        self.continuations
            .get(handle.0)
            .map(|saved| saved.frames.len())
    }
    pub fn steps(&self) -> usize {
        self.steps
    }

    /// A depleted caller budget pauses the live private machine. It never
    /// publishes a partial value as a completed evaluation and can be resumed.
    pub fn run(&mut self, step_budget: usize) -> RuntimeOutcome {
        for _ in 0..step_budget {
            let outcome = self.step();
            if !matches!(outcome, RuntimeOutcome::Running) {
                return outcome;
            }
        }
        match &self.state {
            State::Stopped(outcome) => outcome.clone(),
            _ => RuntimeOutcome::ResourceExhausted { steps: self.steps },
        }
    }

    pub(crate) fn resume_host_write(
        &mut self,
        continuation: ContinuationHandle,
        operation: &SourceOperationId,
    ) -> Result<Box<str>, RuntimeUnavailable> {
        let (current_continuation, current_operation, payload, source) = match &self.state {
            State::Stopped(RuntimeOutcome::UnhandledRequest {
                source,
                operation,
                payload,
                continuation,
                ..
            }) => (*continuation, operation, *payload, source.clone()),
            _ => return Err(RuntimeUnavailable::InvalidSourceReference),
        };
        if current_continuation != continuation
            || current_operation != operation
            || self.program.host_write_operation() != Some(operation)
        {
            return Err(RuntimeUnavailable::HostWriteResponse(source));
        }
        let saved = self.continuations.get(continuation.0)
            .ok_or(RuntimeUnavailable::HostWriteResponse(source.clone()))?;
        if saved.resumed {
            return Err(RuntimeUnavailable::HostWriteResponse(source));
        }
        let template = saved.template
            .ok_or(RuntimeUnavailable::HostWriteResponse(source.clone()))?;
        let resume = self.resume_templates.get(template.0)
            .ok_or(RuntimeUnavailable::HostWriteResponse(source.clone()))?;
        if !self.program.host_write_declaration_matches(&resume.declaration)
            || !matches!(self.values.get(payload.0).map(|value| &value.kind),
                Some(RuntimeValueKind::String(_)))
        {
            return Err(RuntimeUnavailable::HostWriteResponse(source));
        }
        let captured = match &self.values[payload.0].kind {
            RuntimeValueKind::String(text) => text.clone(),
            _ => unreachable!("the payload kind was checked above"),
        };
        let template_root = resume.root;
        self.continuations[continuation.0].resumed = true;
        let response_value = self.allocate(&source, RuntimeValueKind::Unit, None);
        let response = ReceivedValue {
            dispatch: None,
            value: response_value,
            interface: ParameterRole::Value,
            view: self.receiving.ground(response_value),
        };
        self.frames.push(Frame::ResumeReturn);
        self.state = State::EnterTemplate {
            template,
            node: template_root,
            control: HashMap::new(),
            response,
        };
        Ok(captured)
    }

    pub fn step(&mut self) -> RuntimeOutcome {
        if let State::Stopped(outcome) = &self.state {
            return outcome.clone();
        }
        self.steps = self.steps.saturating_add(1);
        let state = std::mem::replace(&mut self.state, State::Stopped(RuntimeOutcome::Running));
        let result = match state {
            State::Evaluate { code, environment } => self.evaluate(code, environment),
            State::Return(value) => self.return_value(value),
            State::EnterTemplate {
                template,
                node,
                control,
                response,
            } => self.enter_template(template, node, control, response),
            State::Request(request) => self.propagate_request(request),
            State::IntegerProduct { product, site } => self.advance_integer_product(product, site),
            State::Stopped(_) => unreachable!(),
        };
        if let Err(error) = result {
            self.pending_name_entry = None;
            self.name_entry_return_token = None;
            self.pending_name_observation = None;
            self.pending_name_return_observation = None;
            self.state = State::Stopped(RuntimeOutcome::Unavailable(error));
        }
        match &self.state {
            State::Stopped(outcome) => outcome.clone(),
            _ => RuntimeOutcome::Running,
        }
    }

    fn evaluate(&mut self, label: Label, environment: usize) -> Result<(), RuntimeUnavailable> {
        let code = self
            .program
            .code
            .get(label.0)
            .cloned()
            .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
        let site = &code.site;
        match &code.instruction {
            Instruction::Unit => self.ground_data(site, RuntimeValueKind::Unit, None),
            Instruction::Integer(text) => self.ground_data(
                site,
                RuntimeValueKind::Integer(
                    literal::integer(text)
                        .ok_or_else(|| RuntimeUnavailable::LiteralDecoding(site.clone()))?,
                ),
                None,
            ),
            Instruction::Boolean(value) => {
                self.ground_data(site, RuntimeValueKind::Boolean(*value), None)
            }
            Instruction::String(text) => self.ground_data(
                site,
                RuntimeValueKind::String(
                    literal::string(text)
                        .ok_or_else(|| RuntimeUnavailable::LiteralDecoding(site.clone()))?,
                ),
                None,
            ),
            Instruction::DecodedString(text) => self.ground_data(site, RuntimeValueKind::String(text.clone()), None),
            Instruction::Primitive(operation) => self.data(
                site,
                RuntimeValueKind::Primitive(operation.clone()),
                Some(ExecutableValue::Primitive { operation: operation.clone(), arguments: Vec::new() }),
            ),
            Instruction::Record { fields } => {
                if let Some((_, first)) = fields.first() {
                    let first = *first;
                    self.frames.push(Frame::Record { record: code, next: 1, environment, prefix: None });
                    self.state = State::Evaluate { code: first, environment };
                } else {
                    self.data(site, RuntimeValueKind::Record(Vec::new()), None);
                }
            }
            Instruction::Tuple { elements } | Instruction::Variant { payloads: elements, .. } => {
                if let Some(first) = elements.first().copied() {
                    self.frames.push(Frame::Tuple {
                        tuple: code,
                        next: 1,
                        environment,
                        prefix: None,
                    });
                    self.state = State::Evaluate { code: first, environment };
                } else {
                    let value = match &code.instruction {
                        Instruction::Variant { tag, .. } => RuntimeValueKind::Variant { tag: tag.clone(), payloads: Vec::new() },
                        _ => RuntimeValueKind::Tuple(Vec::new()),
                    };
                    self.data(site, value, None);
                }
            }
            Instruction::FieldTail { receiver, .. } if self.program.dictionaries.is_some() => {
                let word = self.dispatch.word(self.environments[environment].dispatch)?;
                let key = dispatch::Site { owner: site.source_root.clone(), occurrence: site.occurrence.clone() };
                let callee = *self.program.dictionaries.as_ref().unwrap().get(&(word, key.clone()))
                    .ok_or_else(|| RuntimeUnavailable::UnsupportedFieldTail(site.clone()))?;
                let entered = self.dispatch_environment(environment, dispatch::Step { kind: dispatch::Kind::Member, site: key })?;
                self.frames.push(Frame::Callee { callee: None, argument: *receiver, environment, site: site.clone() });
                self.state = State::Evaluate { code: callee, environment: entered };
            }
            Instruction::FieldTail { .. } => {
                // Only exact candidate-retained abstract constraints survive
                // construction. Execution requires a concrete selection; no
                // runtime value tag supplies a missing dictionary.
                return Err(RuntimeUnavailable::UnsupportedFieldTail(site.clone()));
            }
            Instruction::OperatorApplication { left, right, key } if self.program.dictionaries.is_some() => {
                let callee = *self.program.operator_bodies.get(key).ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                let entered = self.dispatch_environment(environment, dispatch::Step {
                    kind: dispatch::Kind::Operator,
                    site: dispatch::Site { owner: site.source_root.clone(), occurrence: site.occurrence.clone() },
                })?;
                if let Some(right) = right { self.frames.push(Frame::Callee { callee: None, argument: *right, environment, site: site.clone() }); }
                self.frames.push(Frame::Callee { callee: None, argument: *left, environment, site: site.clone() });
                self.state = State::Evaluate { code: callee, environment: entered };
            }
            Instruction::OperatorApplication { .. } => {
                return Err(RuntimeUnavailable::InvalidSourceReference);
            }
            Instruction::Forward(inner) => {
                self.state = State::Evaluate {
                    code: *inner,
                    environment,
                }
            }
            Instruction::Name {
                resolution,
                consumption,
            } => {
                let cell = match resolution {
                    LocalSourceResolution::ModuleDef(id) => {
                        self.program.definition_indices.get(id).copied()
                    }
                    LocalSourceResolution::Parameter(id) => {
                        self.lookup(environment, |binder| {
                            matches!(binder, Binder::Parameter(candidate) if candidate == id)
                        })
                    }
                    LocalSourceResolution::Local(id) => {
                        self.lookup(environment, |binder| {
                            matches!(binder, Binder::Local(candidate) if candidate == id)
                        })
                    }
                    LocalSourceResolution::CatchBinder(id) => {
                        self.lookup(environment, |binder| {
                            matches!(binder, Binder::Catch(candidate) if candidate == id)
                        })
                    }
                    LocalSourceResolution::CaseBinder(id) => {
                        self.lookup(environment, |binder| {
                            matches!(binder, Binder::Catch(candidate) if candidate == id)
                        })
                    }
                    LocalSourceResolution::Imported(_)
                    | LocalSourceResolution::Unresolved
                    | LocalSourceResolution::Ambiguous => None,
                }
                .ok_or_else(|| RuntimeUnavailable::MissingBinding(site.clone()))?;
                if let Some(received) = self.cells[cell] {
                    let execution_owner = self.current_execution_owner();
                    if *consumption == NameConsumption::Observe {
                        let resolution_kind = match resolution {
                            LocalSourceResolution::Parameter(_) => "Parameter",
                            LocalSourceResolution::Local(_) => "Local",
                            _ => "Other",
                        };
                        self.pending_name_observation = Some(PendingNameObservation {
                            resolution: resolution_kind,
                            site: site.clone(),
                            cell,
                        });
                        if let (LocalSourceResolution::Parameter(parameter),
                            ExecutionOwner::Invocation(invocation)) = (resolution, execution_owner)
                        {
                            self.pending_name_entry = Some(PendingNameEntry {
                                invocation,
                                site: site.clone(),
                                source_parameter: parameter.clone(),
                                source_cell: cell,
                                value: received.value,
                                view: received.view,
                                cells_before_bind: self.cells.len(),
                                receipt_index: None,
                            });
                        }
                    }
                    if let (Some(plan), Some(trace)) =
                        (&self.program.operation_v1, &mut self.operation_v1_trace)
                    {
                        if plan.local_lineage.as_ref().is_some_and(|lineage|
                            site.occurrence == lineage.name_use.occurrence)
                            && matches!(resolution,
                                LocalSourceResolution::Local(id)
                                    if plan.local_lineage.as_ref().is_some_and(|lineage|
                                        id == &lineage.binding))
                        {
                            trace.read_local_cell = Some((
                                cell,
                                received.value,
                                execution_owner,
                            ));
                        }
                        if site.occurrence == plan.response_argument.occurrence
                            && matches!(resolution,
                                LocalSourceResolution::Local(id)
                                    if id == &plan.link.response_definition)
                        {
                            trace.response_definition_read =
                                Some((received.value, environment, site.clone()));
                        }
                    }
                    let received = self.dispatch_name(received, cell, environment, site)?;
                    let formal = match resolution {
                        LocalSourceResolution::Parameter(formal) => Some(formal),
                        _ => None,
                    };
                    self.consume(received, *consumption, site, formal)?;
                } else if matches!(resolution, LocalSourceResolution::ModuleDef(_)) {
                    if !self.initializing_globals.insert(cell) {
                        return Err(RuntimeUnavailable::RecursiveDefinitionInitialization(
                            site.clone(),
                        ));
                    }
                    self.frames.push(Frame::GlobalRead {
                        cell,
                        consumption: *consumption,
                        site: site.clone(),
                        environment,
                    });
                    let environment = self.initializer_environment(cell, 0)?;
                    self.state = State::Evaluate {
                        code: self.program.definitions[cell].body,
                        environment,
                    };
                } else {
                    return Err(RuntimeUnavailable::UninitializedBinding(site.clone()));
                }
            }
            Instruction::Lambda {
                parameter,
                unit_pattern,
                record_pattern,
                role,
                root_schema,
                callback_schema,
                body,
            } => {
                self.data(
                    site,
                    RuntimeValueKind::Closure,
                    Some(ExecutableValue::Closure {
                        parameter: parameter.clone(),
                        unit_pattern: *unit_pattern,
                        record_pattern: record_pattern.clone(),
                        role: *role,
                        root_schema: root_schema.clone(),
                        callback_schema: callback_schema.clone(),
                        body: *body,
                        environment,
                    }),
                );
            }
            Instruction::Apply { callee, argument } => {
                self.frames.push(Frame::Callee {
                    callee: Some(*callee),
                    argument: *argument,
                    environment,
                    site: site.clone(),
                });
                self.state = State::Evaluate {
                    code: *callee,
                    environment,
                };
            }
            Instruction::Block { .. } | Instruction::StatementBlock { .. } => self.begin_local(code, 0, environment)?,
            Instruction::Sequence { items } => {
                let Some(first) = items.first().copied() else {
                    return Err(RuntimeUnavailable::InvalidSourceReference);
                };
                self.frames.push(Frame::Sequence { sequence: code, next: 1, environment });
                self.state = State::Evaluate { code: first, environment };
            }
            Instruction::If { arms, else_branch } => {
                if let Some((test, _)) = arms.first() {
                    let test = *test;
                    self.frames.push(Frame::Condition {
                        conditional: code,
                        arm: 0,
                        environment,
                    });
                    self.state = State::Evaluate {
                        code: test,
                        environment,
                    };
                } else if let Some(branch) = else_branch {
                    self.state = State::Evaluate {
                        code: *branch,
                        environment,
                    };
                } else {
                    self.ground_data(site, RuntimeValueKind::Unit, None);
                }
            }
            Instruction::Case { scrutinee, .. } => {
                self.frames.push(Frame::Case {
                    case: code.clone(),
                    environment,
                });
                self.state = State::Evaluate {
                    code: *scrutinee,
                    environment,
                };
            }
            Instruction::Operation(resolution) => {
                let execution_owner = self.current_execution_owner();
                if let (Some(plan), Some(trace)) =
                    (&self.program.operation_v1, &mut self.operation_v1_trace)
                {
                    if site.occurrence == plan.request.occurrence
                        && matches!(resolution, SourceOperationResolution::Resolved(declaration)
                            if declaration.id == plan.request_operation)
                    {
                        trace.request_operation_seen = true;
                    }
                    if site.occurrence == plan.callback_operation.occurrence
                        && trace.applied_response_invocation.as_ref().is_some_and(|(apply, owner)| {
                            apply.occurrence == plan.response_invocation_apply.occurrence
                                && apply.source_root == plan.response_invocation_apply.source_root
                                && *owner == execution_owner
                        })
                        && matches!(resolution, SourceOperationResolution::Resolved(declaration)
                            if declaration.id == plan.link.callback_operation)
                    {
                        trace.callback_operation_seen = true;
                        trace.callback_operation_owner = Some(execution_owner);
                    }
                }
                self.data(site, RuntimeValueKind::Operation(resolution.clone()), None)
            }
            Instruction::Catch { scrutinee, .. } => {
                let scrutinee = *scrutinee;
                let execution_owner = self.current_execution_owner();
                if let (Some(plan), Some(trace)) =
                    (&self.program.operation_v1, &mut self.operation_v1_trace)
                {
                    if plan.local_lineage.as_ref().is_some_and(|lineage|
                        site.occurrence == lineage.initializer_catch.occurrence
                            && site.source_root == lineage.initializer_catch.source_root)
                    {
                        trace.initializer_catch_owner = Some(execution_owner);
                    }
                }
                let occurrence = self.next_handler;
                self.next_handler = occurrence
                    .checked_add(1)
                    .ok_or(RuntimeUnavailable::IdentityExhausted)?;
                let installation = HandlerInstallation {
                    occurrence,
                    owner: self.current_execution_owner(),
                };
                self.frames.push(Frame::CatchReturn {
                    handler: code,
                    environment,
                    installation,
                });
                self.state = State::Evaluate {
                    code: scrutinee,
                    environment,
                };
            }
        }
        Ok(())
    }

    fn return_value(&mut self, received: ReceivedValue) -> Result<(), RuntimeUnavailable> {
        #[cfg(test)]
        if self.hygiene_trace.active_catches.last().is_some_and(|(_, depth)| *depth == self.frames.len()) {
            let (index, _) = self.hygiene_trace.active_catches.pop().unwrap();
            if let Some(HygieneRecord { transition: HygieneObservation::CatchCommit { result, .. }, .. }) =
                self.hygiene_trace.observations.get_mut(index)
            {
                *result = Some((received.value, received.view));
            }
        }
        // The token belongs only to this one return consumer. Taking it before
        // inspecting the frame prevents it crossing Sequence/Condition/etc.
        let return_token = self.name_entry_return_token.take();
        let returned_name = self.pending_name_return_observation.take();
        let Some(frame) = self.frames.pop() else {
            self.state = State::Stopped(RuntimeOutcome::Completed(received.value));
            return Ok(());
        };
        let (frame_kind, frame_invocation) = match &frame {
            Frame::ValueEntry { entry_receiver, .. } => ("ValueEntry", Some(*entry_receiver)),
            Frame::Sequence { .. } => ("Sequence", None),
            Frame::Condition { .. } => ("Condition", None),
            Frame::BlockExpression { .. } => ("BlockExpression", None),
            _ => ("Other", None),
        };
        self.name_entry_return_observations.push(NameEntryReturnObservation {
            frame: frame_kind,
            invocation: frame_invocation,
            token_receipt_index: return_token.as_ref().and_then(|p| p.receipt_index),
            token_source_parameter_ordinal: return_token.as_ref().map(|p| p.source_parameter.ordinal()),
            token_name_site_ordinal: return_token.as_ref().map(|p| p.site.occurrence.ordinal()),
            token_value: return_token.as_ref().map(|p| p.value.0),
            token_view: return_token.as_ref().map(|p| p.view.index()),
            token_cells_before_bind: return_token.as_ref().map(|p| p.cells_before_bind),
            returned_value: received.value.0,
            returned_view: received.view.index(),
            cells_at_return: self.cells.len(),
        });
        if let Some(observed) = returned_name {
            self.name_entry_name_return_observations.push(NameEntryNameReturnObservation {
                resolution: observed.resolution,
                name_site_ordinal: observed.site.occurrence.ordinal(),
                source_cell: observed.cell,
                value: observed.value.0,
                view: observed.view.index(),
                receipt_index: observed.receipt_index,
                cells_before_observe: observed.cells_before_observe,
                return_frame: frame_kind,
            });
        }
        match frame {
            Frame::ResumeArgument { template, source } => {
                if let (Some(plan), Some(trace)) =
                    (&self.program.operation_v1, &mut self.operation_v1_trace)
                {
                    let exact_definition_read = trace.response_definition_read.as_ref()
                        .is_some_and(|(value, _, read_site)| {
                            *value == received.value
                                && read_site.occurrence == plan.response_argument.occurrence
                        });
                    if received.value.0 < self.values.len()
                        && self.values[received.value.0].source.occurrence
                            == plan.response_lambda.occurrence
                        && source.occurrence == plan.continuation_apply.occurrence
                        && exact_definition_read
                    {
                        if let Some(ExecutableValue::Closure { environment, .. }) =
                            self.executables.get(&received.value.0)
                        {
                            trace.selected_closure = Some((received.value, *environment));
                        }
                    }
                }
                let SourceAnnotationValue::Function { result, .. } = &self
                    .resume_templates
                    .get(template.0)
                    .ok_or(RuntimeUnavailable::InvalidSourceReference)?
                    .declaration
                    .signature
                    .value
                else {
                    return Err(RuntimeUnavailable::ContinuationResponse(source));
                };
                let exact_v1_function_response = matches!(
                    &result.value,
                    SourceAnnotationValue::Function { .. }
                ) && self.program.operation_v1.as_ref().is_some_and(|plan| {
                    received.interface == ParameterRole::Value
                        && self.receiving.matches_value(received.view, received.value)
                        && source.occurrence == plan.continuation_apply.occurrence
                        && self.operation_v1_trace.as_ref().is_some_and(|trace| {
                            trace.response_definition_read.as_ref().is_some_and(
                                |(value, _, read_site)| {
                                    *value == received.value
                                        && read_site.occurrence == plan.response_argument.occurrence
                                },
                            )
                        })
                        && self.values.get(received.value.0).is_some_and(|value| {
                            value.source.occurrence == plan.response_lambda.occurrence
                                && value.source.source_root == plan.response_lambda.source_root
                        })
                        && matches!(self.executables.get(&received.value.0),
                            Some(ExecutableValue::Closure { .. }))
                });
                if !self.primitive_matches(&result.value, received)
                    && !exact_v1_function_response
                {
                    return Err(RuntimeUnavailable::ContinuationResponse(source));
                }
                #[cfg(test)]
                self.hygiene_trace.record(HygieneObservation::ContinuationResponse {
                    template,
                    owner: self.current_execution_owner(),
                    source: source.clone(),
                    value: received.value,
                    view: received.view,
                });
                self.frames.push(Frame::ResumeReturn);
                let node = self
                    .resume_templates
                    .get(template.0)
                    .ok_or(RuntimeUnavailable::InvalidSourceReference)?
                    .root;
                self.state = State::EnterTemplate {
                    template,
                    node,
                    control: HashMap::new(),
                    response: received,
                };
            }
            Frame::ResumeReturn => {
                #[cfg(test)]
                if let Some((template, owner)) = self.hygiene_trace.active_continuations.pop() {
                    self.hygiene_trace.record(HygieneObservation::ContinuationClose {
                        template,
                        owner,
                        returned: received.value,
                        view: received.view,
                    });
                }
                self.state = State::Return(received)
            }
            Frame::OwnerReturn {
                owner,
                owned,
                previous,
            } => {
                self.leave_owner(owner, owned, previous)?;
                #[cfg(test)]
                if let ExecutionOwner::Invocation(_) = owner {
                    let descriptor = match owner {
                        ExecutionOwner::Invocation(id) => self.invocations.get(id),
                        ExecutionOwner::ModuleRun => None,
                    }.ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                    self.hygiene_trace.record(HygieneObservation::OwnerClose {
                        owner,
                        call: descriptor.call.clone(),
                        provider: descriptor.provider.clone(),
                        returned: Some((received.value, received.view)),
                    });
                }
                self.state = State::Return(received);
            }
            Frame::RootCompReturn { execution } => {
                if !self.receiving.matches_value(received.view, received.value) {
                    return Err(RuntimeUnavailable::InvalidSourceReference);
                }
                self.end_execution_view(execution)?;
                // The consumed computation root has no result-path image.
                // Its actual result retains its own view, unknown coverage,
                // private captures and dictionary; no groundness is assumed.
                self.state = State::Return(received);
            }
            Frame::CatchReturn {
                handler,
                environment,
                installation,
            } => {
                self.validate_handler_installation(installation)?;
                // Popping this delimiter leaves the shallow handler before any
                // value pattern binding or arm code executes.
                let Instruction::Catch { arms, .. } = &handler.instruction else {
                    unreachable!()
                };
                if let Some(arm) = arms
                    .iter()
                    .find(|arm| matches!(arm.pattern, LocalSourceCatchPattern::Value(_)))
                {
                    let LocalSourceCatchPattern::Value(pattern) = &arm.pattern else {
                        unreachable!()
                    };
                    let environment = match pattern {
                        LocalSourceCatchValuePattern::Binder(binder) => self.bind(
                            environment,
                            Binder::Catch(binder.id.clone()),
                            ReceivedValue {
                                dispatch: received.dispatch,
                                value: received.value,
                                interface: ParameterRole::Value,
                                view: received.view,
                            },
                        ),
                        LocalSourceCatchValuePattern::Wildcard => environment,
                    };
                    let _ = (&arm.source, &arm.range);
                    self.state = State::Evaluate {
                        code: arm.body,
                        environment,
                    };
                } else {
                    self.state = State::Return(received);
                }
            }
            Frame::OperationPayload {
                declaration,
                source,
            } => self.make_request_carrier(declaration, received, &source),
            Frame::OperationResultConsumer { source, callback_use } => {
                if let Some(callback_use) = callback_use {
                    let execution = self.receiving.callback_execution(callback_use)
                        .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                    #[cfg(test)]
                    {
                        let (_, apply, _, result_view, result_receipt) = self.receiving
                            .hygiene_callback_use(callback_use)
                            .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                        let (_, _, occurrence, _, _, _) = self.receiving.hygiene_execution(execution)
                            .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                        self.hygiene_trace.record(HygieneObservation::CallbackExecution {
                            use_handle: callback_use,
                            owner: self.current_execution_owner(),
                            apply,
                            result_view,
                            result_receipt,
                            occurrence,
                        });
                    }
                    self.executing_views.push(execution);
                    self.frames.push(Frame::RootCompReturn { execution });
                }
                self.execute_with_substitution(received.value, &source, received.dispatch)?;
            }
            Frame::DiscardToUnit { site } => self.ground_data(&site, RuntimeValueKind::Unit, None),
            Frame::PrimitiveArgument { operation, mut arguments, site } => {
                arguments.try_reserve(1).map_err(|_| RuntimeUnavailable::InvalidSourceReference)?;
                arguments.push(received.value);
                let arity = pinned_primitive_arity(&operation).ok_or_else(|| RuntimeUnavailable::InvalidSourceReference)?;
                if arguments.len() < arity {
                    self.data(
                        &site,
                        RuntimeValueKind::Primitive(operation.clone()),
                        Some(ExecutableValue::Primitive { operation, arguments }),
                    );
                } else if arguments.len() == arity {
                    if matches!(operation, yu_hir::shadow::PinnedPrimitiveOp::IntMul) {
                        let Some(RuntimeValueKind::Integer(left)) = self.values.get(arguments[0].0).map(|value| &value.kind) else {
                            return Err(RuntimeUnavailable::InvalidSourceReference);
                        };
                        let Some(RuntimeValueKind::Integer(right)) = self.values.get(arguments[1].0).map(|value| &value.kind) else {
                            return Err(RuntimeUnavailable::InvalidSourceReference);
                        };
                        let product = super::decimal::Product::new(left, right)
                            .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                        self.state = State::IntegerProduct { product, site };
                    } else {
                        let result = pinned_primitive_apply(&operation, &arguments, &self.values)
                            .ok_or_else(|| RuntimeUnavailable::InvalidSourceReference)?;
                        self.ground_data(&site, result, None);
                    }
                } else {
                    return Err(RuntimeUnavailable::InvalidSourceReference);
                }
            }
            Frame::Callee {
                callee,
                argument,
                environment,
                site,
            } => {
                // This allocates only inert code plus lexical references. No
                // argument prefix runs before the receiver entry is selected.
                let delay = self.allocate(
                    &site,
                    RuntimeValueKind::Computation,
                    Some(ExecutableValue::Delay {
                        code: argument,
                        environment,
                    }),
                );
                let inherited = self.direct_formal_root(argument, environment);
                let delay_view = self.receiving.delay(delay, inherited);
                let executable = self.executables.get(&received.value.0).cloned();
                match executable {
                    Some(ExecutableValue::Primitive { operation, arguments }) => {
                        // This actual primitive receives a Value argument. Its
                        // invocation owns the force, including a suspended raw
                        // suffix, just like an ordinary Value-entry closure.
                        let provider = self.values[received.value.0].source.clone();
                        let (activation, previous) = self.new_invocation(site.clone(), provider)?;
                        self.frames.push(Frame::ReceiverReturn { activation, previous });
                        self.frames.push(Frame::PrimitiveArgument { operation, arguments, site: site.clone() });
                        self.execute(delay, &site)?;
                    }
                    Some(ExecutableValue::Continuation(template)) => {
                        let provider = self.values[received.value.0].source.clone();
                        let (activation, previous) = self.new_invocation(site.clone(), provider.clone())?;
                        #[cfg(test)]
                        {
                            let owner = ExecutionOwner::Invocation(activation);
                            self.hygiene_trace.record(HygieneObservation::ContinuationApply {
                                template,
                                owner,
                                parent: previous,
                                call: site.clone(),
                                provider,
                            });
                            self.hygiene_trace.active_continuations.push((template, owner));
                        }
                        self.frames.push(Frame::ReceiverReturn {
                            activation,
                            previous,
                        });
                        self.frames.push(Frame::ResumeArgument {
                            template,
                            source: site.clone(),
                        });
                        self.execute(delay, &site)?;
                    }
                    Some(ExecutableValue::Closure {
                        parameter,
                        unit_pattern,
                        record_pattern,
                        role,
                        root_schema,
                        callback_schema,
                        body,
                        environment,
                    }) => {
                        let exact_response_invocation = self
                            .program
                            .operation_v1
                            .as_ref()
                            .is_some_and(|plan| {
                                site.occurrence == plan.response_invocation_apply.occurrence
                                    && site.source_root == plan.response_invocation_apply.source_root
                            })
                            && self.operation_v1_trace.as_ref().is_some_and(|trace| {
                                trace.selected_closure.is_some_and(|(value, saved_environment)| {
                                    value == received.value && saved_environment == environment
                                })
                            });
                        let provider = self.values[received.value.0].source.clone();
                        let (activation, previous) = self.new_invocation(site.clone(), provider)?;
                        if let (Some(plan), Some(trace)) =
                            (&self.program.operation_v1, &mut self.operation_v1_trace)
                        {
                            if plan.local_lineage.as_ref().is_some_and(|lineage|
                                site.occurrence == lineage.apply.occurrence)
                                && trace.installed_local_cell.is_some_and(
                                    |(cell, value, saved_environment, install_owner)| {
                                        value == received.value
                                            && saved_environment == environment
                                            && trace.read_local_cell.is_some_and(
                                                |(read_cell, read_value, read_owner)| {
                                                    read_cell == cell
                                                        && read_value == value
                                                        && read_owner == install_owner
                                                },
                                            )
                                    },
                                )
                            {
                                trace.local_invocation_owner =
                                    Some(ExecutionOwner::Invocation(activation));
                            }
                        }
                        if exact_response_invocation {
                            if let Some(trace) = &mut self.operation_v1_trace {
                                trace.applied_response_invocation = Some((
                                    site.clone(),
                                    ExecutionOwner::Invocation(activation),
                                ));
                            }
                        }
                        let environment = self.substitute_environment(environment, received.dispatch)?;
                        self.frames.push(Frame::ReceiverReturn {
                            activation,
                            previous,
                        });
                        match role {
                            ParameterRole::Value => {
                                self.frames.push(Frame::ValueEntry {
                                    parameter,
                                    callback_schema,
                                    entry_receiver: activation,
                                    unit_pattern,
                                    record_pattern,
                                    body,
                                    environment,
                                });
                                self.execute(delay, &site)?;
                            }
                            ParameterRole::Computation => {
                                let view = if let Some(schema) = root_schema {
                                    let view = self.receiving.enter(
                                        delay,
                                        delay_view,
                                        activation,
                                        schema.clone(),
                                    );
                                    self.receiving.receipt(
                                        ExecutionOwner::Invocation(activation),
                                        view,
                                        &schema.lambda,
                                        Some(parameter.clone()),
                                    );
                                    view
                                } else {
                                    delay_view
                                };
                                let environment = self.bind(
                                    environment,
                                    Binder::Parameter(parameter),
                                    ReceivedValue {
                                        dispatch: None,
                                        value: delay,
                                        interface: ParameterRole::Computation,
                                        view,
                                    },
                                );
                                self.state = State::Evaluate {
                                    code: body,
                                    environment,
                                };
                            }
                        }
                    }
                    _ if matches!(
                        &self.values[received.value.0].kind,
                        RuntimeValueKind::Operation(_)
                    ) =>
                    {
                        let RuntimeValueKind::Operation(SourceOperationResolution::Resolved(
                            declaration,
                        )) = &self.values[received.value.0].kind
                        else {
                            return Err(RuntimeUnavailable::UnresolvedOperation(site));
                        };
                        let declaration = declaration.clone();
                        if declaration.signature.effects.is_some() {
                            return Err(RuntimeUnavailable::OperationConsumer(site));
                        }
                        let SourceAnnotationValue::Function { argument, result } =
                            &declaration.signature.value
                        else {
                            return Err(RuntimeUnavailable::OperationConsumer(site));
                        };
                        let role = if argument.effects.is_some() {
                            ParameterRole::Computation
                        } else {
                            ParameterRole::Value
                        };
                        let callback_use = if role == ParameterRole::Value
                            && argument.effects.is_none()
                            && matches!(argument.value, SourceAnnotationValue::Unit)
                            && result.effects.is_none()
                            && matches!(result.value, SourceAnnotationValue::Int)
                        {
                            let source_formal = callee.and_then(|callee| {
                                let code = self.program.code.get(callee.0)?;
                                let Instruction::Name {
                                    resolution: LocalSourceResolution::Parameter(formal),
                                    consumption: NameConsumption::Observe,
                                } = &code.instruction else { return None; };
                                self.receiving.callback_entry_for_apply(
                                    received.value,
                                    received.view,
                                    formal,
                                    self.current_execution_owner(),
                                    &code.site,
                                )
                            });
                            source_formal.and_then(|entry| {
                                self.receiving.callback_use(
                                    entry,
                                    received.value,
                                    received.view,
                                    &site,
                                    self.current_execution_owner(),
                                )
                            })
                        } else {
                            None
                        };
                        #[cfg(test)]
                        if let Some(use_handle) = callback_use {
                            let owner = self.current_execution_owner();
                            let code = callee.and_then(|label| self.program.code.get(label.0))
                                .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                            let name = code.site.clone();
                            let (entry, apply, name_view, result_view, use_receipt) = self.receiving
                                .hygiene_callback_use(use_handle)
                                .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                            let (lambda, formal, _, _, _, formal_receipt) = self.receiving
                                .hygiene_callback_entry(entry)
                                .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                            let name_receipt = self.receiving.hygiene_receipt(owner, name_view, None)
                                .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                            let name_minted = self.hygiene_trace.observations.iter().any(|record| {
                                matches!(&record.transition, HygieneObservation::NameReceipt {
                                    owner: seen_owner, name: seen_name, formal: seen_formal, view, receipt,
                                } if *seen_owner == owner && seen_formal == &formal && *view == name_view
                                    && *receipt == name_receipt && HygieneTrace::site_eq(seen_name, &name))
                            });
                            if !name_minted { return Err(RuntimeUnavailable::InvalidSourceReference); }
                            self.hygiene_trace.record(HygieneObservation::CallbackUse {
                                entry,
                                use_handle,
                                owner,
                                name,
                                apply,
                                formal,
                                name_view,
                                result_view,
                                formal_receipt,
                                name_receipt,
                                use_receipt,
                            });
                            let _ = lambda;
                        }
                        let provider = self.values[received.value.0].source.clone();
                        let (activation, previous) = self.new_invocation(site.clone(), provider)?;
                        // The declared source consumer runs after native return.
                        // Its authority comes from the operation declaration,
                        // including when the written result effect row is absent.
                        self.frames.push(Frame::OperationResultConsumer {
                            source: site.clone(),
                            callback_use,
                        });
                        self.frames.push(Frame::ReceiverReturn {
                            activation,
                            previous,
                        });
                        match role {
                            ParameterRole::Value => {
                                self.frames.push(Frame::OperationPayload {
                                    declaration,
                                    source: site.clone(),
                                });
                                self.execute(delay, &site)?;
                            }
                            ParameterRole::Computation => self.make_request_carrier(
                                declaration,
                                ReceivedValue {
                                    dispatch: None,
                                    value: delay,
                                    interface: ParameterRole::Computation,
                                    view: delay_view,
                                },
                                &site,
                            ),
                        }
                    }
                    _ => return Err(RuntimeUnavailable::ExpectedCallable(site)),
                }
            }
            Frame::ReceiverReturn {
                activation,
                previous,
            } => {
                self.leave_owner(ExecutionOwner::Invocation(activation), true, previous)?;
                #[cfg(test)]
                {
                    let descriptor = self.invocations.get(activation)
                        .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                    self.hygiene_trace.record(HygieneObservation::OwnerClose {
                        owner: ExecutionOwner::Invocation(activation),
                        call: descriptor.call.clone(),
                        provider: descriptor.provider.clone(),
                        returned: Some((received.value, received.view)),
                    });
                }
                self.state = State::Return(ReceivedValue {
                    dispatch: received.dispatch,
                    value: received.value,
                    interface: ParameterRole::Value,
                    view: received.view,
                });
            }
            Frame::ValueEntry {
                parameter,
                callback_schema,
                entry_receiver,
                unit_pattern,
                record_pattern,
                body,
                environment,
            } => {
                let ordinary_entry = callback_schema.is_none()
                    && !unit_pattern
                    && record_pattern.is_none();
                let received = if let Some(schema) = callback_schema {
                    let owner = ExecutionOwner::Invocation(entry_receiver);
                    if unit_pattern
                        || record_pattern.is_some()
                        || self.current_execution_owner() != owner
                        || schema.formal.id != parameter
                        || schema.formal.id.source_root() != &schema.lambda.source_root
                        || received.interface != ParameterRole::Value
                    {
                        return Err(RuntimeUnavailable::InvalidSourceReference);
                    }
                    let (view, entry) = self.receiving.callback_entry(
                        schema,
                        owner,
                        received.value,
                        received.view,
                    ).ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                    #[cfg(test)]
                    {
                        let (lambda, formal, families, incoming, entry_view, formal_receipt) = self.receiving
                            .hygiene_callback_entry(entry)
                            .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                        self.hygiene_trace.record(HygieneObservation::Permission {
                            lambda: lambda.clone(),
                            formal: formal.clone(),
                            families,
                        });
                        self.hygiene_trace.record(HygieneObservation::CallbackEntry {
                            entry,
                            owner,
                            lambda,
                            formal,
                            incoming,
                            view: entry_view,
                            formal_receipt,
                        });
                    }
                    ReceivedValue { interface: ParameterRole::Value, view, ..received }
                } else {
                    received
                };
                if let Some(fields) = record_pattern {
                    return self.bind_record_parameter(fields, 0, received, body, environment);
                }
                let bound_cell = self.cells.len();
                let returned_value_origin_site = self.values[received.value.0].source.clone();
                let environment = if unit_pattern {
                    if !self.value(received.value).is_some_and(|value| matches!(value.kind, RuntimeValueKind::Unit)) {
                        return Err(RuntimeUnavailable::InvalidSourceReference);
                    }
                    environment
                } else { self.bind(
                    environment,
                    Binder::Parameter(parameter.clone()),
                    ReceivedValue {
                        dispatch: received.dispatch,
                        value: received.value,
                        interface: ParameterRole::Value,
                        view: received.view,
                    },
                ) };
                if ordinary_entry {
                    let owner_matches = self.current_execution_owner()
                        == ExecutionOwner::Invocation(entry_receiver);
                    let bound_matches = self.cells.get(bound_cell).is_some_and(|cell|
                        cell.is_some_and(|bound| bound.value == received.value
                            && bound.view == received.view
                            && bound.interface == ParameterRole::Value));
                    let token_accepted = owner_matches && bound_matches
                        && return_token.as_ref().is_some_and(|pending|
                            pending.invocation == entry_receiver
                                && pending.cells_before_bind == bound_cell
                                && pending.value == received.value
                                && pending.view == received.view
                                && pending.receipt_index.is_some());
                    self.name_entry_value_entry_attempts.push(NameEntryValueEntryAttempt {
                        invocation: entry_receiver,
                        entry_parameter_ordinal: parameter.ordinal(),
                        value: received.value.0,
                        view: received.view.index(),
                        cells_before_bind: bound_cell,
                        bound_cell,
                        cells_after_bind: self.cells.len(),
                        token_receipt_index: return_token.as_ref().and_then(|p| p.receipt_index),
                        token_source_parameter_ordinal: return_token.as_ref().map(|p| p.source_parameter.ordinal()),
                        token_name_site_ordinal: return_token.as_ref().map(|p| p.site.occurrence.ordinal()),
                        token_accepted,
                    });
                    if token_accepted {
                        if let Some(pending) = return_token {
                            self.name_entry_trace = Some(NameEntryCorrespondenceTrace {
                                invocation: entry_receiver,
                                name_site: pending.site,
                                returned_value_origin_site,
                                source_parameter: pending.source_parameter,
                                entry_parameter: parameter,
                                source_cell: pending.source_cell,
                                value: received.value.0,
                                view: received.view.index(),
                                receipt_index: pending.receipt_index.unwrap(),
                                cells_before_bind: pending.cells_before_bind,
                                bound_cell,
                                cells_after_bind: self.cells.len(),
                            });
                        }
                    }
                }
                self.state = State::Evaluate {
                    code: body,
                    environment,
                };
            }
            Frame::RecordDefault { fields, index, argument, body, environment } => {
                let view = self.receiving.project_record(argument.view, received.view, received.value)
                    .ok_or_else(|| RuntimeUnavailable::UnsupportedRecordPattern(self.values[argument.value.0].source.clone()))?;
                let environment = self.bind(environment, Binder::Parameter(fields[index].binder.clone()),
                    ReceivedValue { view, interface: ParameterRole::Value, ..received });
                self.bind_record_parameter(fields, index + 1, argument, body, environment)?;
            }
            Frame::Local {
                block,
                next,
                environment,
                cell,
                recursive,
            } => {
                let execution_owner = self.current_execution_owner();
                let binding = match &block.instruction {
                    Instruction::Block { bindings, .. } => bindings
                        .get(next - 1)
                        .ok_or(RuntimeUnavailable::InvalidSourceReference)?,
                    Instruction::StatementBlock { statements, .. } => match statements.get(next - 1) {
                        Some(BlockStatement::Binding(binding)) => binding,
                        _ => return Err(RuntimeUnavailable::InvalidSourceReference),
                    },
                    _ => return Err(RuntimeUnavailable::InvalidSourceReference),
                };
                if let (Some(plan), Some(trace)) =
                    (&self.program.operation_v1, &mut self.operation_v1_trace)
                {
                    if plan.local_lineage.as_ref().is_some_and(|lineage|
                        binding.id == lineage.binding)
                    {
                        let lineage = plan.local_lineage.as_ref()
                            .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                        let initializer_site = self.program.code.get(binding.initializer.0)
                            .ok_or(RuntimeUnavailable::InvalidSourceReference)?
                            .site.clone();
                        let closure_environment = match self.executables.get(&received.value.0) {
                            Some(ExecutableValue::Closure { environment, .. }) => *environment,
                            _ => return Err(RuntimeUnavailable::InvalidSourceReference),
                        };
                        if initializer_site.occurrence == lineage.initializer_catch.occurrence
                            && trace.initializer_catch_owner == Some(execution_owner)
                        {
                            trace.installed_local_cell = Some((
                                cell,
                                received.value,
                                closure_environment,
                                execution_owner,
                            ));
                        }
                    }
                }
                self.cells[cell] = Some(ReceivedValue {
                    dispatch: received.dispatch,
                    value: received.value,
                    interface: ParameterRole::Value,
                    view: received.view,
                });
                let local = binding.id.clone();
                let environment = if recursive {
                    environment
                } else {
                    self.extend(
                        environment,
                        Binder::Local(local),
                        cell,
                    )
                };
                self.begin_local(block, next, environment)?;
            }
            Frame::Condition {
                conditional,
                arm,
                environment,
            } => {
                let RuntimeValueKind::Boolean(condition) = &self.values[received.value.0].kind
                else {
                    return Err(RuntimeUnavailable::ExpectedBoolean(
                        conditional.site.clone(),
                    ));
                };
                let Instruction::If { arms, else_branch } = &conditional.instruction else {
                    unreachable!()
                };
                if *condition {
                    if else_branch.is_none() {
                        self.frames.push(Frame::DiscardToUnit {
                            site: conditional.site.clone(),
                        });
                    }
                    self.state = State::Evaluate {
                        code: arms[arm].1,
                        environment,
                    };
                } else if let Some((test, _)) = arms.get(arm + 1) {
                    let test = *test;
                    self.state = State::Evaluate {
                        code: test,
                        environment,
                    };
                    self.frames.push(Frame::Condition {
                        conditional,
                        arm: arm + 1,
                        environment,
                    });
                } else if let Some(branch) = else_branch {
                    self.state = State::Evaluate {
                        code: *branch,
                        environment,
                    };
                } else {
                    self.ground_data(&conditional.site, RuntimeValueKind::Unit, None);
                }
            }
            Frame::BlockExpression { block, next, environment } => {
                self.begin_local(block, next, environment)?;
            }
            Frame::Sequence { sequence, next, environment } => {
                let Instruction::Sequence { items } = &sequence.instruction else {
                    unreachable!()
                };
                if let Some(item) = items.get(next).copied() {
                    self.frames.push(Frame::Sequence { sequence, next: next + 1, environment });
                    self.state = State::Evaluate { code: item, environment };
                } else {
                    self.state = State::Return(received);
                }
            }
            Frame::Record { record, next, environment, prefix: previous } => {
                let prefix = self.tuple_prefixes.len();
                self.tuple_prefixes.push(TuplePrefix { previous, received });
                let Instruction::Record { fields } = &record.instruction else { unreachable!() };
                if let Some((_, element)) = fields.get(next) {
                    let element = *element;
                    self.frames.push(Frame::Record { record, next: next + 1, environment, prefix: Some(prefix) });
                    self.state = State::Evaluate { code: element, environment };
                } else {
                    let mut reversed = Vec::with_capacity(fields.len());
                    let mut cursor = Some(prefix);
                    while let Some(index) = cursor {
                        let node = self.tuple_prefixes.get(index).ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                        reversed.push(TupleElement { received: node.received });
                        cursor = node.previous;
                    }
                    if reversed.len() != fields.len() { return Err(RuntimeUnavailable::InvalidSourceReference); }
                    reversed.reverse();
                    let value = fields.iter().map(|(label, _)| label.clone()).zip(reversed).collect();
                    self.data(&record.site, RuntimeValueKind::Record(value), None);
                }
            }
            Frame::Tuple { tuple, next, environment, prefix: previous } => {
                let prefix = self.tuple_prefixes.len();
                self.tuple_prefixes.push(TuplePrefix {
                    previous,
                    received,
                });
                let elements = match &tuple.instruction {
                    Instruction::Tuple { elements } | Instruction::Variant { payloads: elements, .. } => elements,
                    _ => unreachable!(),
                };
                if let Some(element) = elements.get(next).copied() {
                    self.frames.push(Frame::Tuple {
                        tuple,
                        next: next + 1,
                        environment,
                        prefix: Some(prefix),
                    });
                    self.state = State::Evaluate { code: element, environment };
                } else {
                    let mut reversed = Vec::with_capacity(elements.len());
                    let mut cursor = Some(prefix);
                    while let Some(index) = cursor {
                        let node = self.tuple_prefixes.get(index)
                            .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                        reversed.push(TupleElement { received: node.received });
                        cursor = node.previous;
                    }
                    if reversed.len() != elements.len() { return Err(RuntimeUnavailable::InvalidSourceReference); }
                    reversed.reverse();
                    let value = match &tuple.instruction {
                        Instruction::Variant { tag, .. } => RuntimeValueKind::Variant { tag: tag.clone(), payloads: reversed },
                        _ => RuntimeValueKind::Tuple(reversed),
                    };
                    self.data(&tuple.site, value, None);
                }
            }
            Frame::Case { case, environment } => {
                let Instruction::Case { arms, .. } = &case.instruction else {
                    unreachable!()
                };
                let selected = {
                    let value = &self.values[received.value.0].kind;
                    arms.iter().position(|arm| match (&arm.pattern, value) {
                        (CasePattern::Integer(expected), RuntimeValueKind::Integer(actual)) => expected == actual,
                        (CasePattern::Binder(_), _) => true,
                        (CasePattern::Tuple(patterns), RuntimeValueKind::Tuple(elements)) => {
                            patterns.len() == elements.len()
                        }
                        (CasePattern::Variant { tag, payloads }, RuntimeValueKind::Variant { tag: actual, payloads: elements }) => {
                            tag == actual && payloads.len() == elements.len()
                        }
                        (CasePattern::Wildcard, _) => true,
                        _ => false,
                    })
                };
                if let Some(selected) = selected {
                    let arm = &arms[selected];
                    let environment = match &arm.pattern {
                        CasePattern::Binder(id) => self.bind(
                            environment,
                            Binder::Catch(id.clone()),
                            ReceivedValue { dispatch: received.dispatch, value: received.value, interface: ParameterRole::Value, view: received.view },
                        ),
                        CasePattern::Tuple(patterns) | CasePattern::Variant { payloads: patterns, .. } => {
                            let bindings = {
                                let elements = match &self.values[received.value.0].kind {
                                    RuntimeValueKind::Tuple(elements) | RuntimeValueKind::Variant { payloads: elements, .. } => elements,
                                    _ => unreachable!("the selected structural pattern matched its value"),
                                };
                                patterns.iter().zip(elements).filter_map(|(pattern, element)| {
                                    pattern.as_ref().map(|id| (id.clone(), element.received))
                                }).collect::<Vec<_>>()
                            };
                            let mut environment = environment;
                            for (id, mut value) in bindings {
                                value.dispatch = self.dispatch.then(value.dispatch, received.dispatch)?;
                                environment = self.bind(environment, Binder::Catch(id), value);
                            }
                            environment
                        }
                        CasePattern::Integer(_) => environment,
                        CasePattern::Wildcard => environment,
                    };
                    self.state = State::Evaluate {
                        code: arm.body,
                        environment,
                    };
                } else {
                    return Err(RuntimeUnavailable::NonExhaustiveCase(case.site.clone()));
                }
            }
            Frame::ExpressionReturn { root, next } => {
                if !self.program.expression_roots.contains_key(&root) {
                    return Err(RuntimeUnavailable::InvalidSourceReference);
                }
                self.begin_root(next);
            }
            Frame::Root { next, cell } => {
                self.cells[cell] = Some(ReceivedValue {
                    dispatch: received.dispatch,
                    value: received.value,
                    interface: ParameterRole::Value,
                    view: received.view,
                });
                self.initializing_globals.remove(&cell);
                self.begin_root(next);
            }
            Frame::GlobalRead {
                cell,
                consumption,
                site,
                environment,
            } => {
                let received = ReceivedValue {
                    dispatch: received.dispatch,
                    value: received.value,
                    interface: ParameterRole::Value,
                    view: received.view,
                };
                self.cells[cell] = Some(received);
                self.initializing_globals.remove(&cell);
                let received = self.dispatch_name(received, cell, environment, &site)?;
                self.consume(received, consumption, &site, None)?;
            }
        }
        Ok(())
    }

    fn primitive_matches(&self, ty: &SourceAnnotationValue, received: ReceivedValue) -> bool {
        received.interface == ParameterRole::Value
            && self.receiving.matches_value(received.view, received.value)
            && matches!(
                (ty, &self.values[received.value.0].kind),
                (SourceAnnotationValue::Unit, RuntimeValueKind::Unit)
                    | (SourceAnnotationValue::Int, RuntimeValueKind::Integer(_))
                    | (SourceAnnotationValue::Bool, RuntimeValueKind::Boolean(_))
                    | (SourceAnnotationValue::Str, RuntimeValueKind::String(_))
            )
    }
    fn new_invocation(
        &mut self,
        call: SourceSite,
        provider: SourceSite,
    ) -> Result<(usize, ExecutionOwner), RuntimeUnavailable> {
        let activation = self.next_receiver;
        self.next_receiver = activation
            .checked_add(1)
            .ok_or(RuntimeUnavailable::IdentityExhausted)?;
        debug_assert_eq!(self.invocations.len(), activation);
        self.invocations.push(InvocationDescriptor {
            call: call.clone(),
            provider: provider.clone(),
            active: true,
        });
        self.active_receivers.push(activation);
        let previous = self.current_owner;
        self.current_owner = ExecutionOwner::Invocation(activation);
        #[cfg(test)]
        self.hygiene_trace.record(HygieneObservation::OwnerOpen {
            owner: ExecutionOwner::Invocation(activation),
            parent: previous,
            call,
            provider,
        });
        Ok((activation, previous))
    }
    fn leave_owner(
        &mut self,
        owner: ExecutionOwner,
        owned: bool,
        previous: ExecutionOwner,
    ) -> Result<(), RuntimeUnavailable> {
        if self.current_owner != owner {
            return Err(RuntimeUnavailable::InvalidSourceReference);
        }
        if owned {
            let ExecutionOwner::Invocation(id) = owner else {
                return Err(RuntimeUnavailable::InvalidSourceReference);
            };
            if self.active_receivers.pop() != Some(id) {
                return Err(RuntimeUnavailable::InvalidSourceReference);
            }
            let invocation = self
                .invocations
                .get_mut(id)
                .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
            if !invocation.active {
                return Err(RuntimeUnavailable::InvalidSourceReference);
            }
            invocation.active = false;
        } else if !self.owner_active(owner) {
            return Err(RuntimeUnavailable::InvalidSourceReference);
        }
        self.current_owner = previous;
        Ok(())
    }
    fn resolve_control(
        original: ExecutionOwner,
        control: &HashMap<usize, usize>,
    ) -> ExecutionOwner {
        match original {
            ExecutionOwner::ModuleRun => ExecutionOwner::ModuleRun,
            ExecutionOwner::Invocation(id) => {
                ExecutionOwner::Invocation(control.get(&id).copied().unwrap_or(id))
            }
        }
    }
    fn capture_template(
        &mut self,
        request: &PendingRequest,
        containing: ExecutionOwner,
    ) -> Result<TemplateHandle, RuntimeUnavailable> {
        let mut nodes = vec![TemplateNode::Hole];
        let mut root = 0;
        for frame in &request.suffix {
            let node = match frame {
                SavedFrame::Ordinary(Frame::GlobalRead { .. } | Frame::Root { .. }) => {
                    return Err(RuntimeUnavailable::ContinuationMaterialization(
                        request.source.clone(),
                    ));
                }
                SavedFrame::Ordinary(Frame::RootCompReturn { execution }) => TemplateNode::View {
                    inner: root,
                    original: *execution,
                },
                SavedFrame::Ordinary(frame) => {
                    if let Frame::ResumeArgument { template, .. } = frame {
                        self.resume_templates
                            .get(template.0)
                            .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                    }
                    TemplateNode::Bind {
                        inner: root,
                        frame: frame.clone(),
                    }
                }
                SavedFrame::ReceiverBoundary {
                    original_activation,
                } => TemplateNode::Owner {
                    inner: root,
                    original: ExecutionOwner::Invocation(*original_activation),
                },
                SavedFrame::AmbientBoundary => TemplateNode::Owner {
                    inner: root,
                    original: ExecutionOwner::ModuleRun,
                },
                SavedFrame::HandlerBoundary {
                    handler,
                    environment,
                    installation,
                } => TemplateNode::ForwardHandler {
                    inner: root,
                    handler: handler.clone(),
                    environment: *environment,
                    owner: installation.owner,
                },
            };
            nodes.push(node);
            root = nodes.len() - 1;
        }
        // The installing source span still contains the capture bound, even
        // when its ordinary ReceiverReturn lies below it and was not captured.
        nodes.push(TemplateNode::Owner {
            inner: root,
            original: containing,
        });
        root = nodes.len() - 1;
        // Publish only after the whole cache-free template has validated. Nodes
        // and saved Bind frames retain handles, never owning template pointers.
        let handle = TemplateHandle(self.resume_templates.len());
        self.resume_templates.push(ResumeTemplate {
            nodes,
            root,
            declaration: request.declaration.clone(),
            original_event: request.event,
        });
        #[cfg(test)]
        if let Some(request_owner) = self.hygiene_trace.request_owner(request.event) {
            self.hygiene_trace.record(HygieneObservation::ContinuationCapture {
                template: handle,
                event: request.event,
                request_owner,
                operation: request.declaration.id.clone(),
                source: request.source.clone(),
                containing,
                suffix: HygieneTrace::suffix_evidence(&request.suffix),
            });
        }
        Ok(handle)
    }
    fn enter_template(
        &mut self,
        template: TemplateHandle,
        node: usize,
        mut control: HashMap<usize, usize>,
        response: ReceivedValue,
    ) -> Result<(), RuntimeUnavailable> {
        let inner = match self
            .resume_templates
            .get(template.0)
            .ok_or(RuntimeUnavailable::InvalidSourceReference)?
            .nodes
            .get(node)
            .cloned()
            .ok_or(RuntimeUnavailable::InvalidSourceReference)?
        {
            TemplateNode::Hole => {
                self.state = State::Return(response);
                return Ok(());
            }
            TemplateNode::Bind { inner, mut frame } => {
                // Pending callback entries are executable frames, so their
                // owner follows this replay's control map. Existing callback
                // entries/uses/receipts remain immutable historical evidence.
                if let Frame::ValueEntry {
                    callback_schema: Some(_),
                    entry_receiver,
                    ..
                } = &mut frame
                {
                    let resolved = Self::resolve_control(
                        ExecutionOwner::Invocation(*entry_receiver),
                        &control,
                    );
                    let ExecutionOwner::Invocation(receiver) = resolved else {
                        return Err(RuntimeUnavailable::InvalidSourceReference);
                    };
                    *entry_receiver = receiver;
                }
                self.frames.push(frame);
                inner
            }
            TemplateNode::Owner { inner, original } => {
                let previous = self.current_owner;
                let resolved = Self::resolve_control(original, &control);
                let (owner, owned) = if self.owner_active(resolved) {
                    self.current_owner = resolved;
                    (resolved, false)
                } else {
                    let ExecutionOwner::Invocation(original_id) = original else {
                        return Err(RuntimeUnavailable::InvalidSourceReference);
                    };
                    let descriptor = self
                        .invocations
                        .get(original_id)
                        .cloned()
                        .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                    let (fresh, _) = self.new_invocation(descriptor.call, descriptor.provider)?;
                    (ExecutionOwner::Invocation(fresh), true)
                };
                if let (
                    ExecutionOwner::Invocation(original),
                    ExecutionOwner::Invocation(resolved),
                ) = (original, owner)
                {
                    // Entry follows one inward path before Hole. Moving this
                    // fresh per-use map and shadowing here equals the nearest
                    // parent binding; no later completion consults this map.
                    control.insert(original, resolved);
                }
                self.frames.push(Frame::OwnerReturn {
                    owner,
                    owned,
                    previous,
                });
                inner
            }
            TemplateNode::ForwardHandler {
                inner,
                handler,
                environment,
                owner,
            } => {
                let owner = Self::resolve_control(owner, &control);
                if !self.owner_active(owner) || self.current_owner != owner {
                    return Err(RuntimeUnavailable::InvalidSourceReference);
                }
                let occurrence = self.next_handler;
                self.next_handler = occurrence
                    .checked_add(1)
                    .ok_or(RuntimeUnavailable::IdentityExhausted)?;
                self.frames.push(Frame::CatchReturn {
                    handler,
                    environment,
                    installation: HandlerInstallation { occurrence, owner },
                });
                inner
            }
            TemplateNode::View { inner, original } => {
                let execution = self
                    .receiving
                    .execution(original.view, original.receipt)
                    .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                self.executing_views.push(execution);
                self.frames.push(Frame::RootCompReturn { execution });
                inner
            }
        };
        self.state = State::EnterTemplate {
            template,
            node: inner,
            control,
            response,
        };
        Ok(())
    }
    fn direct_formal_root(&self, label: Label, environment: usize) -> Option<ViewHandle> {
        let Instruction::Name {
            resolution: LocalSourceResolution::Parameter(parameter),
            consumption: NameConsumption::Execute,
        } = &self.program.code.get(label.0)?.instruction
        else {
            return None;
        };
        let cell = self.lookup(environment, |binder| {
            matches!(binder, Binder::Parameter(candidate) if candidate == parameter)
        })?;
        let received = self.cells.get(cell).copied().flatten()?;
        (received.interface == ParameterRole::Computation).then_some(received.view)
    }
    fn end_execution_view(&mut self, execution: ExecutionView) -> Result<(), RuntimeUnavailable> {
        let Some(current) = self.executing_views.pop() else {
            return Err(RuntimeUnavailable::InvalidSourceReference);
        };
        if current.view != execution.view
            || current.receipt != execution.receipt
            || current.occurrence != execution.occurrence
        {
            return Err(RuntimeUnavailable::InvalidSourceReference);
        }
        Ok(())
    }
    fn current_execution_owner(&self) -> ExecutionOwner {
        self.current_owner
    }
    fn owner_active(&self, owner: ExecutionOwner) -> bool {
        match owner {
            ExecutionOwner::ModuleRun => true,
            ExecutionOwner::Invocation(id) => self
                .invocations
                .get(id)
                .is_some_and(InvocationDescriptor::is_active),
        }
    }
    fn validate_handler_installation(
        &self,
        installation: HandlerInstallation,
    ) -> Result<(), RuntimeUnavailable> {
        // The retained installer must be both executable here and actually live.
        // A borrowed resumed owner can be below the resumer in active order;
        // ModuleRun is the distinct ambient case, never an invocation ordinal.
        if installation.occurrence >= self.next_handler
            || installation.owner != self.current_execution_owner()
            || !self.owner_active(installation.owner)
        {
            return Err(RuntimeUnavailable::InvalidSourceReference);
        }
        Ok(())
    }
    fn propagate_request(&mut self, mut request: PendingRequest) -> Result<(), RuntimeUnavailable> {
        let request_owner = self.current_execution_owner();
        if let (Some(plan), Some(trace)) =
            (&self.program.operation_v1, &mut self.operation_v1_trace)
        {
            if trace.callback_operation_seen
                && trace.callback_operation_owner == Some(request_owner)
                && trace.applied_response_invocation.as_ref().is_some_and(|(_, owner)| {
                    *owner == request_owner
                })
                && request.declaration.id == plan.link.callback_operation
                && request.source.occurrence == plan.link.callback_apply
            {
                trace.callback_request_event = Some(request.event);
                trace.callback_request = Some((request.event, request.source.clone()));
            }
        }
        // Inspect the actual installed candidate while its delimiter is still
        // active. Only a committed forwarding transition removes that occurrence.
        if let Some(Frame::CatchReturn {
            handler,
            installation,
            environment,
        }) = self.frames.last().cloned()
        {
            self.validate_handler_installation(installation)?;
            let Instruction::Catch { arms, .. } = &handler.instruction else {
                unreachable!()
            };
            for arm in arms {
                let LocalSourceCatchPattern::Operation {
                    resolution,
                    payloads,
                    continuation,
                    ..
                } = &arm.pattern
                else {
                    continue;
                };
                let declaration = match resolution {
                    SourceOperationResolution::Resolved(declaration)
                        if declaration.id != request.declaration.id =>
                    {
                        continue;
                    }
                    SourceOperationResolution::Resolved(declaration) => declaration,
                    _ => return Err(RuntimeUnavailable::HandlerEvidence(handler.site.clone())),
                };
                // The closed primitive ModuleRun certificate proves unprotected
                // events for this whole universe. Otherwise require a positive
                // local Grant; missing Grant alone supplies no negative fact.
                if !self.program.closed_primitive
                    && !self.receiving.local_grant(
                        &request.observations,
                        request.event,
                        installation.owner,
                        &self.invocations,
                        &request.declaration.id.family,
                    )
                {
                    return Err(RuntimeUnavailable::HandlerEvidence(handler.site.clone()));
                }
                let SourceAnnotationValue::Function { argument, result } =
                    &declaration.signature.value
                else {
                    return Err(RuntimeUnavailable::HandlerEvidence(handler.site.clone()));
                };
                if declaration.signature.effects.is_some() || argument.effects.is_some() {
                    return Err(RuntimeUnavailable::HandlerEvidence(handler.site.clone()));
                }
                let [payload_pattern] = payloads.as_slice() else {
                    return Err(RuntimeUnavailable::HandlerEvidence(handler.site.clone()));
                };
                if !self.primitive_matches(&argument.value, request.payload) {
                    return Err(RuntimeUnavailable::HandlerEvidence(handler.site.clone()));
                }
                let captured = if matches!(continuation, LocalSourceCatchValuePattern::Binder(_)) {
                    let primitive_response = matches!(
                        result.value,
                        SourceAnnotationValue::Unit
                            | SourceAnnotationValue::Int
                            | SourceAnnotationValue::Bool
                            | SourceAnnotationValue::Str
                    );
                    let exact_v1_function_response = matches!(
                        &result.value,
                        SourceAnnotationValue::Function { .. }
                    ) && self.program.operation_v1.as_ref().is_some_and(|plan| {
                        request.source.occurrence == plan.request_apply.occurrence
                            && request.declaration.id == plan.request_operation
                            && handler.site.occurrence == plan.request_handler.occurrence
                            && arm.source == plan.request_arm
                            && self.operation_v1_trace.as_ref().is_some_and(|trace| {
                                trace.request_operation_seen
                            })
                    });
                    if !primitive_response && !exact_v1_function_response {
                        return Err(RuntimeUnavailable::HandlerEvidence(handler.site.clone()));
                    }
                    Some(self.capture_template(&request, self.current_owner)?)
                } else {
                    None
                };
                #[cfg(test)]
                let hygiene_request_owner = self.hygiene_trace.request_owner(request.event)
                    .unwrap_or(request_owner);
                #[cfg(test)]
                self.hygiene_trace.record(HygieneObservation::CatchCandidate {
                    event: request.event,
                    request_owner: hygiene_request_owner,
                    owner: installation.owner,
                    handler_occurrence: installation.occurrence,
                    handler: handler.site.clone(),
                    arm: arm.source.clone(),
                    arm_range: arm.range.clone(),
                    operation: request.declaration.id.clone(),
                    payload: request.payload.value,
                });
                #[cfg(test)]
                let hygiene_suffix = HygieneTrace::suffix_evidence(&request.suffix);
                #[cfg(test)]
                let mut hygiene_pending_before: Vec<_> = self.initializing_globals.iter().copied().collect();
                #[cfg(test)]
                hygiene_pending_before.sort_unstable();
                #[cfg(test)]
                let hygiene_callback_use = self.hygiene_trace.callback_use(request.event);
                #[cfg(test)]
                let hygiene_catch_index = self.hygiene_trace.record(HygieneObservation::CatchCommit {
                    event: request.event,
                    request_owner: hygiene_request_owner,
                    owner: installation.owner,
                    handler_occurrence: installation.occurrence,
                    handler: handler.site.clone(),
                    arm: arm.source.clone(),
                    arm_range: arm.range.clone(),
                    operation: request.declaration.id.clone(),
                    payload: request.payload.value,
                    callback_use: hygiene_callback_use,
                    lifetime: if captured.is_some() { HygieneLifetime::CapturedContinuation }
                        else { HygieneLifetime::ShallowDiscard },
                    result: None,
                    continuation: captured,
                    retirement: None,
                });
                // Commit shallow selection only after every ordered candidate
                // premise succeeds. Discarding its raw suffix is source control;
                // the arm executes outside this exact handler occurrence.
                self.frames.pop();
                #[cfg(test)]
                self.hygiene_trace.active_catches.push((hygiene_catch_index, self.frames.len()));
                if captured.is_none() {
                    self.abandon_suffix(&request.suffix);
                    #[cfg(test)]
                    {
                        let mut hygiene_pending_after: Vec<_> = self.initializing_globals.iter().copied().collect();
                        hygiene_pending_after.sort_unstable();
                        let retired_cells: Vec<_> = hygiene_pending_before.iter().copied()
                            .filter(|cell| !hygiene_pending_after.contains(cell)).collect();
                        if let Some(HygieneRecord { transition: HygieneObservation::CatchCommit { retirement, .. }, .. }) =
                            self.hygiene_trace.observations.get_mut(hygiene_catch_index)
                        {
                            *retirement = Some(retired_cells.clone());
                        }
                        self.hygiene_trace.record(HygieneObservation::ShallowRetirement {
                            event: request.event,
                            request_owner: hygiene_request_owner,
                            handler_owner: installation.owner,
                            handler_occurrence: installation.occurrence,
                            suffix: hygiene_suffix,
                            pending_before: hygiene_pending_before,
                            retired_cells,
                            pending_after: hygiene_pending_after,
                        });
                    }
                }
                let environment = match payload_pattern {
                    LocalSourceCatchPayloadPattern::Value(
                        LocalSourceCatchValuePattern::Binder(binder),
                    ) => self.bind(
                        environment,
                        Binder::Catch(binder.id.clone()),
                        request.payload,
                    ),
                    LocalSourceCatchPayloadPattern::Value(
                        LocalSourceCatchValuePattern::Wildcard,
                    )
                    // Empty-call pattern syntax lowers to a wildcard; payload
                    // compatibility is established above by the declaration.
                    | LocalSourceCatchPayloadPattern::Unit { .. } => environment,
                };
                let environment =
                    if let (LocalSourceCatchValuePattern::Binder(binder), Some(template)) =
                        (continuation, captured)
                    {
                        let value = self.allocate(
                            &handler.site,
                            RuntimeValueKind::Closure,
                            Some(ExecutableValue::Continuation(template)),
                        );
                        let view = self.receiving.opaque(value);
                        self.bind(
                            environment,
                            Binder::Catch(binder.id.clone()),
                            ReceivedValue {
                                dispatch: None,
                                value,
                                interface: ParameterRole::Value,
                                view,
                            },
                        )
                    } else {
                        environment
                    };
                self.state = State::Evaluate {
                    code: arm.body,
                    environment,
                };
                if let Some(trace) = &mut self.operation_v1_trace {
                    if let Some(plan) = &self.program.operation_v1 {
                        if trace.callback_request_event == Some(request.event)
                            && request.declaration.id == plan.link.callback_operation
                            && request.source.occurrence == plan.link.callback_apply
                            && plan.expected_outer_handler.as_ref().is_some_and(|expected|
                                handler.site.occurrence == expected.occurrence)
                            && plan.expected_outer_arm.as_ref().is_some_and(|expected|
                                &arm.source == expected)
                            && trace.callback_request.as_ref().is_some_and(|(event, source)| {
                                *event == request.event
                                    && source.occurrence == request.source.occurrence
                            })
                        {
                            trace.live_handler = Some((
                                handler.site.clone(),
                                arm.source.clone(),
                                request.event,
                                request.source.clone(),
                            ));
                        }
                    }
                }
                return Ok(());
            }
        }
        // An initializer's escaping request cannot search handlers installed
        // around the Name that demanded its value. Scheduled initializers have
        // the same cut for the authenticated resumable host consumer. Keep its
        // cache write and module cursor live; resume must drain owner frames
        // before another root starts. Other escaping operations remain terminal
        // and retain their existing opaque suffix observation.
        let resumable_host = self.program.host_write_operation()
            .is_some_and(|operation| operation == &request.declaration.id);
        if matches!(self.frames.last(), Some(Frame::GlobalRead { .. }))
            || (resumable_host && matches!(self.frames.last(),
                Some(Frame::Root { .. } | Frame::ExpressionReturn { .. }))) {
            self.stop_unhandled_request(request, request_owner)?;
            return Ok(());
        }
        let Some(frame) = self.frames.pop() else {
            self.stop_unhandled_request(request, request_owner)?;
            return Ok(());
        };
        let template = match frame {
            Frame::RootCompReturn { execution } => {
                self.end_execution_view(execution)?;
                SavedFrame::Ordinary(Frame::RootCompReturn { execution })
            }
            Frame::ReceiverReturn {
                activation,
                previous,
            } => {
                self.leave_owner(ExecutionOwner::Invocation(activation), true, previous)?;
                #[cfg(test)]
                {
                    let descriptor = self.invocations.get(activation)
                        .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                    self.hygiene_trace.record(HygieneObservation::OwnerClose {
                        owner: ExecutionOwner::Invocation(activation),
                        call: descriptor.call.clone(),
                        provider: descriptor.provider.clone(),
                        returned: None,
                    });
                }
                SavedFrame::ReceiverBoundary {
                    original_activation: activation,
                }
            }
            Frame::OwnerReturn {
                owner,
                owned,
                previous,
            } => {
                self.leave_owner(owner, owned, previous)?;
                #[cfg(test)]
                if let ExecutionOwner::Invocation(id) = owner {
                    let descriptor = self.invocations.get(id)
                        .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                    self.hygiene_trace.record(HygieneObservation::OwnerClose {
                        owner,
                        call: descriptor.call.clone(),
                        provider: descriptor.provider.clone(),
                        returned: None,
                    });
                }
                match owner {
                    ExecutionOwner::Invocation(original_activation) => {
                        SavedFrame::ReceiverBoundary {
                            original_activation,
                        }
                    }
                    ExecutionOwner::ModuleRun => SavedFrame::AmbientBoundary,
                }
            }
            Frame::CatchReturn {
                handler,
                environment,
                installation,
            } => SavedFrame::HandlerBoundary {
                handler,
                environment,
                installation,
            },
            ordinary => SavedFrame::Ordinary(ordinary),
        };
        request.suffix.push(template);
        self.state = State::Request(request);
        Ok(())
    }
    fn stop_unhandled_request(
        &mut self,
        request: PendingRequest,
        containing: ExecutionOwner,
    ) -> Result<(), RuntimeUnavailable> {
        let template = if self.program.host_write_operation()
            .is_some_and(|operation| operation == &request.declaration.id)
        {
            Some(self.capture_template(&request, containing)?)
        } else {
            None
        };
        let continuation = ContinuationHandle(self.continuations.len());
        self.continuations.push(SavedContinuation {
            frames: request.suffix,
            template,
            resumed: false,
            observations: request.observations,
        });
        self.state = State::Stopped(RuntimeOutcome::UnhandledRequest {
            source: request.source,
            operation: request.declaration.id.clone(),
            payload: request.payload.value,
            event: request.event,
            continuation,
        });
        Ok(())
    }
    fn abandon_suffix(&mut self, suffix: &[SavedFrame]) {
        // These writes will never run: release only their pending materialization
        // markers. Live outer cache owners and retained/forwarded suffixes remain
        // untouched, and the selected arm is not their initializer result.
        for frame in suffix {
            if let SavedFrame::Ordinary(Frame::GlobalRead { cell, .. } | Frame::Root { cell, .. }) =
                frame
            {
                self.initializing_globals.remove(cell);
            }
        }
    }
    fn make_request_carrier(
        &mut self,
        declaration: Arc<SourceOperationDeclaration>,
        payload: ReceivedValue,
        source: &SourceSite,
    ) {
        self.data(
            source,
            RuntimeValueKind::Computation,
            Some(ExecutableValue::Request {
                declaration,
                payload,
                source: source.clone(),
            }),
        );
        #[cfg(test)]
        if let State::Return(received) = &self.state {
            self.hygiene_trace.record(HygieneObservation::CarrierConstructed {
                carrier: received.value,
                owner: self.current_execution_owner(),
                source: source.clone(),
            });
        }
    }
    fn begin_root(&mut self, mut ordinal: usize) {
        // Completion is reached only after the root's handlers and real
        // invocation owners have returned. Never overwrite a mismatched owner.
        if self.current_owner != ExecutionOwner::ModuleRun {
            self.state = State::Stopped(RuntimeOutcome::Unavailable(
                RuntimeUnavailable::InvalidSourceReference,
            ));
            return;
        }
        // A slot is visited once; dependency-materialized definitions skip their
        // cache, while expression values have no publication cell or marker.
        while let Some(root) = self.execution_roots.get(ordinal).cloned() {
            ordinal += 1;
            let mut environment = 0;
            let code = match root {
                ScheduledRoot::Definition(index) => {
                    if self.cells[index].is_some() {
                        continue;
                    }
                    self.initializing_globals.insert(index);
                    self.frames.push(Frame::Root {
                        next: ordinal,
                        cell: index,
                    });
                    environment = match self.initializer_environment(index, 0) {
                        Ok(environment) => environment,
                        Err(error) => { self.state = State::Stopped(RuntimeOutcome::Unavailable(error)); return; }
                    };
                    self.program.definitions[index].body
                }
                ScheduledRoot::Expression { root, code } => {
                    self.frames.push(Frame::ExpressionReturn {
                        root,
                        next: ordinal,
                    });
                    code
                }
            };
            self.state = State::Evaluate {
                code,
                environment,
            };
            return;
        }
        if let Some(selected) = self.selected {
            self.complete_selected_definition(ordinal, selected);
        } else {
            self.complete_module();
        }
    }
    fn complete_selected_definition(&mut self, next_ordinal: usize, selected: usize) {
        // Schedule exhaustion retains the selected-definition entry contract:
        // use its cached cell, or evaluate its initializer as the final root.
        if let Some(value) = self.cells[selected] {
            self.state = State::Stopped(RuntimeOutcome::Completed(value.value));
        } else {
            self.initializing_globals.insert(selected);
            self.frames.push(Frame::Root {
                next: next_ordinal,
                cell: selected,
            });
            let environment = match self.initializer_environment(selected, 0) {
                Ok(environment) => environment,
                Err(error) => { self.state = State::Stopped(RuntimeOutcome::Unavailable(error)); return; }
            };
            self.state = State::Evaluate {
                code: self.program.definitions[selected].body,
                environment,
            };
        }
    }
    fn complete_module(&mut self) {
        if self.current_owner != ExecutionOwner::ModuleRun {
            self.state = State::Stopped(RuntimeOutcome::Unavailable(
                RuntimeUnavailable::InvalidSourceReference,
            ));
            return;
        }
        let site = match self.program.module_completion_site() {
            Ok(Some(site)) => site,
            Ok(None) => {
                self.state = State::Stopped(RuntimeOutcome::EmptyModuleCompleted);
                return;
            }
            Err(error) => {
                self.state = State::Stopped(RuntimeOutcome::Unavailable(error));
                return;
            }
        };
        let value = self.allocate(&site, RuntimeValueKind::Unit, None);
        self.state = State::Stopped(RuntimeOutcome::Completed(value));
    }
    fn consume(
        &mut self,
        received: ReceivedValue,
        consumption: NameConsumption,
        site: &SourceSite,
        formal: Option<&HirParameterId>,
    ) -> Result<(), RuntimeUnavailable> {
        // A candidate is single-use and belongs to this Name consume only.
        // Any prior return token is likewise expired before a new consume.
        let candidate = self.pending_name_entry.take();
        let observed_name = self.pending_name_observation.take();
        self.name_entry_return_token = None;
        self.pending_name_return_observation = None;
        if !self.receiving.matches_value(received.view, received.value) {
            return Err(RuntimeUnavailable::InvalidSourceReference);
        }
        let owner = self.current_execution_owner();
        let receipt_index = self.receiving.next_receipt_index();
        let receipt =
            self.receiving
                .receipt(owner, received.view, site, None);
        #[cfg(test)]
        if consumption == NameConsumption::Observe {
            if let Some(formal) = formal {
                self.hygiene_trace.record(HygieneObservation::NameReceipt {
                    owner,
                    name: site.clone(),
                    formal: formal.clone(),
                    view: received.view,
                    receipt,
                });
            }
        }
        if consumption == NameConsumption::Observe {
            if let Some(observed) = observed_name.filter(|observed|
                observed.site.source_root == site.source_root
                    && observed.site.occurrence == site.occurrence)
            {
                self.pending_name_return_observation = Some(CompletedNameObservation {
                    resolution: observed.resolution,
                    site: observed.site,
                    cell: observed.cell,
                    value: received.value,
                    view: received.view,
                    receipt_index,
                    cells_before_observe: self.cells.len(),
                });
            }
        }
        if consumption == NameConsumption::Observe {
            if let Some(mut pending) = candidate {
            if pending.site.source_root == site.source_root
                && pending.site.occurrence == site.occurrence
                && pending.value == received.value
                && pending.view == received.view
                && owner == ExecutionOwner::Invocation(pending.invocation)
            {
                pending.receipt_index = Some(receipt_index);
                self.name_entry_return_token = Some(pending);
            }
            }
        }
        match consumption {
            NameConsumption::Observe => self.state = State::Return(received),
            NameConsumption::Execute => {
                if received.interface != ParameterRole::Computation {
                    return Err(RuntimeUnavailable::MissingConsumptionEvidence(site.clone()));
                }
                if self.receiving.has_root(received.view) {
                    let execution = self
                        .receiving
                        .execution(received.view, receipt)
                        .ok_or(RuntimeUnavailable::InvalidSourceReference)?;
                    self.executing_views.push(execution);
                    self.frames.push(Frame::RootCompReturn { execution });
                }
                self.execute_with_substitution(received.value, site, received.dispatch)?;
            }
        }
        Ok(())
    }
    fn begin_local(
        &mut self,
        block: Arc<Code>,
        ordinal: usize,
        mut environment: usize,
    ) -> Result<(), RuntimeUnavailable> {
        let (binding, final_expression) = match &block.instruction {
            Instruction::Block { bindings, final_expression } => (bindings.get(ordinal).cloned(), *final_expression),
            Instruction::StatementBlock { statements, final_expression } => match statements.get(ordinal) {
                Some(BlockStatement::Expression(expression)) => {
                    let code = *expression;
                    self.frames.push(Frame::BlockExpression { block, next: ordinal + 1, environment });
                    self.state = State::Evaluate { code, environment };
                    return Ok(());
                }
                Some(BlockStatement::Binding(binding)) => (Some(binding.clone()), *final_expression),
                None => (None, *final_expression),
            },
            _ => return Err(RuntimeUnavailable::InvalidSourceReference),
        };
        if let Some(binding) = binding {
            let initializer = binding.initializer;
            let recursive = binding.recursive;
            let cell = self.cells.len();
            self.cells.push(None);
            if recursive {
                environment = self.extend(environment, Binder::Local(binding.id.clone()), cell);
            }
            self.frames.push(Frame::Local {
                block,
                next: ordinal + 1,
                environment,
                cell,
                recursive,
            });
            let environment = self.initializer_environment(cell, environment)?;
            self.state = State::Evaluate {
                code: initializer,
                environment,
            };
        } else {
            self.state = State::Evaluate {
                code: final_expression,
                environment,
            };
        }
        Ok(())
    }
    fn execute(&mut self, value: ValueHandle, site: &SourceSite) -> Result<(), RuntimeUnavailable> {
        self.execute_with_substitution(value, site, None)
    }
    fn execute_with_substitution(&mut self, value: ValueHandle, site: &SourceSite,
        substitution: Option<usize>) -> Result<(), RuntimeUnavailable> {
        match self.executables.get(&value.0).cloned() {
            Some(ExecutableValue::Delay { code, environment }) => {
                let environment = self.substitute_environment(environment, substitution)?;
                self.state = State::Evaluate { code, environment };
                Ok(())
            }
            Some(ExecutableValue::Request {
                declaration,
                mut payload,
                source,
            }) => {
                payload.dispatch = self.dispatch.then(payload.dispatch, substitution)?;
                let event = self.next_request;
                self.next_request = event
                    .checked_add(1)
                    .ok_or(RuntimeUnavailable::IdentityExhausted)?;
                let observations = self.receiving.observe(event, &self.executing_views)
                    .ok_or(RuntimeUnavailable::IdentityExhausted)?;
                #[cfg(test)]
                {
                    let callback_use = self.executing_views.iter().rev().find_map(|view|
                        self.receiving.hygiene_callback_use_for_execution(view));
                    let executions = self.receiving.hygiene_observations(&observations)
                        .unwrap_or_default()
                        .into_iter()
                        .map(|(event, view, receipt, occurrence, owner, slot, formal)| {
                            HygieneExecutionEvidence { event, view, receipt, occurrence, owner, slot, formal }
                        })
                        .collect();
                    let continuation = self.hygiene_trace.active_continuations.last().map(|(template, _)| *template);
                    self.hygiene_trace.record(HygieneObservation::Request {
                        event,
                        owner: self.current_execution_owner(),
                        source: source.clone(),
                        carrier: value,
                        operation: declaration.id.clone(),
                        payload: payload.value,
                        payload_view: payload.view,
                        callback_use,
                        executions,
                        continuation,
                    });
                }
                self.state = State::Request(PendingRequest {
                    declaration,
                    payload,
                    source,
                    event,
                    observations,
                    suffix: Vec::new(),
                });
                Ok(())
            }
            _ => Err(RuntimeUnavailable::ExpectedComputation(site.clone())),
        }
    }
    fn lookup(&self, mut environment: usize, matches: impl Fn(&Binder) -> bool) -> Option<usize> {
        loop {
            let frame = self.environments.get(environment)?;
            if let Some((candidate, cell)) = &frame.binder {
                if matches(candidate) {
                    return Some(*cell);
                }
            }
            environment = frame.parent?;
        }
    }
    fn with_dispatch(&mut self, parent: usize, dispatch: dispatch::State) -> usize {
        let environment = self.environments.len();
        self.environments.push(Environment { parent: Some(parent), binder: None, dispatch });
        environment
    }
    fn initializer_environment(&mut self, cell: usize, parent: usize) -> Result<usize, RuntimeUnavailable> {
        if self.program.dictionaries.is_none() { return Ok(parent); }
        let dispatch = self.dispatch.initializer(cell, self.environments[parent].dispatch)?;
        Ok(self.with_dispatch(parent, dispatch))
    }
    fn substitute_environment(&mut self, environment: usize, substitution: Option<usize>) -> Result<usize, RuntimeUnavailable> {
        if self.program.dictionaries.is_none() || substitution.is_none() { return Ok(environment); }
        let mut dispatch = self.environments[environment].dispatch;
        dispatch.substitution = self.dispatch.then(dispatch.substitution, substitution)?;
        Ok(self.with_dispatch(environment, dispatch))
    }
    fn dispatch_environment(&mut self, environment: usize, step: dispatch::Step) -> Result<usize, RuntimeUnavailable> {
        let mut dispatch = self.environments[environment].dispatch;
        dispatch.context = self.dispatch.append(dispatch.context, step)?;
        Ok(self.with_dispatch(environment, dispatch))
    }
    fn dispatch_name(&mut self, mut value: ReceivedValue, cell: usize, environment: usize,
        site: &SourceSite) -> Result<ReceivedValue, RuntimeUnavailable> {
        if self.program.dictionaries.is_none() { return Ok(value); }
        let key = dispatch::Site { owner: site.source_root.clone(), occurrence: site.occurrence.clone() };
        let instantiate = self.program.dictionary_names.contains(&key)
            .then_some(dispatch::Step { kind: dispatch::Kind::Name, site: key });
        value.dispatch = self.dispatch.name(value.dispatch, self.environments[environment].dispatch, cell, instantiate)?;
        Ok(value)
    }
    fn extend(&mut self, parent: usize, binder: Binder, cell: usize) -> usize {
        let index = self.environments.len();
        self.environments.push(Environment {
            parent: Some(parent),
            binder: Some((binder, cell)),
            dispatch: self.environments[parent].dispatch,
        });
        index
    }
    fn bind(&mut self, environment: usize, binder: Binder, value: ReceivedValue) -> usize {
        let cell = self.cells.len();
        self.cells.push(Some(value));
        self.extend(environment, binder, cell)
    }
    fn ground_data(
        &mut self,
        site: &SourceSite,
        kind: RuntimeValueKind,
        executable: Option<ExecutableValue>,
    ) {
        let value = self.allocate(site, kind, executable);
        let view = self.receiving.ground(value);
        self.state = State::Return(ReceivedValue {
            dispatch: None,
            value,
            interface: ParameterRole::Value,
            view,
        });
    }
    fn bind_record_parameter(&mut self, fields: Arc<[RecordParameterField]>, mut index: usize,
        argument: ReceivedValue, body: Label, mut environment: usize) -> Result<(), RuntimeUnavailable> {
        if !self.receiving.matches_value(argument.view, argument.value) {
            return Err(RuntimeUnavailable::InvalidSourceReference);
        }
        while index < fields.len() {
            let RuntimeValueKind::Record(actual) = &self.values[argument.value.0].kind else {
                return Err(RuntimeUnavailable::InvalidSourceReference);
            };
            let field = &fields[index];
            if let Some((_, actual)) = actual.iter().find(|(name, _)| name == &field.label) {
                let mut received = actual.received;
                received.view = self.receiving.project_record(argument.view, received.view, received.value)
                    .ok_or_else(|| RuntimeUnavailable::UnsupportedRecordPattern(self.values[argument.value.0].source.clone()))?;
                received.dispatch = self.dispatch.then(received.dispatch, argument.dispatch)?;
                received.interface = ParameterRole::Value;
                environment = self.bind(environment, Binder::Parameter(field.binder.clone()), received);
                index += 1;
            } else if let Some(default) = field.default {
                self.frames.push(Frame::RecordDefault { fields, index, argument, body, environment });
                self.state = State::Evaluate { code: default, environment };
                return Ok(());
            } else { return Err(RuntimeUnavailable::InvalidSourceReference); }
        }
        // Even an empty pattern requires an actual record.
        if !matches!(self.values[argument.value.0].kind, RuntimeValueKind::Record(_)) {
            return Err(RuntimeUnavailable::InvalidSourceReference);
        }
        self.state = State::Evaluate { code: body, environment };
        Ok(())
    }
    fn data(
        &mut self,
        site: &SourceSite,
        kind: RuntimeValueKind,
        executable: Option<ExecutableValue>,
    ) {
        let value = self.allocate(site, kind, executable);
        let view = self.receiving.opaque(value);
        self.state = State::Return(ReceivedValue {
            dispatch: None,
            value,
            interface: ParameterRole::Value,
            view,
        });
    }
    fn allocate(
        &mut self,
        site: &SourceSite,
        kind: RuntimeValueKind,
        executable: Option<ExecutableValue>,
    ) -> ValueHandle {
        let handle = ValueHandle(self.values.len());
        self.values.push(RuntimeValue {
            source: site.clone(),
            kind,
        });
        if let Some(executable) = executable {
            self.executables.insert(handle.0, executable);
        }
        handle
    }
}

impl Machine {
    fn advance_integer_product(&mut self, mut product: super::decimal::Product, site: SourceSite) -> Result<(), RuntimeUnavailable> {
        if product.advance() {
            let value = product.finish().ok_or(RuntimeUnavailable::InvalidSourceReference)?;
            self.ground_data(&site, RuntimeValueKind::Integer(value.into_boxed_str()), None);
        } else {
            self.state = State::IntegerProduct { product, site };
        }
        Ok(())
    }
}

fn pinned_primitive_arity(operation: &yu_hir::shadow::PinnedPrimitiveOp) -> Option<usize> {
    match operation {
        yu_hir::shadow::PinnedPrimitiveOp::IntToString
        | yu_hir::shadow::PinnedPrimitiveOp::BoolNot
        | yu_hir::shadow::PinnedPrimitiveOp::BoolToString => Some(1),
        yu_hir::shadow::PinnedPrimitiveOp::IntAdd
        | yu_hir::shadow::PinnedPrimitiveOp::IntSub
        | yu_hir::shadow::PinnedPrimitiveOp::IntMul
        | yu_hir::shadow::PinnedPrimitiveOp::IntEq
        | yu_hir::shadow::PinnedPrimitiveOp::IntLt
        | yu_hir::shadow::PinnedPrimitiveOp::IntLe
        | yu_hir::shadow::PinnedPrimitiveOp::IntGt
        | yu_hir::shadow::PinnedPrimitiveOp::IntGe
        | yu_hir::shadow::PinnedPrimitiveOp::BoolEq
        | yu_hir::shadow::PinnedPrimitiveOp::StringConcat => Some(2),
        yu_hir::shadow::PinnedPrimitiveOp::Unsupported(_) => None,
    }
}

fn pinned_primitive_apply(
    operation: &yu_hir::shadow::PinnedPrimitiveOp,
    arguments: &[ValueHandle],
    values: &[RuntimeValue],
) -> Option<RuntimeValueKind> {
    let argument = |index: usize| values.get(arguments.get(index)?.0).map(|value| &value.kind);
    match operation {
        yu_hir::shadow::PinnedPrimitiveOp::BoolNot => {
            let RuntimeValueKind::Boolean(value) = argument(0)? else { return None; };
            Some(RuntimeValueKind::Boolean(!*value))
        }
        yu_hir::shadow::PinnedPrimitiveOp::BoolEq => {
            let RuntimeValueKind::Boolean(left) = argument(0)? else { return None; };
            let RuntimeValueKind::Boolean(right) = argument(1)? else { return None; };
            Some(RuntimeValueKind::Boolean(*left == *right))
        }
        yu_hir::shadow::PinnedPrimitiveOp::BoolToString => {
            let RuntimeValueKind::Boolean(value) = argument(0)? else { return None; };
            let text = if *value { "true" } else { "false" };
            let mut result = String::new();
            result.try_reserve(text.len()).ok()?;
            result.push_str(text);
            Some(RuntimeValueKind::String(result.into_boxed_str()))
        }
        yu_hir::shadow::PinnedPrimitiveOp::IntAdd => {
            let RuntimeValueKind::Integer(left) = argument(0)? else { return None; };
            let RuntimeValueKind::Integer(right) = argument(1)? else { return None; };
            Some(RuntimeValueKind::Integer(decimal_add(left, right)?.into_boxed_str()))
        }
        yu_hir::shadow::PinnedPrimitiveOp::IntSub => {
            let RuntimeValueKind::Integer(left) = argument(0)? else { return None; };
            let RuntimeValueKind::Integer(right) = argument(1)? else { return None; };
            let negative = super::decimal::negate(right)?;
            Some(RuntimeValueKind::Integer(decimal_add(left, &negative)?.into_boxed_str()))
        }
        yu_hir::shadow::PinnedPrimitiveOp::IntEq
        | yu_hir::shadow::PinnedPrimitiveOp::IntLt
        | yu_hir::shadow::PinnedPrimitiveOp::IntLe
        | yu_hir::shadow::PinnedPrimitiveOp::IntGt
        | yu_hir::shadow::PinnedPrimitiveOp::IntGe => {
            let RuntimeValueKind::Integer(left) = argument(0)? else { return None; };
            let RuntimeValueKind::Integer(right) = argument(1)? else { return None; };
            let ordering = super::decimal::compare(left, right)?;
            let result = match operation {
                yu_hir::shadow::PinnedPrimitiveOp::IntEq => ordering.is_eq(),
                yu_hir::shadow::PinnedPrimitiveOp::IntLt => ordering.is_lt(),
                yu_hir::shadow::PinnedPrimitiveOp::IntLe => !ordering.is_gt(),
                yu_hir::shadow::PinnedPrimitiveOp::IntGt => ordering.is_gt(),
                yu_hir::shadow::PinnedPrimitiveOp::IntGe => !ordering.is_lt(),
                _ => return None,
            };
            Some(RuntimeValueKind::Boolean(result))
        }
        // Multiplication uses the resumable Machine state above.
        yu_hir::shadow::PinnedPrimitiveOp::IntMul => None,
        yu_hir::shadow::PinnedPrimitiveOp::IntToString => {
            let RuntimeValueKind::Integer(value) = argument(0)? else { return None; };
            Some(RuntimeValueKind::String(value.clone()))
        }
        yu_hir::shadow::PinnedPrimitiveOp::StringConcat => {
            let RuntimeValueKind::String(left) = argument(0)? else { return None; };
            let RuntimeValueKind::String(right) = argument(1)? else { return None; };
            let mut result = String::new();
            result.try_reserve(left.len().checked_add(right.len())?).ok()?;
            result.push_str(left);
            result.push_str(right);
            Some(RuntimeValueKind::String(result.into_boxed_str()))
        }
        yu_hir::shadow::PinnedPrimitiveOp::Unsupported(_) => None,
    }
}

fn decimal_add(left: &str, right: &str) -> Option<String> {
    fn signed(negative: bool, digits: String) -> Option<String> {
        if !negative || digits == "0" { return Some(digits); }
        let mut output = String::new();
        output.try_reserve(digits.len().checked_add(1)?).ok()?;
        output.push('-');
        output.push_str(&digits);
        Some(output)
    }
    fn split(value: &str) -> Option<(bool, &str)> {
        let (negative, digits) = value.strip_prefix('-').map_or((false, value), |digits| (true, digits));
        if digits.is_empty() || !digits.bytes().all(|byte| byte.is_ascii_digit()) { return None; }
        let digits = digits.trim_start_matches('0');
        Some((negative, if digits.is_empty() { "0" } else { digits }))
    }
    fn add_magnitude(left: &str, right: &str) -> Option<String> {
        let width = left.len().max(right.len());
        let mut output = Vec::new();
        output.try_reserve(width.checked_add(1)?).ok()?;
        let (mut carry, mut index) = (0u8, 0usize);
        while index < width || carry != 0 {
            let a = left.len().checked_sub(index + 1).and_then(|at| left.as_bytes().get(at)).copied().map_or(0, |b| b - b'0');
            let b = right.len().checked_sub(index + 1).and_then(|at| right.as_bytes().get(at)).copied().map_or(0, |b| b - b'0');
            let sum = a + b + carry;
            output.push(b'0' + sum % 10);
            carry = sum / 10;
            index += 1;
        }
        output.reverse();
        String::from_utf8(output).ok()
    }
    fn compare_magnitude(left: &str, right: &str) -> std::cmp::Ordering {
        left.len().cmp(&right.len()).then_with(|| left.cmp(right))
    }
    fn subtract_magnitude(larger: &str, smaller: &str) -> Option<String> {
        let mut output = Vec::new();
        output.try_reserve(larger.len()).ok()?;
        let (mut borrow, mut index) = (0i16, 0usize);
        while index < larger.len() {
            let a = i16::from(*larger.as_bytes().get(larger.len() - index - 1)? - b'0');
            let b = i16::from(smaller.len().checked_sub(index + 1).and_then(|at| smaller.as_bytes().get(at)).copied().map_or(0, |digit| digit - b'0'));
            let mut digit = a - borrow - b;
            borrow = i16::from(digit < 0);
            if borrow != 0 { digit += 10; }
            output.push(b'0' + digit as u8);
            index += 1;
        }
        while output.len() > 1 && output.last() == Some(&b'0') { output.pop(); }
        output.reverse();
        String::from_utf8(output).ok()
    }
    let (left_negative, left) = split(left)?;
    let (right_negative, right) = split(right)?;
    if left_negative == right_negative {
        let sum = add_magnitude(left, right)?;
        signed(left_negative, sum)
    } else {
        match compare_magnitude(left, right) {
            std::cmp::Ordering::Equal => Some("0".to_owned()),
            std::cmp::Ordering::Greater => {
                let difference = subtract_magnitude(left, right)?;
                signed(left_negative, difference)
            }
            std::cmp::Ordering::Less => {
                let difference = subtract_magnitude(right, left)?;
                signed(right_negative, difference)
            }
        }
    }
}

#[cfg(test)]
mod module_expression_tests {
    use super::*;
    use yu_hir::{FileId, FileKey, ModuleIdentity, SemanticImports, lower_module};
    use yu_syntax::{SourceText, SyntaxEnvironment, parse_file, scan_header};

    const CALLBACK_SOURCE: &str = "act signal:\n    our ping: () -> int\n\nmy relay(cb: () -> [signal] int) = catch cb() {\n    signal::ping(), _ -> 1,\n    v -> v\n}\nmy answer = relay signal::ping\n";

    fn runtime_program(source: &str, opt_in_source: bool) -> Arc<RuntimeProgram> {
        let source: Arc<SourceText> = Arc::from(source);
        let parsed = parse_file(
            source.clone(),
            Arc::new(scan_header(source)),
            Arc::new(SyntaxEnvironment::empty()),
        );
        assert!(parsed.syntax_diagnostics().unwrap().is_empty());
        let lower = if opt_in_source {
            yu_hir::shadow::lower_module_with_local_source
        } else {
            lower_module
        };
        let hir = Arc::new(
            lower(
                ModuleIdentity::source_root(FileId::new(FileKey::new("runtime-roots", "test.yu"))),
                &parsed,
                SemanticImports::empty(),
            )
            .unwrap(),
        );
        RuntimeProgram::from_hir(hir, super::super::RuntimeEvidence::default()).unwrap()
    }

    fn start(program: &Arc<RuntimeProgram>) -> Machine {
        let definition = program.definition_named("main").unwrap().clone();
        let roots = program.execution_roots().unwrap();
        program.start(&definition, &roots).unwrap()
    }

    fn machine(source: &str, opt_in_source: bool) -> Machine {
        start(&runtime_program(source, opt_in_source))
    }

    fn cache_snapshot(
        machine: &Machine,
    ) -> Vec<Option<(ValueHandle, ParameterRole, ViewHandle)>> {
        machine
            .cells
            .iter()
            .map(|cell| {
                cell.as_ref().map(|received| {
                    (received.value, received.interface, received.view)
                })
            })
            .collect()
    }

    fn integer_count(machine: &Machine, expected: &str) -> usize {
        machine
            .values
            .iter()
            .filter(|value| {
                matches!(
                    &value.kind,
                    RuntimeValueKind::Integer(text) if text.as_ref() == expected
                )
            })
            .count()
    }

    #[test]
    fn variant_native_matching_checks_tag_arity_order_and_original_binders() {
        for (source, expected) in [
            ("my main = case :disabled: :disabled -> 7, _ -> 0", "7"),
            ("my main = case :pair(1,2): :other(x,y) -> 99, :pair(x) -> 98, :pair(left,right) -> right", "2"),
            ("my main = case :pair(1,2): :pair(_,right) -> right, :pair(left,_) -> left", "2"),
            ("my main = case :wrap (\\x -> x): :wrap f -> f 7", "7"),
            ("my main = case :disabled(): :disabled -> 99, :disabled _ -> 7", "7"),
            ("my main = case :other 3: :pair x -> x, _ -> 7", "7"),
        ] {
            let mut machine = machine(source, true);
            assert!(!machine.program.closed_primitive, "new shapes confer no old negative-visibility certificate");
            let RuntimeOutcome::Completed(value) = machine.run(10_000) else { panic!("variant native source: {source}"); };
            assert!(matches!(&machine.value(value).unwrap().kind,
                RuntimeValueKind::Integer(value) if value.as_ref() == expected), "{source}");
        }
        for source in [
            "my main = case :some 1: :none -> 0",
            "my main = case :pair(1,2): :pair x -> x",
        ] {
            assert!(matches!(machine(source, true).run(10_000),
                RuntimeOutcome::Unavailable(RuntimeUnavailable::NonExhaustiveCase(_))), "{source}");
        }
    }

    #[test]
    fn variant_result_rendering_keeps_tag_and_payload_arity() {
        for (expression, expected) in [
            (":disabled", ":disabled"),
            (":disabled()", ":disabled(())"),
            (":pair(41,23)", ":pair(41, 23)"),
        ] {
            let mut machine = machine(&format!("my main = {expression}"), true);
            let RuntimeOutcome::Completed(value) = machine.run(10_000) else { panic!("variant result"); };
            let mut output = crate::Output::new();
            crate::render_runtime_value(&machine, value, &mut output).unwrap();
            assert_eq!(output.finish().unwrap(), expected);
        }
    }

    #[test]
    fn variant_payload_projection_preserves_the_received_values_and_views() {
        let mut machine = machine("my main = case :pair(1,2): :pair(left,right) -> (right,left)", true);
        let RuntimeOutcome::Completed(value) = machine.run(10_000) else { panic!("variant projection"); };
        let RuntimeValueKind::Tuple(result) = &machine.value(value).unwrap().kind else { panic!("projected tuple"); };
        let payloads = machine.values.iter().find_map(|value| match &value.kind {
            RuntimeValueKind::Variant { tag, payloads } if tag.as_ref() == "pair" => Some(payloads), _ => None,
        }).unwrap();
        for (output, input) in result.iter().zip(payloads.iter().rev()) {
            assert_eq!(output.received.value, input.received.value);
            assert_eq!(output.received.view, input.received.view);
            assert_eq!(output.received.interface, input.received.interface);
            assert!(machine.receiving.matches_value(output.received.view, output.received.value));
        }
    }

    #[test]
    fn variant_prefix_survives_repeated_raw_resumption_without_replaying_children() {
        let source = "act io:\n    our tick: int -> int\nmy relay (thunk:[io] 'a) = catch thunk { io::tick(p), k -> { k 11; k 23 } }\nmy main = relay (:pair(41, io::tick 0))";
        let mut machine = machine(source, true);
        let mut completed = None;
        for _ in 0..10_000 {
            match machine.run(1) {
                RuntimeOutcome::Running | RuntimeOutcome::ResourceExhausted { .. } => {},
                RuntimeOutcome::Completed(value) => { completed = Some(value); break; },
                other => panic!("variant resume: {other:?}"),
            }
        }
        let RuntimeValueKind::Variant { tag, payloads } = &machine.value(completed.expect("variant completion")).unwrap().kind else { panic!("tagged result"); };
        assert_eq!(tag.as_ref(), "pair");
        assert_eq!(payloads.len(), 2);
        for (payload, expected) in payloads.iter().zip(["41", "23"]) {
            assert!(matches!(&machine.value(payload.value()).unwrap().kind,
                RuntimeValueKind::Integer(value) if value.as_ref() == expected));
            assert!(machine.receiving.matches_value(payload.received.view, payload.received.value));
        }
        assert_eq!(integer_count(&machine, "41"), 1, "the captured prefix is reused by both resumes");
    }

    #[test]
    fn primitive_value_entry_creates_each_invocation_before_forcing_the_argument() {
        let mut machine = machine("my main = builtin_op::int_add 1 2", true);
        let mut entries = Vec::new();
        let mut completed = None;
        for _ in 0..200 {
            if let Some(Frame::PrimitiveArgument { site, .. }) = machine.frames.last() {
                let Frame::ReceiverReturn { activation, previous } = &machine.frames[machine.frames.len() - 2] else { panic!("primitive invocation return"); };
                assert_eq!(machine.current_owner, ExecutionOwner::Invocation(*activation));
                assert_eq!(*previous, ExecutionOwner::ModuleRun);
                let invocation = &machine.invocations[*activation];
                assert!(invocation.active);
                assert_eq!(invocation.call.source_root, site.source_root);
                assert_eq!(invocation.call.occurrence, site.occurrence);
                if !entries.contains(activation) {
                    assert!(matches!(machine.state, State::Evaluate { .. }), "whole argument enters only after the receiver is live");
                    entries.push(*activation);
                }
            }
            match machine.run(1) {
                RuntimeOutcome::Running | RuntimeOutcome::ResourceExhausted { .. } => {},
                RuntimeOutcome::Completed(value) => { completed = Some(value); break; },
                other => panic!("primitive entry: {other:?}"),
            }
        }
        assert_eq!(entries, [0, 1], "curried calls have separate actual owners");
        assert!(machine.invocations.iter().all(|invocation| !invocation.active));
        assert!(machine.active_receivers.is_empty());
        assert_eq!(machine.current_owner, ExecutionOwner::ModuleRun);
        assert!(matches!(&machine.value(completed.expect("completion")).unwrap().kind,
            RuntimeValueKind::Integer(value) if value.as_ref() == "3"));
    }

    #[test]
    fn integer_product_budget_pause_preserves_the_live_machine() {
        let mut machine = machine("my main = builtin_op::int_mul 12345678901234567890 12345678901234567890", true);
        for _ in 0..100 {
            if matches!(machine.state, State::IntegerProduct { .. }) { break; }
            assert!(matches!(machine.run(1), RuntimeOutcome::ResourceExhausted { .. }));
        }
        assert!(matches!(machine.state, State::IntegerProduct { .. }));
        let before_steps = machine.steps();
        let before_values = machine.values.len();
        let before_frames = machine.frames.len();
        let before_cells = cache_snapshot(&machine);
        assert!(matches!(machine.run(7), RuntimeOutcome::ResourceExhausted { .. }));
        assert_eq!(machine.steps(), before_steps + 7);
        assert_eq!(machine.values.len(), before_values, "no partial product becomes a value");
        assert_eq!(machine.frames.len(), before_frames);
        assert_eq!(cache_snapshot(&machine), before_cells);
        assert!(matches!(machine.state, State::IntegerProduct { .. }));
        let RuntimeOutcome::Completed(value) = machine.run(1000) else { panic!("resumed product"); };
        assert!(matches!(&machine.value(value).unwrap().kind,
            RuntimeValueKind::Integer(value) if value.as_ref() == "152415787532388367501905199875019052100"));
    }

    #[test]
    fn tuple_elements_retain_their_received_views() {
        let mut machine = machine("my main = (1, 2)", true);
        let RuntimeOutcome::Completed(tuple) = machine.run(100) else {
            panic!("expected tuple completion")
        };
        let RuntimeValueKind::Tuple(elements) = &machine.value(tuple).unwrap().kind else {
            panic!("expected tuple value")
        };
        assert_eq!(elements.len(), 2);
        for element in elements {
            assert_eq!(element.received.interface, ParameterRole::Value);
            assert!(machine.receiving.matches_value(
                element.received.view,
                element.received.value
            ));
        }
    }

    #[test]
    fn computation_completion_preserves_the_actual_result_record() {
        for (source, minimum_returns) in [
            ("my relay (thunk:[] 'a) = thunk\nmy main = relay (7, \\x -> x)\n", 1),
            ("my relay (thunk:[] (int -> int)) = thunk\nmy main = relay (\\x -> x)\n", 1),
            ("my relay (thunk:[] 'a) = thunk\nmy forward (input:[] 'b) = relay input\nmy main = forward (\\x -> x)\n", 2),
            ("act io:\n    our tick: int -> int\nmy relay (thunk:[io] 'a) = catch thunk { io::tick(p), k -> { my first = k 11; k 23 } }\nmy main = relay { my x = io::tick 0; (x, \\u -> u) }\n", 2),
        ] {
            let mut machine = machine(source, true);
            let mut returns = 0;
            let mut executions = HashSet::new();
            let mut completed = false;
            for _ in 0..2000 {
                let before = match (&machine.state, machine.frames.last()) {
                    (State::Return(value), Some(Frame::RootCompReturn { execution })) =>
                        Some((*value, *execution, machine.executing_views.len())),
                    _ => None,
                };
                let outcome = machine.step();
                if let Some((before, execution, depth)) = before {
                    assert!(matches!(outcome, RuntimeOutcome::Running), "{source}: {outcome:?}");
                    let State::Return(after) = machine.state else { panic!("completion returns the actual record"); };
                    assert_eq!((after.value, after.interface, after.view, after.dispatch),
                        (before.value, before.interface, before.view, before.dispatch),
                        "completion cannot replace unknown/result evidence with a ground view");
                    assert!(machine.receiving.matches_value(after.view, after.value));
                    assert_eq!(machine.executing_views.len() + 1, depth);
                    assert!(executions.insert(execution.occurrence), "each execution closes once");
                    returns += 1;
                }
                match outcome {
                    RuntimeOutcome::Running => {},
                    RuntimeOutcome::Completed(_) => { completed = true; break; },
                    other => panic!("{source}: {other:?}"),
                }
            }
            assert!(completed, "{source}");
            assert!(returns >= minimum_returns, "{source}: {returns}");
            assert!(machine.executing_views.is_empty());
            assert!(machine.initializing_globals.is_empty());
        }
    }

    #[test]
    fn pinned_primitive_values_execute_with_currying_and_arbitrary_precision() {
        let mut add = machine("my main = builtin_op::int_add 999999999999999999999999999999 1", true);
        let outcome = add.run(100);
        assert_completed_integer(&add, outcome, "1000000000000000000000000000000");

        let mut format = machine(
            "my main = builtin_op::string_concat (builtin_op::int_to_string 42) \"!\"",
            true,
        );
        let RuntimeOutcome::Completed(value) = format.run(100) else { panic!("expected primitive string result") };
        assert!(matches!(format.value(value).map(|value| &value.kind), Some(RuntimeValueKind::String(text)) if text.as_ref() == "42!"));
        assert_eq!(decimal_add("-1000", "1").as_deref(), Some("-999"));
        assert_eq!(decimal_add("001", "-1").as_deref(), Some("0"));
    }

    fn assert_completed_integer(machine: &Machine, outcome: RuntimeOutcome, expected: &str) {
        let RuntimeOutcome::Completed(handle) = outcome else {
            panic!("expected completion with integer {expected}, got {outcome:?}");
        };
        assert!(matches!(
            machine.value(handle).map(|value| &value.kind),
            Some(RuntimeValueKind::Integer(text)) if text.as_ref() == expected
        ));
    }

    #[test]
    fn expression_roots_allocate_no_global_cells_or_initialization_markers() {
        let mut machine = machine(
            "later; 99; my later = { my value = 11; value }; later; my main = 7",
            false,
        );
        assert_eq!(machine.cells.len(), 2);
        assert_eq!(machine.program.definition_indices.len(), 2);
        assert!(machine.initializing_globals.is_empty());
        assert!(matches!(
            machine.frames.last(),
            Some(Frame::ExpressionReturn { .. })
        ));
        assert!(matches!(machine.run(10_000), RuntimeOutcome::Completed(_)));
        // One local initializer value, despite a forward Name demand and the
        // definition's later scheduled slot. Expressions publish no cells.
        assert_eq!(
            machine
                .values
                .iter()
                .filter(|value| matches!(
                    &value.kind, RuntimeValueKind::Integer(text) if text.as_ref() == "11"
                ))
                .count(),
            1
        );
        assert_eq!(machine.cells.len(), 3); // Two globals and the actual local.
        assert!(machine.initializing_globals.is_empty());
    }

    #[test]
    fn shared_program_machines_keep_module_root_caches_and_progress_private() {
        let program = runtime_program(
            "later; 99; my later = { my value = 11; value }; later; my main = 7",
            false,
        );
        let mut first = start(&program);
        let mut second = start(&program);
        assert!(Arc::ptr_eq(&first.program, &second.program));

        assert!(matches!(first.step(), RuntimeOutcome::Running));
        let first_steps = first.steps();
        let first_cells = cache_snapshot(&first);
        let first_frame_depth = first.frames.len();

        let second_outcome = second.run(10_000);
        assert_completed_integer(&second, second_outcome, "7");
        assert_eq!(first.steps(), first_steps);
        assert_eq!(cache_snapshot(&first), first_cells);
        assert_eq!(first.frames.len(), first_frame_depth);

        let first_outcome = first.run(10_000);
        assert_completed_integer(&first, first_outcome, "7");
        assert_eq!(first.steps(), second.steps());
        assert_eq!(integer_count(&first, "11"), 1);
        assert_eq!(integer_count(&second, "11"), 1);

        let third = start(&program);
        assert!(Arc::ptr_eq(&first.program, &third.program));
        assert!(third.cells.iter().all(Option::is_none));
        assert_eq!(third.steps(), 0);
    }

    #[test]
    fn initializer_stop_retains_the_cache_write_and_live_caller_prefix() {
        // A low-level boundary reproduction, without a claim about source
        // initialization order or resumed cache publication.
        let mut machine = machine(
            "act io:\n    our tick: int -> int\nmy relay (thunk:[io] int) = catch thunk { io::tick(p), k -> k p }\nmy main = relay later\nmy later = io::tick 7",
            true,
        );
        for _ in 0..10_000 {
            if matches!(machine.state, State::Request(_))
                && matches!(machine.frames.last(), Some(Frame::GlobalRead { .. }))
            {
                break;
            }
            assert!(matches!(machine.step(), RuntimeOutcome::Running));
        }
        let State::Request(request) = &machine.state else {
            panic!("pending request");
        };
        let expected_source = request.source.clone();
        let expected_operation = request.declaration.id.clone();
        let expected_event = request.event;
        let expected_payload = request.payload.value;
        let suffix_len = request.suffix.len();
        let observations_len = request.observations.len();
        let Frame::GlobalRead { cell, .. } = machine.frames.last().unwrap() else {
            panic!("cache write");
        };
        let cell = *cell;
        assert!(machine.cells[cell].is_none());
        assert!(machine.initializing_globals.contains(&cell));
        assert!(
            machine
                .frames
                .iter()
                .any(|frame| matches!(frame, Frame::CatchReturn { .. }))
        );
        let frames_len = machine.frames.len();
        let caller_handlers: Vec<_> = machine
            .frames
            .iter()
            .enumerate()
            .filter_map(|(index, frame)| {
                if let Frame::CatchReturn { installation, .. } = frame {
                    Some((index, *installation))
                } else {
                    None
                }
            })
            .collect();
        let markers = machine.initializing_globals.clone();
        let owner = machine.current_owner;
        let active = machine.active_receivers.clone();
        let invocation_activity: Vec<_> = machine
            .invocations
            .iter()
            .map(|invocation| invocation.active)
            .collect();
        let views: Vec<_> = machine
            .executing_views
            .iter()
            .map(|view| (view.view, view.receipt, view.occurrence))
            .collect();
        let templates_len = machine.resume_templates.len();
        let values_len = machine.values.len();
        let RuntimeOutcome::UnhandledRequest {
            source,
            operation,
            event,
            payload,
            continuation,
        } = machine.step()
        else {
            panic!("initializer boundary must stop before caller selection");
        };
        assert_eq!(source.source_root, expected_source.source_root);
        assert_eq!(source.occurrence, expected_source.occurrence);
        assert_eq!(source.range, expected_source.range);
        assert_eq!(operation, expected_operation);
        assert_eq!(event, expected_event);
        assert_eq!(payload, expected_payload);
        assert_eq!(machine.frames.len(), frames_len);
        assert!(
            matches!(machine.frames.last(), Some(Frame::GlobalRead { cell: retained, .. }) if *retained == cell)
        );
        assert!(
            machine
                .frames
                .iter()
                .any(|frame| matches!(frame, Frame::CatchReturn { .. }))
        );
        assert_eq!(
            machine
                .frames
                .iter()
                .enumerate()
                .filter_map(|(index, frame)| {
                    if let Frame::CatchReturn { installation, .. } = frame {
                        Some((index, *installation))
                    } else {
                        None
                    }
                })
                .collect::<Vec<_>>(),
            caller_handlers
        );
        assert_eq!(machine.initializing_globals, markers);
        assert!(machine.cells[cell].is_none());
        assert_eq!(machine.current_owner, owner);
        assert_eq!(machine.active_receivers, active);
        assert_eq!(
            machine
                .invocations
                .iter()
                .map(|invocation| invocation.active)
                .collect::<Vec<_>>(),
            invocation_activity
        );
        assert_eq!(
            machine
                .executing_views
                .iter()
                .map(|view| (view.view, view.receipt, view.occurrence))
                .collect::<Vec<_>>(),
            views
        );
        assert_eq!(
            machine.resume_templates.len(),
            templates_len,
            "caller raw binder is never captured"
        );
        assert_eq!(
            machine.values.len(),
            values_len,
            "no continuation value is published"
        );
        let saved = &machine.continuations[continuation.0];
        assert_eq!(saved.frames.len(), suffix_len);
        assert_eq!(saved.observations.len(), observations_len);
        assert!(
            !saved
                .frames
                .iter()
                .any(|frame| matches!(frame, SavedFrame::Ordinary(Frame::GlobalRead { .. })))
        );
    }

    #[test]
    fn scheduled_initializer_host_writes_keep_one_live_publication_frame() {
        let source = "my main = { my emit x = say x; my first = emit (3, \"text\"); my second = println \"second\"; 7 }\nprintln \"after\"\n";
        let (hir, candidate, world, indexes) = crate::prepare_with_world(
            source, "scheduled-host-write.yu", false,
        ).unwrap();
        let program = RuntimeProgram::from_candidate_world(hir, world, &indexes, &candidate).unwrap();
        let definition = program.definition_named("main").unwrap();
        let cell = program.definition_indices[definition];
        let mut machine = program.start_source_schedule(definition).unwrap();
        for (ordinal, expected) in ["(3, text)\n", "second\n", "after\n"].into_iter().enumerate() {
            let outcome = machine.run(100_000);
            let RuntimeOutcome::UnhandledRequest { operation, continuation, .. } = outcome else {
                panic!("expected authenticated host write {ordinal}, got {outcome:?}");
            };
            assert_eq!(program.host_write_operation(), Some(&operation));
            if ordinal < 2 {
                assert!(machine.cells[cell].is_none());
                assert!(machine.initializing_globals.contains(&cell));
                assert_eq!(machine.frames.iter().filter(|frame|
                    matches!(frame, Frame::Root { cell: actual, .. } if *actual == cell)).count(), 1);
            } else {
                assert!(machine.cells[cell].is_some());
                assert!(!machine.initializing_globals.contains(&cell));
            }
            let saved = &machine.continuations[continuation.0];
            assert!(!saved.frames.iter().any(|frame|
                matches!(frame, SavedFrame::Ordinary(Frame::Root { .. } | Frame::GlobalRead { .. }
                    | Frame::ExpressionReturn { .. }))));
            let template = &machine.resume_templates[saved.template.unwrap().0];
            assert!(!template.nodes.iter().any(|node| matches!(node,
                TemplateNode::Bind { frame: Frame::Root { .. } | Frame::GlobalRead { .. }
                    | Frame::ExpressionReturn { .. }, .. })));
            assert_eq!(machine.resume_host_write(continuation, &operation).unwrap().as_ref(), expected);
            assert!(machine.resume_host_write(continuation, &operation).is_err(),
                "the external handle cannot publish a second response");
        }
        let outcome = machine.run(100_000);
        assert_completed_integer(&machine, outcome, "7");
        let cached = machine.cells[cell].unwrap().value;
        assert!(matches!(machine.state_outcome(), Some(RuntimeOutcome::Completed(value)) if *value == cached));
        assert_eq!(integer_count(&machine, "7"), 1);
        assert!(machine.initializing_globals.is_empty());
        assert!(machine.frames.is_empty());
    }

    #[test]
    fn mixed_statement_host_writes_preserve_one_initializer_publication() {
        let source = "my main = { println \"first\"; my ignored = println \"second\"; 7 }\nprintln \"after\"\n";
        let (hir, candidate, world, indexes) = crate::prepare_with_world(source, "mixed-host.yu", false).unwrap();
        let program = RuntimeProgram::from_candidate_world(hir, world, &indexes, &candidate).unwrap();
        let definition = program.definition_named("main").unwrap();
        let cell = program.definition_indices[definition];
        let mut machine = program.start_source_schedule(definition).unwrap();
        for (ordinal, expected) in ["first\n", "second\n", "after\n"].into_iter().enumerate() {
            let outcome = machine.run(100_000);
            let RuntimeOutcome::UnhandledRequest { operation, continuation, .. } = outcome else { panic!("{outcome:?}"); };
            assert_eq!(machine.cells[cell].is_some(), ordinal == 2);
            assert_eq!(machine.initializing_globals.contains(&cell), ordinal != 2);
            if ordinal < 2 {
                assert_eq!(machine.frames.iter().filter(|frame|
                    matches!(frame, Frame::Root { cell: actual, .. } if *actual == cell)).count(), 1);
            }
            assert_eq!(machine.resume_host_write(continuation, &operation).unwrap().as_ref(), expected);
        }
        let outcome = machine.run(100_000);
        assert_completed_integer(&machine, outcome, "7");
        assert_eq!(integer_count(&machine, "7"), 1);
        assert!(machine.frames.is_empty());
        assert!(machine.initializing_globals.is_empty());
    }

    #[test]
    fn mixed_statement_resumption_keeps_completed_prefix_outside_template() {
        let source = "act io:\n    our tick: int -> int\nmy relay (thunk:[io] int) = catch thunk { io::tick(p), k -> { k 11; k 23 } }\nmy main = relay { 99; io::tick 0; my x = 7; x }\n";
        let mut machine = machine(source, true);
        let outcome = machine.run(100_000);
        assert_completed_integer(&machine, outcome, "7");
        assert_eq!(integer_count(&machine, "99"), 1, "completed prefix is not in either resumed suffix");
        assert_eq!(integer_count(&machine, "7"), 2, "the suffix initializer runs separately for each continuation invocation");
        assert_eq!(machine.cells.iter().flatten().filter(|value|
            matches!(&machine.values[value.value.0].kind, RuntimeValueKind::Integer(n) if n.as_ref() == "7")).count(), 3,
            "two distinct local publications and the final module result");
        assert!(machine.frames.is_empty());
        assert!(machine.initializing_globals.is_empty());
    }

    #[test]
    fn polymorphic_dictionary_reads_preserve_identity_and_initialize_once() {
        for source in [
            "my add = { my once = println \"init\"; \\x -> x + x }\nmy main = (add 3, add \"a\")\n",
            "my main = { my add = { my once = println \"init\"; \\x -> x + x }; (add 3, add \"a\") }\n",
        ] {
            let (hir, candidate, world, indexes) = crate::prepare_with_world(
                source, "dictionary-initializer.yu", false,
            ).unwrap();
            let program = RuntimeProgram::from_candidate_world(hir, world, &indexes, &candidate).unwrap();
            assert!(program.dictionaries.is_some());
            let definition = program.definition_named("main").unwrap();
            let mut machine = program.start_source_schedule(definition).unwrap();
            let mut writes = 0;
            let mut identity_checks = 0;
            let mut steps = 0;
            let result = loop {
                steps += 1;
                assert!(steps <= 100_000, "source run must stay within its step budget");
                // Observe actual source Name transitions at already published
                // polymorphic cells, including their receiving view identity.
                if let State::Evaluate { code, environment } = &machine.state {
                    let code = &program.code[code.0];
                    let site = &code.site;
                    let key = dispatch::Site { owner: site.source_root.clone(), occurrence: site.occurrence.clone() };
                    if program.dictionary_names.contains(&key) {
                        if let Instruction::Name { resolution, consumption: NameConsumption::Observe } = &code.instruction {
                            let cell = match resolution {
                                LocalSourceResolution::ModuleDef(id) => program.definition_indices.get(id).copied(),
                                LocalSourceResolution::Local(id) => machine.lookup(*environment, |binder|
                                    matches!(binder, Binder::Local(candidate) if candidate == id)),
                                _ => panic!("dictionary Name must refer to an initialized binding"),
                            }.unwrap();
                            if let Some(before) = machine.cells[cell] {
                                assert!(matches!(machine.step(), RuntimeOutcome::Running));
                                let State::Return(after) = machine.state else { panic!("Name must return its cached value"); };
                                assert_eq!(before.value, after.value);
                                assert_eq!(before.view, after.view);
                                assert_eq!(before.interface, after.interface);
                                assert_eq!(machine.cells[cell].unwrap().dispatch, before.dispatch);
                                assert!(after.dispatch.is_some());
                                identity_checks += 1;
                                continue;
                            }
                        }
                    }
                }
                match machine.step() {
                    RuntimeOutcome::Running => {}
                    RuntimeOutcome::UnhandledRequest { operation, continuation, .. } => {
                        writes += 1;
                        assert_eq!(program.host_write_operation(), Some(&operation));
                        assert_eq!(machine.resume_host_write(continuation, &operation).unwrap().as_ref(), "init\n");
                    }
                    RuntimeOutcome::Completed(result) => break result,
                    other => panic!("source={source:?}: {other:?}"),
                }
            };
            assert_eq!(writes, 1, "initializer is never repeated by dictionary instantiation");
            assert!(identity_checks >= 2);
            let RuntimeValueKind::Tuple(elements) = &machine.value(result).unwrap().kind else { panic!("tuple result"); };
            assert!(matches!(&machine.value(elements[0].received.value).unwrap().kind, RuntimeValueKind::Integer(n) if n.as_ref() == "6"));
            assert!(matches!(&machine.value(elements[1].received.value).unwrap().kind, RuntimeValueKind::String(s) if s.as_ref() == "aa"));
            assert!(machine.frames.is_empty());
            assert!(machine.initializing_globals.is_empty());
        }
    }

    #[test]
    fn missing_contextual_dictionary_never_uses_runtime_value_shapes() {
        let source = "my add x = x + x\nmy main = (add 3, add \"a\")\n";
        let (hir, candidate, world, indexes) = crate::prepare_with_world(
            source, "missing-dictionary.yu", false,
        ).unwrap();
        let mut program = RuntimeProgram::from_candidate_world(hir, world, &indexes, &candidate).unwrap();
        Arc::get_mut(&mut program).unwrap().dictionaries.as_mut().unwrap().clear();
        let definition = program.definition_named("main").unwrap();
        let mut machine = program.start_source_schedule(definition).unwrap();
        assert!(matches!(machine.run(100_000), RuntimeOutcome::Unavailable(RuntimeUnavailable::UnsupportedFieldTail(_))));
    }

    #[test]
    fn retained_abstract_member_instruction_cannot_dispatch_without_evidence() {
        let source = "my main = { my unused x = x.show; 7 }\n";
        let (hir, candidate, world, indexes) = crate::prepare_with_world(
            source, "abstract-member.yu", false,
        ).unwrap();
        assert!(matches!(RuntimeProgram::from_hir(hir.clone(), super::super::RuntimeEvidence::default()),
            Err(RuntimeUnavailable::UnsupportedFieldTail(_))),
            "missing arbitrary evidence still rejects program construction");
        let templates: Vec<_> = candidate.retained_field_tail_templates().unwrap().collect();
        let program = RuntimeProgram::from_candidate_world(hir, world, &indexes, &candidate).unwrap();
        let (label, instruction) = program.code.iter().enumerate().find(|(_, code)|
            matches!(code.instruction, Instruction::FieldTail { .. })).unwrap();
        let site = instruction.site.clone();
        assert!(templates.iter().any(|template|
            template.source_owner == &site.source_root && template.occurrence == &site.occurrence));
        let definition = program.definition_named("main").unwrap();
        let mut machine = program.start_source_schedule(definition).unwrap();
        // Adversarial private-state probe, not a claimed source execution:
        // force entry into the retained abstract body without a dictionary.
        machine.state = State::Evaluate { code: Label(label), environment: 0 };
        assert!(matches!(machine.step(), RuntimeOutcome::Unavailable(RuntimeUnavailable::UnsupportedFieldTail(actual))
            if actual.source_root == site.source_root && actual.occurrence == site.occurrence));
        assert!(machine.continuations.is_empty());
        assert!(machine.values.is_empty());
    }

    #[test]
    fn expression_handle_must_match_its_original_code_join() {
        let machine = machine("99; my main = 7", false);
        let program = &machine.program;
        let mut roots = program.execution_roots().unwrap();
        let ExecutionRoot::Expression(expression) = &mut roots[0] else {
            panic!("expression")
        };
        expression.code = program.definitions[0].body.0;
        assert!(matches!(
            program.start(program.definition_named("main").unwrap(), &roots),
            Err(RuntimeUnavailable::InvalidSourceReference)
        ));
    }

    #[test]
    fn internal_raw_templates_exclude_the_module_scheduler() {
        let mut machine = machine(
            "act io:\n    our tick: int -> int\nmy relay (thunk:[io] int) = catch thunk { io::tick(p), k -> { my first = k 11; k 23 } }; relay (io::tick 7); relay (io::tick 9); my main = 5",
            true,
        );
        assert!(matches!(machine.run(30_000), RuntimeOutcome::Completed(_)));
        assert_eq!(machine.resume_templates.len(), 2);
        for template in &machine.resume_templates {
            assert!(!template.nodes.iter().any(|node| matches!(
                node,
                TemplateNode::Bind {
                    frame: Frame::ExpressionReturn { .. } | Frame::Root { .. },
                    ..
                }
            )));
        }
        assert_eq!(
            machine
                .values
                .iter()
                .filter(|value| matches!(
                    &value.kind, RuntimeValueKind::Integer(text) if text.as_ref() == "9"
                ))
                .count(),
            1
        );
        assert!(machine.frames.is_empty());
        assert_eq!(machine.current_owner, ExecutionOwner::ModuleRun);
    }

    fn callback_trace() -> HygieneTrace {
        let program = runtime_program(CALLBACK_SOURCE, true);
        let answer = program.definition_named("answer").unwrap().clone();
        let roots = program.execution_roots().unwrap();
        let mut machine = program.start(&answer, &roots).unwrap();
        let RuntimeOutcome::Completed(value) = machine.run(100_000) else { panic!("exact callback route must complete"); };
        assert!(matches!(&machine.value(value).unwrap().kind, RuntimeValueKind::Integer(value) if value.as_ref() == "1"));
        machine.hygiene_trace
    }

    fn alternate_callback_arm() -> yu_hir::shadow::SourceNodeKey {
        let program = runtime_program(CALLBACK_SOURCE, true);
        let trace = callback_trace();
        let selected = trace.observations.iter().find_map(|record| match &record.transition {
            HygieneObservation::CatchCommit { arm, .. } => Some(arm),
            _ => None,
        }).unwrap();
        let handler = trace.observations.iter().find_map(|record| match &record.transition {
            HygieneObservation::CatchCommit { handler, .. } => Some(handler),
            _ => None,
        }).unwrap();
        let code = program.code.iter().find(|code| HygieneTrace::site_eq(&code.site, handler)).unwrap();
        let Instruction::Catch { arms, .. } = &code.instruction else { panic!("source-owned Catch"); };
        arms.iter().find(|arm| &arm.source != selected).unwrap().source.clone()
    }

    fn retire_callback_owner_early(trace: &mut HygieneTrace) {
        let owner = trace.observations.iter().find_map(|record| match &record.transition {
            HygieneObservation::CallbackEntry { owner, .. } => Some(*owner),
            _ => None,
        }).unwrap();
        let close = trace.observations.iter().position(|record| matches!(&record.transition,
            HygieneObservation::OwnerClose { owner: seen, .. } if *seen == owner)).unwrap();
        let commit = trace.observations.iter().position(|record| matches!(&record.transition,
            HygieneObservation::CatchCommit { .. })).unwrap();
        let record = trace.observations.remove(close);
        let adjusted_commit = if close < commit { commit - 1 } else { commit };
        trace.observations.insert(adjusted_commit, record);
        for (ordinal, record) in trace.observations.iter_mut().enumerate() { record.ordinal = ordinal; }
    }

    fn companion_trace() -> (HygieneTrace, SourceOperationId, SourceOperationId) {
        let source = include_str!("../../examples/original-suffix-outer-receiver.yu");
        let program = runtime_program(source, true);
        let operation = |effect_name: &str| {
            program._hir.source_effect_declarations().iter()
                .find(|effect| effect.spelling.as_ref() == effect_name)
                .and_then(|effect| effect.operations.iter().find(|operation| operation.spelling.as_ref() == "ping"))
                .expect("source-anchored operation declaration")
                .id.clone()
        };
        let signal = operation("signal");
        let write = operation("write");
        let main = program.definition_named("main").unwrap().clone();
        let roots = program.execution_roots().unwrap();
        let mut machine = program.start(&main, &roots).unwrap();
        let RuntimeOutcome::Completed(value) = machine.run(100_000) else { panic!("exact companion route must complete"); };
        assert!(matches!(&machine.value(value).unwrap().kind, RuntimeValueKind::Integer(value) if value.as_ref() == "23"));
        (machine.hygiene_trace, signal, write)
    }

    #[test]
    fn source_owned_callback_route_and_direct_mutations() {
        let trace = callback_trace();
        assert_eq!(trace.validate_callback_route(), Ok(()));
        let reject = |mutate: &dyn Fn(&mut HygieneTrace)| {
            let mut changed = trace.clone();
            mutate(&mut changed);
            assert!(changed.validate_callback_route().is_err());
        };
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::Permission { .. })); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::CallbackEntry { .. })); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::NameReceipt { .. })); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::CallbackUse { .. })); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::CallbackExecution { .. })); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::Request { callback_use: Some(_), .. })); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::CatchCandidate { .. })); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::CatchCommit { callback_use: Some(_), .. })); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::ShallowRetirement { .. })); });
        reject(&|t| t.observations.swap(2, 3));
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::Request { .. })) {
                if let HygieneObservation::Request { owner, .. } = &mut record.transition { *owner = ExecutionOwner::ModuleRun; }
            }
        });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::CarrierConstructed { .. })); });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CarrierConstructed { .. })) {
                if let HygieneObservation::CarrierConstructed { owner, .. } = &mut record.transition { *owner = ExecutionOwner::ModuleRun; }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CallbackUse { .. })) {
                if let HygieneObservation::CallbackUse { use_handle, .. } = &mut record.transition { *use_handle = use_handle.hygiene_next(); }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CallbackUse { .. })) {
                if let HygieneObservation::CallbackUse { entry, .. } = &mut record.transition { *entry = entry.hygiene_next(); }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::NameReceipt { .. })) {
                if let HygieneObservation::NameReceipt { view, .. } = &mut record.transition { *view = view.hygiene_next(); }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CallbackEntry { .. })) {
                if let HygieneObservation::CallbackEntry { formal_receipt, .. } = &mut record.transition { *formal_receipt = formal_receipt.hygiene_next(); }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CallbackExecution { .. })) {
                if let HygieneObservation::CallbackExecution { result_view, .. } = &mut record.transition { *result_view = result_view.hygiene_next(); }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CallbackUse { .. })) {
                if let HygieneObservation::CallbackUse { use_receipt, .. } = &mut record.transition { *use_receipt = use_receipt.hygiene_next(); }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::Request { .. })) {
                if let HygieneObservation::Request { executions, .. } = &mut record.transition { executions.clear(); }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::Permission { .. })) {
                if let HygieneObservation::Permission { families, .. } = &mut record.transition { families.clear(); }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::Request { .. })) {
                if let HygieneObservation::Request { payload, .. } = &mut record.transition { *payload = payload.hygiene_next(); }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CatchCommit { .. })) {
                if let HygieneObservation::CatchCommit { owner, .. } = &mut record.transition { *owner = ExecutionOwner::ModuleRun; }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CatchCommit { .. })) {
                if let HygieneObservation::CatchCommit { arm_range, .. } = &mut record.transition { arm_range.start += 1; }
            }
        });
        let wrong_arm = alternate_callback_arm();
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CatchCommit { .. })) {
                if let HygieneObservation::CatchCommit { arm, .. } = &mut record.transition { *arm = wrong_arm.clone(); }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CatchCommit { .. })) {
                if let HygieneObservation::CatchCommit { lifetime, .. } = &mut record.transition { *lifetime = HygieneLifetime::CapturedContinuation; }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CatchCommit { .. })) {
                if let HygieneObservation::CatchCommit { event, .. } = &mut record.transition { *event += 1; }
            }
        });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::OwnerClose { .. })); });
        reject(&|t| retire_callback_owner_early(t));
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::ShallowRetirement { .. })) {
                if let HygieneObservation::ShallowRetirement { retired_cells, .. } = &mut record.transition { retired_cells.push(usize::MAX); }
            }
        });
    }

    #[test]
    fn source_owned_companion_route_links_capture_response_and_retained_write() {
        let (trace, signal, write) = companion_trace();
        assert_eq!(trace.validate_companion_route(&signal, &write), Ok(()));
        let signal_arm = trace.observations.iter().find_map(|r| match &r.transition {
            HygieneObservation::CatchCommit { operation, arm, .. } if operation == &signal => Some(arm.clone()), _ => None,
        }).unwrap();
        let write_arm = trace.observations.iter().find_map(|r| match &r.transition {
            HygieneObservation::CatchCommit { operation, arm, .. } if operation == &write => Some(arm.clone()), _ => None,
        }).unwrap();
        let reject = |mutate: &dyn Fn(&mut HygieneTrace)| {
            let mut changed = trace.clone();
            mutate(&mut changed);
            assert!(changed.validate_companion_route(&signal, &write).is_err());
        };
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::Request { operation, .. } if operation == &write)); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::CatchCommit { operation, .. } if operation == &signal)); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::CatchCandidate { operation, .. } if operation == &write)); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::ContinuationCapture { .. })); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::ContinuationApply { .. })); });
        reject(&|t| { t.observations.retain(|r| !matches!(&r.transition, HygieneObservation::ContinuationResponse { .. })); });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::Request { operation, .. } if operation == &write)) {
                if let HygieneObservation::Request { owner, .. } = &mut record.transition { *owner = ExecutionOwner::ModuleRun; }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::Request { operation, .. } if operation == &write)) {
                if let HygieneObservation::Request { payload, .. } = &mut record.transition { *payload = payload.hygiene_next(); }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::ContinuationResponse { .. })) {
                if let HygieneObservation::ContinuationResponse { value, .. } = &mut record.transition { *value = value.hygiene_next(); }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::ContinuationResponse { .. })) {
                if let HygieneObservation::ContinuationResponse { view, .. } = &mut record.transition { *view = view.hygiene_next(); }
            }
        });
        reject(&|t| t.observations.swap(1, 2));
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CatchCommit { operation, .. } if operation == &signal)) {
                if let HygieneObservation::CatchCommit { lifetime, .. } = &mut record.transition { *lifetime = HygieneLifetime::ShallowDiscard; }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CatchCommit { operation, .. } if operation == &signal)) {
                if let HygieneObservation::CatchCommit { owner, .. } = &mut record.transition { *owner = ExecutionOwner::ModuleRun; }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CatchCommit { operation, .. } if operation == &signal)) {
                if let HygieneObservation::CatchCommit { arm_range, .. } = &mut record.transition { arm_range.start += 1; }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CatchCommit { operation, .. } if operation == &write)) {
                if let HygieneObservation::CatchCommit { event, .. } = &mut record.transition { *event += 1; }
            }
        });
        reject(&|t| {
            if let Some(record) = t.observations.iter_mut().find(|r| matches!(&r.transition, HygieneObservation::CatchCommit { operation, .. } if operation == &signal)) {
                if let HygieneObservation::CatchCommit { arm, .. } = &mut record.transition { *arm = write_arm.clone(); }
            }
        });
        let _ = signal_arm;
    }
}
