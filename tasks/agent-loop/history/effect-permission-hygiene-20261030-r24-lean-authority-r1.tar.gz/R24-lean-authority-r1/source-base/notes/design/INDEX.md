# Design authority index

This index is a navigation aid. The listed source document remains authoritative for its own text and scope. If this file conflicts with a source, read the source and correct the index.

- [Computed Call の complete result constructor](2026-10-24-computed-call-result-constructor.md) — 既存の missing-definition authorization に基づき独立査読後に選択。EvalInvoke/InvokeTail の新形成・解釈、全 independent arms、genuine inputs による introduction と checked Name における ReadInvoke との両方向一致。旧 IF→Desc の無条件推論を撤回し、固定 foreign R・native result-slot 対応・全体閉鎖は別に保持する。
- [生成レベルごとの Value SCC と intrusion](2026-10-24-birth-level-scc-intrusion.md) — ユーザーの直接選択。固定された Value 生成レベルの誘導グラフで SCC を計算し、同じ成分の実 extrusion occurrence の親子を等置する。旧跨レベル資格だけを置換し、参照・extrusion・一般化の規則は保持する。全体保存定理や実装完了の宣言ではない。
- [共起分析と保護解除の関係](2026-10-24-cooccurrence-release-clarification.md) — 直接のユーザー訂正。引数の保護と正確な共変位置の共起から共有変数・解除を説明する。複数入力の解除対象を新たに選ぶ質問は撤回し、保存証明と source 対応を進める。任意の `A_all` 候補の採用や証明完了ではない。
- [Braced `if` arm compatibility proposal](2026-10-20-braced-if-compatibility.md) — Draft only; not approved or authoritative. Scope: proposed dedicated expression-list bodies for braced `if`/`elsif`/`else`; current accepted Y3 syntax remains colon-only. The Yulang2 consumer audit has a major correction under review. User approval and a successor implementation contract are required before any syntax or compiler change.
- [R149 Types and Console compatibility](2026-10-20-r149-types-console.md) — Authoritative, provisionally adopted by the user's explicit ongoing goal for R149. Scope: exact pinned Yulang2 Web `Types` and `Console` examples, tuple inference/Display, standard-library host writes, and ordered whole-module execution; broader unchanged-example compatibility remains the goal. R149 is provisionally adopted; Luna activation still requires exact owner pins and prospective review.

## Resident Yulang orchestration (2026-10-16)

- [Reduced Astra use in goal-driven sprints](2026-10-17-astra-budget-reduction.md)
  — User-directed resource amendment: default zero, with one named-risk
  assignment capped at 300 seconds and three stages per sprint.
- [Module environment exposure](2026-10-17-module-environment-exposure-definition.md)
  — Adopts the independently reviewed typed module environment formation and
  occurrence lookup rule; admission equivalence, registered root and parent
  call theorem remain open.
- [Module entry provenance contract](2026-10-17-module-entry-provenance-contract.md)
  — Reviewed source/native readiness contract; identifies missing typed source
  owners and does not authorize an implementation representation or code.

- [Concrete-only negative formal-port source admission](2026-10-18-npair-source-admission-adoption.md)
  — Adopts only the reviewed nonempty concrete-only source case; explicit rollback conditions are recorded. Source/call access still requires a real UNKNOWN-owner STOP and lease handoff.
- [Adoption of the reviewed source-formation proposals](2026-10-17-source-formation-proposals-adoption.md)
  — Direct user adoption of the exact reviewed NPAIR and Catch source interfaces.
  Their proof obligations, including N-Transport and source-derived M_exit,
  remain open; adoption grants no compiler code lease or parent closure.

- [Goal-driven research and implementation sprints](2026-10-16-goal-driven-sprints.md) — Authoritative workflow decision approved 2026-10-16; supersedes only the listed scheduling clauses, preserves semantic/proof/review/Git invariants, and requires one-time independent migration review plus live legacy-worker reconciliation before adoption.

- [Implementation-first dispatch correction](2026-10-16-implementation-first-dispatch.md) — Mandatory multi-owner code-ready audit after research-only churn; normal focused checks, Luna/high implementer or explicit NO_SAFE_CODE_SLICE, without lifting dependent proof/cutover gates.

- [History reuse, Luna implementation floor, untracked hygiene and atomic questions](2026-10-16-resident-loop-operations-addendum.md) — Latest narrow authoritative update to the [resident dispatcher/prover/implementer loop](2026-10-16-resident-research-loop.md) and the [questioner handoff](2026-10-04-questioner-integrated-answer-handoff.md). Only approved answers confer decision authority; earlier attempts are preserved as history.

## Current callback identity decision (2026-10-15)

- [Extrusion replay completion](../theory/2026-10-16-extrusion-replay-capture-completion.md)
  and [source-publication attack](../progress/2026-10-16-extrusion-replay-publication-falsifier.md)
  — Independently CLEAN operational bridge from actual queue-covered descendants
  through drain/restoration completion to source capture/use. No new barrier or
  code is needed. It supplies neither missing generation nor semantic context/
  duplicate correctness; full H2/U remain OPEN and H3/P disabled.

- [Native Result predicate obligations](../theory/2026-10-16-native-source-predicate-adequacy.md)
  — Independently reviewed bounded derivation of actual declared-member/tail
  checks, same-witness source projection and retained residual factorization.
  Selected observations alone do not establish the declared Support predicates.
  Whole-descriptor-to-native adequacy for the original xi/z remains OPEN;
  no source-qualified counterexample or semantic change is established.
  The independently reviewed [formation audit](../theory/2026-10-16-native-declared-support-source-embedding.md)
  leaves the attempted annotation-to-complete-descriptor clause unproved.
  The [consumed user correction](../../questions/2026-10-16-annotation-declared-envelope/receipt.md),
  bundle `cfded839e`, withdraws the offered envelope/refinement framing.
  [Annotation policy §1.2](2026-10-10-annotation-effect-hygiene-integration.md)
  separates permission, constraint inflow and subtraction residual; declaration
  alone does not add an effect to the residual. Actual Support-role correspondence
  is active with original polarity/B and xi/z scope retained; no new choice waits.
  The independently reviewed [type-flow derivation](../theory/2026-10-16-native-annotation-flow-correspondence.md)
  and [source audit](../progress/2026-10-16-native-permission-inflow-residual-audit.md)
  resolve the local formation premise through already approved target exposure.
  Direct computation Allowance injects no declaration-only inflow. Full same-
  witness Result/context implication and general subtraction remain OPEN.
  The reviewed [source-judgment inversion](../theory/2026-10-16-first-result-source-judgment-preservation.md)
  fixes the original obligations/coordinates and locates the first coupled
  Apply translation. Its reverse implication stays OPEN while required forward
  soundness is pursued; abstraction-relative principality does not automatically
  imply universal extensional completeness or authorize gate retirement.
  The reviewed [forward constructor pass](../theory/2026-10-16-first-call-native-forward-soundness.md)
  establishes Unit/Delay validity and locates the original declared-arrow inlet
  correspondence. The reviewed [bounded Unit-inlet pass](../theory/2026-10-16-declared-unit-arrow-inlet-correspondence.md)
  pins the missing original annotation introduction; scalar truth is not whole
  checked admission. The [source constructor](2026-10-16-written-unit-arrow-inlet.md)
  is now selected after independent mathematical and conformance review under
  existing definition authority. It constructs the actual Unit filling and
  full-domain two-hole inlet, plus the selected native Identity kernel. Native
  ambient/copy applicability and both full parent directions remain OPEN.
  The reviewed [neutral Result-row interpretation](../theory/2026-10-16-neutral-result-row-source-interpretation.md)
  gives same-value source inclusion and same-z transfer for the actual plain
  field-3 fragment under explicit MODEL/CanonicalEq/source-correspondence
  premises. It supplies no model-existence, RE or global solver theorem.
  The separately reviewed [RE guarantee component](../theory/2026-10-16-first-call-re-guarantee-preservation.md)
  preserves the current invocation's outward bound to original E1 at fixed
  challenges, keeping the imported interface and full routing evidence.
  The [joint pass](../theory/2026-10-16-first-call-joint-forward-preservation.md)
  has a reviewed MAJOR claim correction: full target Comp(E1,A1) introduction
  remained OPEN despite accepted simultaneous transfers. Actual source/code
  attribution and two CLEAN delta reviews now justify selecting the
  [generated checked-result constructor](2026-10-16-source-application-checked-result.md)
  under existing definition permission. It preserves the full actual-source
  guard telescope and independent foreign/whole-Call contracts. Its actual native
  consumer application now has fresh independent mathematical CLEAN review:
  original local FORWARD-FIRST-CALL is proved under the unchanged explicit
  MODEL/lawful-map premises, with both same-z inputs and Return/Request/Bind.
  Native MODEL establishment, universal copy/source applicability, original
  reverse/full C0, global soundness/principality and F5 remain OPEN.
  The independently reviewed [FreshUse instance](../theory/2026-10-16-first-call-fresh-use-semantic-application.md)
  and [guard audit](../progress/2026-10-16-first-call-fresh-use-guard-falsifier.md)
  preserve one source-fixed presentation but leave arbitrary source-frame
  allocation OPEN at the local ResultBind publication/fixed-dependency owner.
  The reviewed [finite-checking pass](../theory/2026-10-16-first-call-source-checking-native-preservation.md)
  embeds explicit uniform Value/nominal RE checks; permitted restricted-domain
  Function checking still lacks native normalization/consumer correspondence.
  No parent is retired, source domain narrowed or compiler defect established.
  The reviewed [reflection attempt](../theory/2026-10-16-first-call-finite-function-check-normalization.md)
  and [guard attack](../progress/2026-10-16-first-call-finite-function-check-falsifier.md)
  leave normalization neither proved nor refuted. Test-provider saturation is
  an optional method premise, not a new necessary A/B gate. No authentic
  same-source counterexample or new annotation restriction is established.
  The local publication [Draft](2026-10-16-local-call-result-view-generalize.md)
  is unselected after matching MAJOR findings at complete d→caller→g:A1.
  Its [repaired characterization](../theory/2026-10-16-first-call-local-result-view-generalization.md)
  has accepted mathematical/source correction review and withdraws eligibility/
  allocation. The [field audit](../progress/2026-10-16-first-call-local-result-view-dependency-audit.md)
  leaves recursive ownership projection OPEN. The independently accepted
  [source-context constructor](../theory/2026-10-16-first-call-source-context-invocation-reuse.md)
  and [executable-field audit](../progress/2026-10-16-first-call-executable-input-dependency-audit.md)
  now prove the actual source graph's equal executable pi_exec and fresh
  full-f guard elimination. Complete IF/d/future typed records and independent
  history premises remain distinct. The subsequent independently accepted
  [ownership construction](../theory/2026-10-16-first-call-challenge-ownership-construction.md)
  and [audit](../progress/2026-10-16-first-call-challenge-ownership-audit.md)
  remove the blanket-fixed-whole-d edge at fresh assembly's introducing rule.
  The [ResultBind projection](2026-10-16-source-result-bind-projection.md)
  is now selected under existing definition permission after CLEAN math/source
  review of its [construction](../theory/2026-10-16-first-call-result-binding-projection.md).
  It retains all typed packet/actual contract fields and original dependencies,
  separating their hereditary checking proof. Full fixed-leaf support remains
  OPEN at the authentic opaque L1 output telescope/substitution; no Generalize
  eligibility, native-use closure or semantic erasure law is selected.
  The [raw-capture projection](../theory/2026-10-16-source-raw-continuation-capture-projection.md)
  and [independent census](../progress/2026-10-16-source-raw-continuation-capture-audit.md)
  have CLEAN mathematical/source review of supplied-operand projections and
  the lawful-response control trace. They preserve the whole installed J_raw;
  no initial g entry is installed. Original J_raw introduction/free support,
  complete typed witness, generalization and native application remain OPEN.
  The [raw-callable registration proposal](../theory/2026-10-16-source-raw-callable-validation-construction.md)
  has CLEAN correction review of its original component references, complete
  Mono fix traversal and Function introduction CONDITIONAL on the original
  typed continuation T_e. Historical whole-root evidence is not suffix typing.
  The independently reviewed [local T_e supplier](../theory/2026-10-16-first-call-local-typed-continuation.md)
  and [guard audit](../progress/2026-10-16-first-call-local-continuation-certificate-audit.md)
  now compose the original full-f inner pending interface and open F_g, with
  finite original-scope checks and both same-z packets. This closes only that
  local supplier under independently valid Gamma/d0/full-f premises. Concrete
  arm/response/context admission, generic source derivation, actual fixed support,
  eligibility and production remain OPEN; no response-arrow default is chosen.
  The [explicit-alpha application](../theory/2026-10-16-explicit-alpha-response-callable-construction.md)
  has CLEAN correction review: retained zero+ and Call(k,zero+) at the original
  result are established under the same independent premises. The initial
  h+/open-arm attempt left the complete R_e/J_raw output inclusion unsupplied;
  actual saved-source behavior is not every hypothetical realizer's guarantee.
  Negative ctrl permission is not an incoming effect cap. This alternate source
  instance narrows no parent and supplies no source-qualified counterexample.
  The [current-reference boundary](../theory/2026-10-16-raw-continuation-current-reference-map.md)
  has CLEAN correction review: map composition is conditional on the original
  root's actual declaration/body graph. Local T_e and IF incidence do not supply
  that graph; authentic current-map and direct support closure are withdrawn.
  The missing owner is source remaining-root formation before reference use,
  with original constraints, scopes, alternatives and inherited maps intact.
  The [selected remaining-root constructor](2026-10-16-source-remaining-root-constructor.md)
  and [independently CLEAN construction](../theory/2026-10-16-source-remaining-root-contract-construction.md)
  now supply that missing SOURCE graph/declaration/maps and universal readout,
  preserving all complete constituent alternatives. Its same-port declaration
  derivative and g ReadInvoke prove Phi_e for the explicit source slice; h+/
  open-arm checking follows under the original complete independent premises.
  This selects a missing source kernel under existing permission, with no
  foreign rewrite, whole-k input cap or runtime implementation. Concrete
  context/Catch admission, full installed support and native/global parents
  remain OPEN.
  The [full choose-producer certificate](../theory/2026-10-16-choose-producer-full-source-certificate.md)
  now has CLEAN mathematical/source correction review. It constructs one beta
  source instance and applies the existing exact-singleton relative kernel
  during membership, retaining carriers which capture the tested f. This
  discharges that case's full-f supplier under independent complete primitive/
  world/map inputs; concrete context/Catch, schemes and native parents stay OPEN.
  The [context construction](../theory/2026-10-16-choose-context-and-catch-source-construction.md)
  has CLEAN mathematical/source review of its open seed and conditional
  fresh-boundary/no-outside-receipt result. Actual AnnotationProfile for the
  explicitly annotated Function formal is the first missing supplier;
  inherited profiles, admitted d0, full selection/OpCompat and Catch stay OPEN.
  The [selected first-call profile constructor](2026-10-16-known-function-first-call-profile.md)
  and [reviewed construction](../theory/2026-10-16-known-function-first-call-profile-construction.md)
  now supply its outer complete-invocation component, first Name/Call
  applicability and Value-entry result-path introduction. The full profile
  inventory and concrete context/Catch/native parents remain OPEN.
  The [selected receiving-action grammar](2026-10-16-receiving-profile-introductions.md)
  and [reviewed construction](../theory/2026-10-16-receiving-profile-introduction-grammar.md)
  now supply actual current-carrier/result/future-entry cases and owner
  inversion for this source component. Complete antecedent and opaque actions
  remain; foreign/primitive/Initial/native parents stay OPEN.
  The [historical source-context constructor](2026-10-16-source-whole-context-constructor.md)
  and [reviewed formation](../theory/2026-10-16-choose-whole-context-reference-construction.md)
  now exhibit complete receive/outer-Call declarations, an independent checked
  view and actual historical reference maps. Original monomorphic formation
  closes; satisfaction, original specialization, generalized/native maps and
  complete installed support remain OPEN.
  The [source-action/support theorem](../theory/2026-10-16-choose-installed-support-source-substitution.md)
  now has CLEAN mathematical/source review: one authentic original TERM frame
  eliminates free this-frame q_c through the entire installed k/h Mono TYPE
  closure, using actual historical/current maps. Capture/context existence,
  other assignments, generalized clients and universal/native parents stay OPEN.
  The [declaration/Initial audit](../theory/2026-10-16-choose-source-declaration-initial-installation.md)
  has bounded semantic review: full typed operation Lambda/bootstrap remains
  the missing source owner. Sigma is an independent theorem parameter that
  a genuinely constructed source package may instantiate; empty environment
  and runtime activation do not prove OriginalInitial. Full admission stays OPEN.
  The [open bootstrap construction](../theory/2026-10-16-choose-source-bootstrap-construction.md)
  has CLEAN mathematical/source review of complete phase-expression and
  inert-prefix formation. Pi0 embedding, alternative coverage, hereditary
  Sigma0/world validity and Initial remain OPEN.
  The [bounded profile/operation application](../theory/2026-10-16-choose-bootstrap-profile-and-hereditary-closure.md)
  now has CLEAN mathematical/source review: actual Unit-entry reception,
  identity transport of choose's alpha return, and exhaustive inversion of
  the candidate operation-local clause graph. Caller-owned immediate guards,
  registration license, joint hereditary validity, every later current-world
  guard and OriginalInitial remain OPEN.

- [Native negative-formal consumer audit](../progress/2026-10-16-native-negative-formal-consumer-audit.md)
  — Independently CLEAN bounded source evidence: existing tail/closed-weight
  validation and Allowance consumers cannot implement open local permission
  by reusing a closed cap. Retained source polarity alone performs no Catch
  subtraction. A replacement coupled constructor/consumer remains unapproved;
  native negative admission and all hygiene/F5 parents stay OPEN.
  The [open negative-port/Catch-image Draft](../theory/2026-10-16-open-negative-formal-catch-image-design.md)
  and [later-lower audit](../theory/2026-10-16-catch-image-later-lower-feasibility.md)
  have CLEAN mathematical/source review of bounded claims. Joint source
  Invoke/remaining-suffix-to-image consumption, complete effect-lower wakeups,
  guarded discharge/copy/publication and central feasibility remain OPEN;
  the new architecture is unapproved and unready for implementation/adoption.
  The [original Call/raw-suffix construction](../theory/2026-10-16-call-suffix-image-demand-construction.md)
  now has CLEAN mathematical/source review of the proposed joint producer/
  entry/Argument/Replay map, original Request/Bind suffix and separate
  response-entry/raw-family demands. Once/twice/outside-arm source equations
  retain every other guarded/opaque alternative. Generic image discharge,
  lifecycle, termination/principality and adoption remain OPEN; current native
  slots and preflight are unchanged.
  The [contractual-alternative audit](../theory/2026-10-16-image-demand-contractual-alternative-falsifier.md)
  has CLEAN independent semantic review: the original unanchored Z branch
  needs its own `G ∧ Z ∧ Image ⇒ target` demand rule, and W needs its complete
  shared local action. Typed-core §8 supplies neither rule. No collision or
  generic impossibility was established; native discharge remains OPEN.
  The [original primitive-leaf analysis](../theory/2026-10-16-image-demand-original-alternative-discharge.md)
  has CLEAN mathematical/specification review. It localizes missing executable
  image-to-upper discharge at the original unanchored `Prim_alpha` clause;
  no concrete W/Z operation is selected, no impossibility/counterexample is
  claimed, and the original generic native A/B gate remains OPEN.

- [Native Value rewrite provenance repair](../progress/2026-10-16-native-value-rewrite-provenance.md)
  — The native duplicate/source audit reaches ordinary diagnostic children
  consumed as whole-Value extrusion certificates. The causal repair and
  [actual constructor/lifecycle proof](../theory/2026-10-16-native-retained-value-rewrite-invariant.md)
  now have CLEAN semantic/resource closure review. The original local native
  operational retention claim closes; the unchanged regression fails before
  and passes after, with 18 focused solver and all 108 playground cases passing.
  The source trace is not an observable counterexample; underlying semantic
  adequacy, source MODEL, full H2/U and production parents remain OPEN.

- [Initialization source-premise correction](../progress/2026-10-16-initialization-source-premise.md)
  — Fresh independent proofs locate Oracle publication outside raw continuations
  and show why stored-value body checks do not establish initializer-control
  admission. No root-purity or new publication law follows. Successor source/
  root/InstanceBody-to-Name/GlobalRead control correspondence remains OPEN.
  The reviewed [forward discriminator](../progress/2026-10-16-forward-initializer-control-discriminator.md)
  reaches the successor guard while Oracle passes readiness then escapes a
  request. No source-validity or divergence claim; exact generated root/instance
  correspondence is the next bounded artifact.
  That [artifact is now reviewed](../progress/2026-10-16-forward-initializer-artifact-correspondence.md):
  forward thunk and later Int root have distinct instance keys; the later root
  explains the escape. The [Name-role proof](../theory/2026-10-16-definition-name-computation-role.md)
  independently closes pure Name/Apply and populated-cache correspondence;
  empty-global execution context remains an open source operational premise.
  The [approved initialization replacement](2026-10-16-initialization-order-global-effects.md),
  integrated `885012b42`, now fixes effect-producing-line relative order and
  global handling/error for escaping initialization effects. It selects neither
  offered blanket dependency-first rule, an effect detector nor additional
  uninitialized-reference policy. The
  [local handler boundary](../progress/2026-10-16-playground-initializer-boundary.md)
  now has independently reviewed constructive/code correspondence and 108 passing
  playground tests. Effect-order/source admission and whole materialization remain
  OPEN; old A/B laws remain unselected. The independently reviewed
  [observation separation](../theory/2026-10-16-initialization-effect-order-source-observation.md)
  authenticates internal request order with empty outward initializer support.
  The validated [observation answer](../../questions/2026-10-16-initialization-effect-order-observation/receipt.md),
  bundle `6b6cafea1`, now selects actual effects escaping each initializer after
  internal handling, including before global consumers. Internal-only requests
  and static permission upper bounds do not count. The governing addendum fills
  that observation boundary without selecting a detector/scheduler or certifying
  source admission, materialization or production.
  The [current public-runtime proof](../theory/2026-10-16-initialization-outward-order-current-runtime.md)
  is independently CLEAN: at most one distinct outward event per fresh machine,
  none on successful completion, hence no observed pair inversion. This closes
  that local prefix fact only; source-prefix refinement, entry timing/earlier
  effects, successful scheduling/admission, global consumers and materialization
  remain OPEN. No runtime change or new failure policy accompanies the result.

- [Authentic module-expression source ownership](2026-10-16-module-expression-source-owner.md)
  — Authoritative option 1, question revision 2 / answer a1 revision 1 integrated
  at `f40e4235d`. G1–G3 complete; authentic carriers and receiver/use routing
  have actual constructive proofs. G4 implements mixed roots with independently
  reviewed structural/control correspondence; whole typed-source materialization
  adequacy remains open. [Integration and checks](../progress/2026-10-16-module-expression-integration.md).
  The separate [source-premise correction](../../questions/2026-10-16-resumed-definition-materialization/receipt.md),
  bundle `1e62dfdc3`, selects no A/B law: establish a valid typed source capture
  or unreachability before requesting that choice.

- [Primitive computation-root receiving](../progress/2026-10-16-playground-primitive-root-receiving.md)
  — The [uniform source theorem](../theory/2026-10-16-primitive-computation-root-receiving.md)
  and actual matcher have CLEAN semantic review for Unit/Int/Bool/Str, exact
  original positive permissions and ground-result projection. All 34 focused
  receiving/Resume/private tests and three CLI continuations pass. General
  profiles, Function/unknown roots, source MODEL and production remain OPEN.
  The independently CLEAN [Function-result owner audit](../theory/2026-10-16-runtime-function-result-view-projection.md)
  identifies the same-return two-input export and the later complete-Call
  observation as separate missing edges. Current ground completion and Callee
  dispatch supply neither Function bridge; schema widening is not selected.
  The independently CLEAN [source export construction](../theory/2026-10-16-runtime-function-result-source-construction.md)
  extracts both packets, complete Call ports and saved dependent return recipes
  from the original independently typed source T, with erasure. This closes
  only source extraction; native/profile supply and executable integration,
  complete Call consumers and full Function receiving remain OPEN.

- [Direct primitive operation handlers](../progress/2026-10-16-playground-primitive-handlers.md)
  — Whole-program source certificate, fresh-context and actual handler consumer
  have independent proof review. M2 code/contract reviews are clean; 90 package
  tests and the direct CLI example pass. General negative/profile evidence,
  full source materialization, full inference and production remain OPEN.
  Current-runtime pending-write raw capture is discharged by the corollary below.

- [Reusable raw continuation execution](../progress/2026-10-16-playground-raw-resume.md)
  — Actual owner/control/view/recapture correspondence and flat template
  ownership have independent proof review; M3 code/contract/resource deltas are
  clean and 82 playground tests pass. The later independently CLEAN
  [delimiter corollary](../theory/2026-10-16-initialization-outward-order-current-runtime.md)
  §8 closes current-public-runtime pending-publication capture/duplication by
  constructional unreachability; cached references/current cells remain supported.
  No A/B law or guard removal is needed. Source materialization, general visibility
  and full-source/production gates remain OPEN.

- [Receiving operation-handler execution](../progress/2026-10-16-playground-receiving-handlers.md)
  — Actual positive local Grant, independent same-view receipt join, primitive
  payload selection and wildcard-continuation discard have independent source
  proof and M3 code/contract/resource review. All 72 playground tests pass.
  Raw Resume, general negative evidence and whole-language parents remain OPEN.

- [Native first-Result source interpretation](../theory/2026-10-15-native-call-result-source-interpretation.md)
  and [origin falsification](../theory/2026-10-16-native-result-origin-falsification.md)
  — Independently reviewed source-coordinate decoder, constructor preservation
  and joint source-witness annotation; bounded static search found no actual
  counterexample. Native Replay/post-check and copied/merged-history adequacy
  remain OPEN. No new metadata or source restriction is selected.
  The [subsequent Replay proof](../theory/2026-10-16-native-result-replay-adequacy.md)
  establishes Value nondischarge, original Result context and ordered live
  activation. Common source/native satisfaction and original adequacy remain open.

- [Native first-Call valuation](../theory/2026-10-16-native-source-constraint-valuation.md),
  [consumer audit](../progress/2026-10-16-native-call-correlation-consumer-audit.md)
  and [received-root discriminator](../theory/2026-10-16-native-returned-callable-incidence-instance.md)
  — Independently reviewed local equations, bounded unsuccessful pure-provider
  attack and concrete captured/direct incidence construction. Both concrete
  sources pass CLI inference; their native graphs differ. The actual consumer
  correspondence is now the active evidence-producing action. Original universal
  adequacy, full B and production remain OPEN.
  The [actual consumer trace](../progress/2026-10-16-native-received-root-consumer-instance.md)
  now has clean independent review and an architect-confirmed minimal test-only
  selected-use census handoff. The [local-map census](../progress/2026-10-16-native-selected-use-census.md)
  and [source interpretation application](../theory/2026-10-16-native-received-root-interpretation.md)
  now have independent review and focused executable evidence. The subsequent
  [module-origin census](../progress/2026-10-16-native-module-use-origin-census.md)
  authenticates actual use origins, second-call dispatch ancestry and outer AE
  images. The reviewed [generative frontier theorem](../theory/2026-10-16-native-returned-callable-demand-frontier.md)
  establishes future-demand preservation and selected live-lower replay for the
  fixed pair, without intermediate-demand inverse reconstruction. Complete
  source/native event-view adequacy remains open. The reviewed
  [outer-use source packet theorem](../theory/2026-10-16-native-outer-use-source-witness-transport.md)
  proves joint reindexing with distinct historical/current environments;
  native Result plus same-parent RE/entry predicate interpretation remains OPEN.

- [Native Call-result transport audit](../progress/2026-10-15-native-call-result-profile-transport-audit.md)
  — Independently reviewed owner inventory. Structural retention exists through
  local install/capture/FreshUse; original first-Apply/result packet interpretation
  remains the next correspondence premise. No evidence-loss theorem or guard
  removal follows from this bounded audit.

- [Ordinary HIR carrier formation](../progress/2026-10-16-ordinary-hir-carrier.md)
  — Approved binding-carrier scope implemented with atomic per-root outcomes,
  preserved ordinary output and authentic provenance. All five local claims
  have independent proof review; default HIR and 201 shadow-feature cases pass.
  Four focused tests also verify existing explicit candidate consumption of the
  exact ordinary carrier. Default solver selection, broader admission, general
  expression roots and F5 remain open.

- [Request and normal-Catch execution checkpoint](../progress/2026-10-15-playground-request-control.md)
  — Existing operation schedule and shallow normal-return semantics implemented,
  with reviewed [source/control simulation](../theory/2026-10-15-playground-request-control-simulation.md).
  [Execution-owner correspondence](../theory/2026-10-15-runtime-execution-owner-correspondence.md)
  supplies the next actual owner constructor; receiving completeness, matching
  operation selection, raw Resume and full hygiene remain open.

- [Ordinary playground execution checkpoint](../progress/2026-10-15-playground-runtime.md)
  — Provisional implementation of existing scheduling and parameter-role
  decisions, with independently reviewed ordinary completed-path simulation.
  This is not new semantic authority or production/hygiene certification.
  The [finite receiving residual theorem](../theory/2026-10-15-native-receiving-residual-prototype.md)
  separately closes one exact assembled use; its [bounded native consumer](../progress/2026-10-15-native-receiving-residual.md)
  is implemented and verified. Generic native consumer transport
  remains open. The [returned exposure classification](../theory/2026-10-15-callback-result-exposure-classification.md)
  preserves inherited evidence without manufacturing a new outer-formal seed.

- [Ordinary identity forwarding](2026-10-15-callback-identity-forwarding.md)
  — Authoritative for the user's direct requirement that `id (h i)` preserve
  Callback Hygiene's outward return and sole output `0`, without special
  meaning for the identifier. The direct clarification also requires ordinary
  forwarding of each effect a function does not handle, and protection relative
  to the receiving boundary. Passing outside that boundary does not erase the
  effect or independent receivers' protections. The selected compose release remains binding;
  source attribution, discharge, Catch integration and soundness remain OPEN.
  The [reviewed finite construction](../theory/2026-10-15-callback-identity-receiver-construction.md)
  identifies the actual selected-frame/formal source key and whole-output
  discharge; its native supplier, latent transport and runtime premises remain
  open, with no production representation adopted.
  The [named-frame source bridge](../theory/2026-10-15-callback-named-frame-source-bridge.md)
  separates conditional frame identity from Oracle callee eligibility: native
  Block-wrapper authentication does not establish Oracle Var-only eligibility.
  [Retained named groups and factual Call joins](../progress/2026-10-15-callback-named-source-groups.md)
  supply source evidence; operational selection and discharge remain OPEN.
  The [reviewed receiver-relative application](../theory/2026-10-15-receiver-relative-protection-exit.md)
  distinguishes candidate receipt, receiver expiry and conditional outgoing
  protection release. Ordinary receiving Calls cannot be identified with the
  omitted-callee introduction records; their native correspondence remains OPEN.
  Its concrete annotated instance locates absent permission output at
  FormalEntry/annotation formation; the original source retains the fact that
  the inspected scalar Function channels cannot recover on their own.
  The [reviewed root-permission construction](../theory/2026-10-15-computation-formal-permission-construction.md)
  derives that finite source licence and an exact injected-operation classifier.
  Its residual theorem remains conditional on dynamic owner/path/instance;
  semantic suppression stays held. Six [delayed-computation source controls](../progress/2026-10-15-computation-laziness-and-permission.md)
  pass, including permissive resumption admission. The [reviewed root-profile
  source construction](../theory/2026-10-15-root-computation-profile-source-construction.md)
  generates the finite entry schema and exact forwarding map. Its body-pause
  future refutes lexical-only unconditional deletion; the conditional
  actual-instance theorem survives. Native entry/profile instantiation,
  complete-future Catch transport and full soundness remain OPEN.
  The subsequent [first positive preservation theorem](../theory/2026-10-15-computation-forwarding-preservation.md)
  has passed independent review for arbitrary finite explicit-root forwarding
  chains and typed control/resumption prefixes. Source entry/maps are generated,
  with base typing hypotheses explicit. The original native template inclusion
  is separate from the conditional FreshUse implication; actual mapped-bound
  admission, native/runtime correspondence and whole-language soundness stay OPEN.
  The [native FreshUse bridge](../theory/2026-10-15-computation-freshuse-admission-bridge.md)
  now establishes mapped-bound capture and physical restoration before
  publication for an isolated first-use direct-Name Computation provider.
  Independent review found no findings. General copied/merged provider
  correspondence and dynamic receiving evidence remain OPEN.
  The subsequent [signed-copy source bridge](../theory/2026-10-15-computation-signed-copy-source-bridge.md)
  derives one source-generated copied provider's joint AE/body/RE route from
  structural-before-pending work order, then capture and one FreshUse map.
  Independent repair review is clean; arbitrary shared/merged histories,
  later recapture and contextual consumers remain OPEN.
  The [playground source-plan implementation](../progress/2026-10-15-computation-source-plans.md)
  now exposes original explicit Computation-root annotation provenance to a
  bounded display consumer. Source ownership comes from the candidate's own
  verified registration, with no new solver constraints or legacy capture.
  Actual argument Name/AE and runtime receiving correspondence remain OPEN.

## Active workflow navigation (2026-10-10)

- [Evidence-based next-action selection](2026-10-12-next-action-selection.md)
  — Authoritative under the user's explicit request for a subagent and skill
  that help Luna identify the next executable work. Adds read-only
  `next_action_selector` for one evidence-producing action; the primary retains
  dispatch and authority, while `task_decomposer` retains multi-packet
  decomposition. Proof-first gates, original theorem scope and existing budgets
  remain binding.

- [Sol proof and task-decomposition roles](2026-10-10-proof-and-task-decomposition-roles.md)
  — Authoritative under the user's explicit 2026-10-10 workflow request;
  independent conformance/lifecycle review passed. Adds constructive `prover` and
  read-only `task_decomposer`, bounded two-leaf proof coordination and genuine
  native Astra escalation. The primary retains authority, reviewer assignment,
  shared records and Git; existing global budgets and proof statuses remain.

- [Questioner-integrated question board](2026-10-04-questioner-integrated-answer-handoff.md)
  — Authoritative; current explicit user change, independently scope-reviewed.
  Sections 2–4 retain local `questions/` and explicit draft approval, let answerers
  publish without Git, and assign discovery/validation/bundle commits to questioners.
  Disjoint primary file writers require no worktree-wide ownership handoff.
  Supersedes the integration/ownership parts of the
  [earlier repository board](2026-10-04-inrepo-uncommitted-question-board.md);
  unchanged approval/revision/freshness/authority safeguards remain.
  See [delivery](../progress/2026-10-04-questioner-integrated-answer-handoff.md).

## Active syntax navigation (2026-10-05)

- [Unary lambda parser for Callback Hygiene](2026-10-15-unary-lambda-parser.md)
  — Authoritative after the user's direct approval. Selects the complete unary identifier
  header before dynamic operators in NUD/ML admission, a lossless CST, and
  ordinary full-expression body/recovery. M3 compiler/specification review
  found no remaining blocking/major findings. The
  [parser implementation and local construction proof](../progress/2026-10-15-unary-lambda-parser.md)
  are complete after fresh semantic/specification and proof closure: 1417 syntax
  tests pass with one existing manual ignored, and the playground package check
  passes. Inline-lambda HIR, old F5 callback construction and runtime remain
  outside this approval.
  The user subsequently authorized the
  [private inline HIR connection](../progress/2026-10-15-inline-lambda-hir.md):
  its original formation theorem and actual-source bridge are now independently
  reviewed, with 33 focused HIR/solver/playground tests and a successful package
  check. Callback-context delivery and runtime remain separate open gates.
  The [native context source gate](../progress/2026-10-15-callback-context-delivery.md)
  now records the actual generation/admission split and the remaining
  phase-factorization and original Function-profile construction premises.
  The [reviewed coordinate/native bridge](../theory/2026-10-15-function-callback-profile-construction.md)
  follows the acyclic original formal through capture and same-use reconstruction;
  source-component applicability and contextual consumption remain OPEN.
  Existing directional authority corrects annotation-only reconstruction:
  original seed/upper-use provenance and independently justified typed evidence
  control applicability. The [local source/native consumer result](../theory/2026-10-15-callback-handler-native-construction.md)
  derives the supplied-profile source equation and direct omitted-formal RE
  chain; actual native interpretation and before-body delivery remain OPEN.
  Ordinary inference success does not close those obligations.

- [Parenthesized same-line ML application](2026-10-05-parenthesized-ml-application-addendum.md)
  — Authoritative; the explicit principal-scheme source
  `my compose f g x = f (g x)` requires `(g x)` to parse as one grouped
  expression containing same-line ML application. `(a b)` is therefore one
  application element, superseding the older Gate 3b E6 missing-comma witness
  and the parenthesized `LayoutOnly` implementation choice. Comma and
  equal/deeper-newline ownership remain as specified by the existing grammar.
  See the [recovery inventory](2026-09-02-yumark-gate3b-recovery-adoption-matrix.md)
  for the retained historical E6 row and the
  [HIR/source-core progress record](../progress/2026-10-04-hir-source-core-boundary.md)
  for the focused parser-to-candidate evidence and remaining production bridge.

## Active inference navigation (2026-10-05)

- **Top-level type-inference principles (2026-10-11):**
  [Yulang Type-Inference Development: Top-Level Principles](2026-10-11-yulang-inference-top-level-principles.md)
  is Authoritative by the user's explicit decision. It prioritizes the
  mathematical Simple-sub algorithm, proof-derived implementation, and
  efficiency; forbids speculative typing search; and limits abnormal-path
  requirements to safe diagnostics, no incorrect typing/publication, and
  safe termination. It supersedes blanket exact-state/capacity restoration
  and allocation-free rollback requirements in conflicting inference gates.
  Its October 14 direct clarification fixes source-driven constraint
  generation (including both branches of a constant-condition `if`),
  extrusion-occurrence Value ownership, Value-reference SCC qualification,
  and reuse of existing hygiene proofs. Read it before selecting inference
  work or applying older contextual rollback clauses.

- **Current legacy withdrawal policy (2026-10-10):**
  [active removal of Simple-sub bypasses](2026-10-10-simple-sub-legacy-withdrawal.md)
  requires actual dependency removal and regression tests, including removal of
  obsolete proof prerequisites rather than false proof closure. Complete Call,
  effect hygiene, soundness and principality remain genuine requirements.
  Historical construction routes do not retain authority over a withdrawn
  mechanism. See the scoped delivery and remaining migration in that record.

- **Ordinary successor HIR carrier (reviewed proposal; approval pending):**
  [supplementary source carrier](2026-10-10-ordinary-hir-successor-carrier.md)
  retains source facts after ordinary admission without changing HIR items,
  diagnostics, recovery, or ordinary occurrence identities. Directly enabling
  the existing opt-in carrier is incompatible with those contracts. The
  proposed sidecar is not implementation authority and closes no default
  inference, public export, Call, hygiene, soundness/principality, or F5 gate.

- **Current user-selected intrusion operation (2026-10-10):**
  The [value-to-type association clarification](2026-10-12-intrusion-value-type-association.md)
  controls qualification: compute SCCs on value-variable references, then
  intrude associated extrusion-related type variables. Type copies need not
  themselves be graph vertices. Earlier copy-vertex nonreachability results
  do not establish nonqualification under this rule.
  [parent-copy SCC equality](2026-10-10-parent-copy-scc-intrusion.md) retains
  parents at extrusion and equates parent/copy variables when they enter the
  same SCC. The user directly authorized implementation. Actual equality and
  SCC integration are required; unused metadata or continued internal-SCC
  rejection does not satisfy this operation. The
  [Value-reference ownership decisions](2026-10-10-parent-copy-scc-intrusion.md)
  now include recursive nested-Apply Name membership and definition-root
  ownership across lexical levels. The
  [October 14 private implementation](../progress/2026-10-14-value-occurrence-intrusion-implementation.md)
  constructs the Value graph, retains call-demand occurrence associations and
  actual polar pairs through replay and transformed-output reuse, and applies
  qualified equalities once. Focused tests and semantic/resource review cover
  that slice. The independently reviewed
  [retained-event activation theorem](../theory/2026-10-14-value-intrusion-activation-correspondence.md)
  proves original-Value SCC projection, exact once-per-pair qualification and
  equality consumption, immutable reuse ownership and rollback for the actual
  private mechanism. Source-global event applicability and typing/equality
  preservation remain open. The
  [conditional source checkpoint](../progress/2026-10-14-conditional-source-playground.md)
  adds actual If/Boolean/String construction and all-branch value/effect
  constraints, with reviewed child-occurrence ownership. Its
  [finite-branch join/source bridge](../theory/2026-10-14-conditional-constraint-join.md)
  passed fresh independent proof review for its local value theorem and bounded
  constructor/admission correspondence. The separate
  [conditional-result Value incidence](2026-10-14-conditional-value-references.md)
  now has explicit user approval for Choice A (conditions and all branches),
  preserving the reviewed constructor boundaries. Its
  [implementation/projection checkpoint](../progress/2026-10-14-conditional-reference-choice-a.md)
  passed focused checks and independent review. The extension adds no incoming
  Expression edge and does not change current semantic SCC membership. The
  [normal-return Catch checkpoint](../progress/2026-10-14-catch-value-and-native-residual.md)
  adds scoped value binders and value/effect joins to the actual source carrier
  and playground. The independently reviewed
  [native Allowance residual primitive](../theory/2026-10-14-native-handler-residual-cut.md)
  establishes plain residual feasibility and replay/lifecycle correspondence
  under its explicit processing premises; authentic handler eligibility and
  full hygiene remain open. The
  [extrusion-initialization replay checkpoint](../progress/2026-10-15-extrusion-initialization-replay.md)
  now queues exact current copied-cut comparisons after construction, using a
  [reviewed sparse native invariant](../theory/2026-10-15-extrusion-initialization-replay-invariant.md).
  Source H2/U, complete contextual completion and handler eligibility remain
  open; the owning Effect module retains three baseline-confirmed failures. The
  [operation-pattern CST/recovery proposal](2026-10-14-operation-pattern-tails.md)
  is Authoritative after the user's 2026-10-14 approval; its
  [parser implementation](../progress/2026-10-14-operation-pattern-implementation.md)
  passed M2 semantic/conformance review and focused/package verification.
  The [operation-Catch carrier](../progress/2026-10-14-operation-catch-constraints.md)
  now forms monomorphic payload/raw-continuation constraints and passes focused
  verification plus M2 review. Its conservative suffix envelope has a
  [bounded reviewed derivation](../theory/2026-10-14-handler-boundary-construction.md);
  source callback-profile/context construction, residual subtraction and full
  hygiene remain OPEN. The
  [copied-row ownership decision](2026-10-12-value-reference-copied-row-ownership.md)
  fixes extrusion and per-use freshening as description/bound copies that do
  not inherit Value-reference incidences; independent source-owner construction
  remains responsible for any such edge. Adopting an SCC-preserving shortcut
  requires both a preservation argument and a computational-cost justification;
  no shortcut implementation or F5 authorization follows. The
  [implementation checkpoint](../progress/2026-10-10-parent-copy-intrusion-implementation.md)
  connects canonical equality, live use-time recapture and actual open recursive
  uses, with bounded M2 reviews and owning builds. The
  [owning runtime regressions](../progress/2026-10-10-intrusion-runtime-regressions.md)
  now cover real extrusion parents, SCC equality and its control, rollback,
  recursion and live captures. Broader semantic correctness and complete
  Call/public cutover remain open.

- **Current single local self-recursive function scope (2026-10-10):**
  [local self-recursive binding](2026-10-10-local-self-recursive-binding.md)
  is Authoritative: the binding is visible during its own initializer and all
  recursive occurrences share one open monomorphic root. It is published
  through the existing sequential local boundary afterward, so later siblings
  can refer to it. Local mutual groups, polymorphic recursion and general
  value self-initialization are not selected. The proposed source-to-solver
  seam passed semantic and conformance review; implementation and focused
  source/lifecycle regressions remain open.

- **Current contextual residual identity (2026-10-10):**
  [constructor-lineage selection](2026-10-10-contextual-residual-lineage-selection.md)
  is Authoritative only for residual-recipe identity. Distinct recipes remain
  distinct across source/key equality, and each applicable current/future
  lower reaches every retained recipe. Qualifying actual parent/copy SCC
  equality still equates rows and transports all recipe obligations. Exact
  source admission, contextual lifecycle, soundness, principality and complete
  Call remain open.

- **Current annotation effect hygiene policy (2026-10-10):**
  [selected polarity policy and existing-proof integration](2026-10-10-annotation-effect-hygiene-integration.md)
  records contravariant function-local concrete subtraction and covariant
  concrete allowance. Section 1.1 records the October 15 annotated callback
  and computation-argument examples, both returning `1`: `[signal]` grants
  local subtraction, accepts an additional `write`, and leaves `write` outward.
  Variables are not concrete annotation atoms; their flow
  and later concrete checks remain. Reviewed conditional hygiene transport,
  owner/lifetime and exact-interface results are reused with their original
  premises, without reopening them. The callback result formerly shown in §6
  was later retracted by the user as a mistake; no replacement result is
  selected. Scoped conformance review passed. Actual
  HIR annotation construction and executable concrete/filter algebra remain
  the implementation cut; no compiler-code or runtime integration is claimed.
  See the [delivery record](../progress/2026-10-10-annotation-effect-hygiene-integration.md).
  The later [concrete/co annotation implementation gate](2026-10-10-concrete-effect-annotation-implementation.md)
  specifies actual whole-binding checks, positive target publication and private
  executable effect operands. Its [initial frozen review](../progress/2026-10-10-concrete-effect-initial-review.md)
  records three passing kernel tests, an owning build failure and accepted
  semantic/resource repairs in progress. It does not certify source subtraction,
  complete Call or public cutover.
  The [later implementation delivery](../progress/2026-10-10-concrete-effect-annotation-implementation.md)
  closes those bounded repairs with independent delta review, 43 focused passing
  tests and warning-free owning checks. Default-parser deep-input stack safety
  remains a separate recorded gap; source subtraction/public cutover remain open.
  The [mixed covariant allowance capture checkpoint](../progress/2026-10-10-mixed-covariant-allowance-capture.md)
  then closes a live-scheme lifecycle gap for rows combining a concrete
  allowance and symbolic tail: incidence survives positive extrusion, capture,
  freshening, intrusion bucket splicing and rollback. Its kernel and source
  regressions cover complementary event orders. This remains a bounded
  candidate result, not full hygiene, Call or public/default cutover.

  The [paired formal composed-covariance checkpoint](../progress/2026-10-10-selected-formal-contextual-integration.md)
  now connects concrete/empty rows at composed positive formal positions to
  the same executable Support/Allowance owner, with scoped tail sharing,
  independent fresh uses and rollback. It corrects the historical paired
  Oracle/source-variance mapping. The nullary source sort theorem separates
  debt-only Value recursion from the still-open mixed Effect/residual consumer.
  This does not admit concrete negative formals or establish an output for the
  previously discussed callback example.
  The [local-recursive source witness](../progress/2026-10-10-local-recursive-contextual-source-witness.md)
  derives an actual lower-copy topology and identifies the missing initial
  contextual replay event. Its infinite complete reference closure remains
  conditional; it proves neither weighted execution nor gamma allocation.

  The [contextual attachment/admission design](2026-10-10-contextual-attachment-admission-design.md)
  is authoritative for the private contextual carrier, exact acceleration of
  two reviewed paired-ascription cycle shapes and certificate invalidation.
  Apply its whole-route rollback/retry clauses under the newer
  [top-level principles](2026-10-11-yulang-inference-top-level-principles.md):
  they are not general correctness gates without a proof of semantic need.
  The user's q1/a1 selects that bounded internal gate only; a later
  approved q1/a1 selects one attachment identity per annotation atom set,
  recorded in §3.1 and integrated at `d86d50dd2`. The user later retracted the
  previously claimed callback result as a mistake; no replacement is selected.
  General mixed-component admission, concrete formal-row enabling,
  Catch/complete Call, and public/default/F5 cutover remain open. The original
  carrier answer bundle is integrated at `7a6490172`.

  The [direct transport association integration](../progress/2026-10-13-direct-transport-admission-integration.md)
  consumes exact frozen source-admission records at the private evidence owner.
  Its borrowed reader and local gap correction are reviewed and compile-checked;
  runtime cases and consumer integration remain unverified. Operational origin
  fallback and all source/Call/L4/F5 gates retain their separate scope.

- [Private candidate suspension contract](2026-10-11-private-candidate-suspension-contract.md)
  — Authoritative after the user's explicit approval “承認して実装を進めて”.
  Specifies the private continuation stack, retained source/SCC progress,
  dependency invalidation/recomputation, private deferral and atomic
  publication for the existing contextual-admission gate. Read its §6–7
  failure-restoration and retry language under the newer
  [top-level inference principles](2026-10-11-yulang-inference-top-level-principles.md):
  blanket complete restoration is superseded, while semantic invalidation,
  successful suspension progress and no inconsistent publication remain.
  No public pending API, language-semantic change, or source restriction is
  selected. Production certificate creation remains gated on complete
  readiness and recognition evidence.

  The reviewed [complete Value-block restoration subcase](../theory/2026-10-13-restoration-temporal-coverage-proof.md)
  derives activation under authentic all-local equal-level preparation and
  identity/effect-leaf conditions. The independent [mixed-level owner audit](../progress/2026-10-13-restoration-lower-prefix-owner-audit.md)
  identifies negative extrusion as an actual lower-prefix producer. Its missed
  direct Function comparison has restored argument/result constraints; their
  [joint record-retention bridge](../theory/2026-10-13-fresh-use-function-port-joint-transport.md)
  preserves the original common parent and one FreshUse map. Its lawful joint
  semantic Function action remains open. These results do not change
  live-index semantics, source admission, original coverage or F5 authority.

- **Contextual cyclic algebra results (2026-10-10, research scope):**
  [exact cyclic-word representation and upward-observation theorem](../progress/2026-10-10-contextual-effect-path-theorem.md)
  proves finite exact one-ID normal-form automata and terminating multi-ID
  active/filter demand saturation without a count cap. Independent mathematical
  and executable reviews passed within that one-sided append subsystem. The
  [reviewed counterexamples](../progress/2026-10-10-contextual-effect-counterexamples.md)
  refute unrestricted support congruence and associative directed replay;
  [integration results](../progress/2026-10-10-contextual-effect-saturation-results.md)
  distinguish those proved results from the open mixed-replay/source/output
  consumer. This is not new language authority or a full hygiene/termination
  closure. No second production solver or source restriction is adopted.

- **Mixed contextual debt observation (2026-10-10, reviewed research scope):**
  The [finite observation theorem](../progress/2026-10-10-mixed-replay-observer-construction.md)
  decides arbitrary cyclic debt grammars under directed replay, swap and
  both-from-right, followed by any finite PUSH-bearing mixed continuation.
  Exact active counts and pending/left/right presence are preserved at every
  node. Query-specific finite saturation retains the original exact grammar;
  it imposes no semantic count cap. The
  [source callback circuit](../progress/2026-10-10-mixed-replay-source-cycle.md)
  returns concrete Function lowers with right debts `1+4k` to the same callback
  slot. Its corrected ordinary argument-Effect port swaps; this source does
  not execute the copying branch. The
  [integration and review record](../progress/2026-10-10-mixed-debt-observer-results.md)
  links the proof and 147-assertion research implementation, separates accepted
  review repairs and local consumer tests, and preserves the open cyclic
  PUSH-bearing/source-output/production gates. No new language authority or
  source-owned production attachment is enabled.

- **Recursive PUSH: direct decision and actual source instance (2026-10-10, reviewed research):**
  The [full-left recursive theorem](../progress/2026-10-10-recursive-push-observer-construction.md)
  decides arbitrary finite left-word grammars with independent binary replay,
  followed by any finite mixed observer. It retains both unbounded leading POP
  and active PUSH counts through an exact global-minimum/PVASS construction;
  no finite recursive PUSH budget is assumed. The
  [reviewed source construction](../progress/2026-10-10-recursive-push-source-invariant.md)
  derives actual consecutive `as` annotations, their concrete Act Row seed,
  retained distinct-owner PUSH/identity and POP/identity loops, and complete
  pre-generalization left-only closure for those two sources. The nested slot
  realizes all `(p,n)` in `N²`. Compiler execution is unrun. The
  [algebra theorem](../progress/2026-10-10-recursive-push-algebra-attack.md)
  also supplies exact mixed cancellation, affine growth and shared geometric
  PUSH families. The [integration/review record](../progress/2026-10-10-recursive-push-results.md)
  connects these proofs to the independently reviewed finite-state observer,
  executable evidence and counterexamples. Unrestricted returning mixed
  contexts, source lifecycle, production attachments and cutover remain open.

- **Mixed recursion and exact raw self factoring (2026-10-10, reviewed scoped research):**
  The [complete integration record](../progress/2026-10-10-complete-mixed-self-edge-results.md)
  distinguishes four proved results from the still open complete authentic
  mixed decision. The [constant-unit theorem](../progress/2026-10-10-contextual-self-edge-erasure.md)
  admits only actual I as a universal replay unit on normal inputs; raw I
  replay performs mix. The [constructive normalizer](../progress/2026-10-10-contextual-self-edge-normalizer.md)
  removes bare I/mix self productions on arbitrary raw recursive suppliers by
  retaining each incoming E and adding mix(E). Its finite-derivation proof
  preserves every original vertex language, lexical sharing, additions and
  supplied quotient/freshening/recovery interfaces without normality or debt
  bounds. Separate original filter events remain obligations. The
  [nonpositive-displacement congruence](../progress/2026-10-10-complete-mixed-effect-obstruction.md)
  supplies an exact finite mixed/copy recursion algorithm with query-specific
  future observations. Its invariant is proved for the stated grammar class,
  not imposed on source. The [unguarded shared PCP theorem](../progress/2026-10-10-complete-mixed-effect-construction.md)
  rules out total empty-support decision for a broader two-ID shared-child
  grammar. The [primitive source audit](../progress/2026-10-10-mixed-independent-grammar-bridge.md)
  prevents transferring that impossibility to independently selected bound
  replay, and falsifies atomic-copy and cancellation shortcuts. Two reviewed
  research executables implement the finite observer and raw self factoring.
  Positive-displacement mixed independent recursion, authentic source
  constructor/consumer/lifecycle correspondence and production remain open.

- **Function-only formal effect feedback (2026-10-10, reviewed conditional source scope):**
  The [one-formal source certificate](../progress/2026-10-10-formal-effect-admission-falsify.md)
  shows the prospective `f (f f)` debt circuit without Tuple or provider
  backflow, under the pinned Oracle constructors and concrete-lower replay.
  One independent compiler referee found no issue within that conditional
  scope; see the [review record](../progress/2026-10-10-formal-effect-admission-falsify-review.md).
  It is not parsed/accepted source execution and has no returning PUSH cycle.
  The [admission reduction](../progress/2026-10-10-formal-effect-admission-construct.md)
  proves an identity-only context bound for the currently admitted effect-free
  formal subset and gives a conditional joint debt observer. Both retain the
  next constructor's Effect dependency SCC and mixed recursive PUSH consumer
  as open. Explicit formal rows remain rejected by the candidate; no production
  attachment or F5 cutover follows.

- **Contextual self-filter discriminator (2026-10-10, reviewed conditional source scope):**
  The [three-formal source-shaped discriminator](../progress/2026-10-10-contextual-self-discharge-falsifier.md)
  derives a later Empty filter on the same symbolic Effect tail while leaving
  the PUSH-owning formal unused. Under the explicit counterfactual premise that
  `T <: T @ PUSH_i[{io}]` is stored as a positive lower, the later filter
  rejects it; dropping that lower makes this local check vacuous while the
  original filter registration remains. An independent compiler referee
  verified the owner path and premise boundary
  [here](../progress/2026-10-10-contextual-self-discharge-falsifier-review.md).
  Oracle drops the same-row candidate and the successor has not enabled
  concrete formal effect attachments or their contextual transport, so this is
  not an admitted witness or production divergence. Equal-level successor
  selection is upper-oriented and does not satisfy the positive-lower premise.
  Contextual self-discharge and its successor observation rule remain open.

- **Upper self retention through negative extrusion (2026-10-10, reviewed conditional source scope):**
  The [owner trace](../progress/2026-10-10-upper-self-filter-observer.md)
  shows that the positive-lower Empty discriminator does not observe an
  upper-only self relation in its local trace. Negative extrusion adds a
  positive parent-to-copy lower and copies selected uppers without replay;
  parent metadata alone does not form an SCC edge. Later scheme replay can
  select an upper when both rows are fresh, or a positive lower when the left
  row is an outer anchor. The [independent review](../progress/2026-10-10-upper-self-filter-observer-review.md)
  confirms these owner paths and keeps the source-reachability and contextual
  payload premises open. The separately reviewed
  [source-root bridge](../progress/2026-10-10-upper-self-source-root-bridge.md)
  establishes a real omitted-row source route that retains original T and an
  anchored negative-extrusion copy C in one later scheme. Its conditional
  extension supplies an Empty observer through a separate symbolic-only
  formal. The independent
  [bridge review](../progress/2026-10-10-upper-self-source-root-bridge-review.md)
  found no issues in that bounded derivation. Explicit formal-row construction,
  contextual payload transport, filter/replay and whole-source SCC behavior
  remain premises; this is still not an admitted counterexample or a safe-
  discharge theorem.

- **Current Simple-sub correction (2026-10-10):**
  [algorithm and code reassessment](../progress/2026-10-10-simple-sub-question-reassessment.md)
  restores uniform fresh-result/callable-bound generation for literal and
  generic arguments. Ordinary-value q1's choice is withdrawn; registry q4 is
  suspended as an inference prerequisite. No dependency from complete raw
  registry adoption to basic bound collection was established. Existing
  full Call, effect/protection, q2/q3 and proof scopes remain binding; proceed
  with compositional collection, live bounds and successor generalization.
  The [collector checkpoint](../progress/2026-10-10-compositional-inference-collector.md)
  implements lexical nested recipes and direct formal result endpoints in the
  nonshipping solver and connects the opt-in multi-parameter HIR carrier.
  Reviewed early depth enforcement closes its recursive ownership hazard;
  runtime verification remains omitted. No full Call or cutover gate is closed.
  The [mixed graph scheme checkpoint](../progress/2026-10-10-successor-mixed-graph-schemes.md)
  now connects kind-qualified value/effect bound capture and per-use freshening
  to private SCC/incoming-use execution. M2 review and owning builds cover that
  implementation slice; the later source-flow and executed-construction results
  below extend its evidence. Complete Call/publication/cutover remain open.
  The [source effect-flow checkpoint](../progress/2026-10-10-successor-source-effect-flow.md)
  connects actual Apply/Group effects and fresh invocation rows to that graph
  path. Its initial checkpoint has M2 static reviews and owning builds; the
  [actual source construction/execution review](../progress/2026-10-10-candidate-graph-call-review.md)
  now supplies bounded runtime evidence for `invoke` and repeated `invoke id`.
  The [polarity-copy checkpoint](../progress/2026-10-10-successor-polarity-copy-extrusion.md)
  adds original-level-preserving copies, directional bound ownership and
  owner-preserving scheme replay to the private graph path. The
  [directional source proof/review](../progress/2026-10-10-candidate-directional-source-review.md)
  now derives exact fresh logical membership construction and records 13 focused
  passing tests. General nested levels and complete Call/public cutover remain open.
  The [generic local source checkpoint](../progress/2026-10-10-generic-local-source-hir.md)
  retains sequential local declarations and lexical ownership at HIR formation.
  M2 review, one batched repair, fresh delta review and owning builds pass.
  Solver consumption with raised initializer levels and per-use freshening is
  implemented by the live local scheme checkpoint below; the sidecar alone
  does not establish local inference.
  The [flat source projection integration](../progress/2026-10-13-flat-local-source-projection-integration.md)
  removes the private expression-depth counter and redundant initializer
  recovery scan after proving formation and larger-input projection invariants.
  A successful formed-binding phase result replaces construction of a discarded
  recursive association tree. M2 semantic/resource reviews and three scoped
  compile checks pass; runtime depth/return/drop tests remain unexecuted.
  Root parameter/annotation safeguards and ordinary/public/direct-root consumers
  retain their separate scope; no ordinary migration or F5 cutover is adopted.
  The [complete Call source-spine packet](../progress/2026-10-10-complete-call-source-spine-next-packet.md)
  identifies existing symbolic formation constructors and their actual input
  dependencies. Unknown-provider collection can precede role refinement;
  no solved receipt, complete consumer or new registry is thereby supplied.
  The [live let correction](../progress/2026-10-10-live-let-level-extrusion-correction.md)
  withdraws mandatory initializer saturation/freezing. The active adapter keeps
  local live roots and level boundaries, freshens at each use and preserves
  later constraints through shared older extrusion coordinates.
  The [live local scheme checkpoint](../progress/2026-10-10-successor-live-local-schemes.md)
  connects actual source levels, live binding handles and use-time freshening
  to candidate execution. Both M2 reviews and candidate/default builds pass;
  the [legacy withdrawal regressions](../progress/2026-10-10-simple-sub-legacy-withdrawal.md)
  and owning intrusion regressions now verify bounded generic-local cases.
  Broader source correspondence and complete Call/public cutover remain open.
  The [candidate lifecycle retirement](../progress/2026-10-10-candidate-closed-lifecycle-retirement.md)
  removes candidate construction/finish of the legacy closed finalizer and
  its result-shell dependency. M2 review and 52 focused tests pass; public
  closed result ownership remains genuine and public successor cutover open.
  The [unused draft resource withdrawal](../progress/2026-10-10-candidate-unused-draft-withdrawal.md)
  also removes the candidate's unused F5 startup reservation. M1 review and ten
  focused controls pass; legacy reservation/failure behavior remains real.
  The [discarded observer Call inventory retirement](../progress/2026-10-10-unused-observer-call-inventory-retirement.md)
  removes unused candidate preflight descriptor construction while preserving
  historical observers and real source Calls; M1 review and 24 owning controls pass.
  The [Oracle Unit integration](../progress/2026-10-10-unit-primitive-integration.md)
  supplies actual primitive, HIR, solver and closed/flat adapters. M2 review,
  129 distinct focused tests and owning/workspace checks pass; authentic
  operation producer construction is now supplied by the
  [authentic operation integration](../progress/2026-10-10-operation-producer-integration.md).
  M2 review, 66 focused tests and owning/workspace checks pass. Typed operation
  interface provenance survives ordinary transport; lookup remains pure.
  Complete execution consumers and public cutover remain open.
  The [Value entry effect repair](../progress/2026-10-10-value-entry-effect-integration.md)
  replaces candidate source lambda's early purity admission with ordinary
  entry-to-invocation constraint flow. Source-role transport through annotations,
  native consumers and full semantic certification remain open.
  The [primitive formal annotation delivery](../progress/2026-10-10-annotated-primitive-formal-integration.md)
  now connects grouped Int/Unit formals to executable body inference and argument
  checks. M2 review and nine new owning regressions close; the coherent phase's
  83 focused tests/checks pass. The later
  [symbolic formal-effect tail slice](../progress/2026-10-10-symbolic-formal-effect-tail-integration.md)
  connects singleton variable-only effect tails across formal ports and the
  same definition's whole annotation, with focused rollback and late-lower
  checks. Concrete formal rows, closed `[]`, contextual subtraction, owned-public
  migration and full semantic gates remain open.
  The [paired Function formal constructor gate](../progress/2026-10-10-paired-function-formal-construction-gate.md)
  records independently reviewed shared omitted-port and binding-variable
  correspondence. The [paired formal delivery](../progress/2026-10-10-paired-function-formal-integration.md)
  now connects effect-free Function/named-variable formals to actual body and
  argument flow, preserving callback effects through shared ordinary port rows.
  M2 runtime and fresh repair deltas close; 93 distinct focused tests and owning,
  workspace and default checks pass. Explicit attachments, wildcard, owned-public
  migration and full semantic gates remain open. The user's exact callback
  target is recorded in the hygiene integration authority:
  `(int -> ['b, io] 'c) -> int -> ['b] 'c`. It remains an unexecuted target for
  concrete contravariant subtraction and a real `run_io` source definition.
  The [cycle-source audit](../progress/2026-10-10-explicit-effect-termination-source-map.md)
  locates Oracle's self-edge and variable-bound guards; successor correspondence
  and negative-formal implementation remain open.
  The [source Call input checkpoint](../progress/2026-10-10-call-source-inputs.md)
  retains authentic formal/operand inputs connected to generated native demands.
  Validating pending construction remains distinct from original certificates
  and semantic residuals. M2 review, Clone repair/delta and owning builds pass.

- **Reviewed deferred Simple-sub bound construction (2026-10-10):**
  [BOUND/PATH/ROW](../theory/2026-10-10-simple-sub-complete-bound-accumulation.md)
  constructs finite same-index complete-inclusion accumulation, exact original
  witness retention, and a row-only bridge to the actual solver. No immediate
  formal resolution or satisfiability is required. The
  [independent proof review](../progress/2026-10-10-simple-sub-complete-bound-review.md)
  and [executed implementation review](../progress/2026-10-10-simple-sub-deferred-call-implementation-review.md)
  record two adapter tests and five scalar/HIR deferred-call tests, including
  actual nested result-to-argument sharing. This is a bounded research result;
  whole Function decomposition, complete Call/C0, joint decision, source
  Generalize/public export and fresh ordinary use are not inferred from it.

- **Reviewed finite value/effect graph construction (2026-10-10):**
  [RAW-EXTRACT / RAW-FRESH](../theory/2026-10-10-simple-sub-kind-qualified-graph-construction.md)
  constructs the whole defined active scalar projection and a kind-qualified
  immutable fresh graph with an inverse. The [independent review](../progress/2026-10-10-kind-qualified-graph-review.md)
  records four executed tests, including actual symbolic-effect F5 failure,
  provider replay, cycles and opposite-polarity sharing. This stronger raw
  snapshot is not imposed on the actual rooted candidate path or equated with
  full operational/source restoration.

- **Reviewed source-generated candidate capture and use (2026-10-10):**
  [SOURCE-LOCAL / CAPTURE / FRESH-ROUTE / REPLAY / TERMINATION](../theory/2026-10-10-candidate-graph-call-correspondence.md)
  derives the actual graph and fresh mapping from the source/session constructor
  at `280d399e`, with symbolic invocation effects and no solved-provider premise.
  The [proof and code review](../progress/2026-10-10-candidate-graph-call-review.md)
  records two passing actual source fixtures and repaired assertion gaps.
  These are nonshipping scalar graph/route results; complete Call, source
  Generalize/public principality and ordinary fresh-use acceptance remain open.
  The [current directional construction](../theory/2026-10-10-candidate-directional-source-correspondence.md)
  proves source-derived closed membership capture and exact `M(C)` restoration
  at `334fd35`, using recorded owner sides and one fresh typed map. It does not
  reuse the old paired-edge replay law or require a stable idle opposite scan.

- **Authoritative native source Generalize (2026-10-08):**
  [source definition](2026-10-08-source-generalize-definition.md) and
  [SRC/SRC-J/GS/GC](../theory/2026-10-08-source-generalize-definition-and-proof.md)
  define source-owned ordinary descriptions, exact publication-indexed anchors,
  final source roots and independent finite joint use. Direct rule construction
  and inversion prove joint soundness and lawful-use completeness under genuine
  local constructor laws, with one allocation before assignments and histories.
  Shared initializer evidence, per-instance descriptions, aliases and actual
  runtime events retain their distinct original scopes. Recursive peer
  descriptions remain in one complete component relation; actual external
  monomorphic contracts stay fixed. Nonidentity checking and admitted
  conversions are included. This source-side rule is distinct from the
  transformed, displayable public export selected by the approved root-policy
  answer. Public projection/principality, production Direct acceptance,
  unprovided primitive/State/recursive laws and aggregate cutover remain
  separate. Both fresh independent reviews passed after the joint-use/recursive-
  anchor repair; see the
  [review record](../progress/2026-10-08-source-generalize-review.md).

- **Selected native transformed projection export (2026-10-08):**
  [native projection definition](2026-10-08-native-projection-public-export-definition.md)
  and [PE-ID/PE-PICK construction](../theory/2026-10-08-projection-public-export-construction.md)
  select a finite displayable public export for authentic immutable unannotated
  `id` and the stated finite public-import `pick` cases. The actual ordinary
  public roots retain the whole inlet/interface, original scopes and finite
  certificate schema; use-time checks do not inspect source bodies. This does
  not establish all-language principality, arbitrary import summaries, State,
  general recursion, solver discovery, production F5 correspondence or cutover.
  See the [integrated review](../progress/2026-10-08-projection-public-export-review.md).

- **Reviewed source-directed native boundary decision (2026-10-08):**
  [SD-NPB](../theory/2026-10-08-source-directed-joint-decision.md) constructs
  source-owned complete argument evidence and proves total sound/complete
  decision with original-scoped strategies for its finite positive native
  projection boundary envelope. It includes real new/alias frames and
  same-whole-inlet Function result views with all independent native
  admission/production/future fields. The enclosing Build/CallMem/C0,
  arbitrary active W, broader inference and production correspondence remain
  outside; general JOINT_DEC stays OPEN-PROOF. The separately reviewed
  [reference](../../tools/research_source_joint_boundary.py) implements only
  finite endpoint/frame arithmetic. Exact scope, eliminated premises and
  independent reviews are in the [integration record](../progress/2026-10-08-source-directed-joint-decision-review.md).

- **Reviewed native Call operational consumer exactness (2026-10-09):**
  [SCX / SCX-P](../theory/2026-10-09-native-call-result-consumer-construction.md)
  construct the actual `id 0` source consumer, prove its operational
  decomposition and literal termination, and construct/invert the complete
  native VP+Echo relational Call/Bind image with all original proof fields.
  This includes nonexecuting J alternatives and current-world raw resumptions.
  It is not typed M_E, selected ReadInvoke formation, complete IF, CallMem/C0,
  or Application_N membership. The [review record](../progress/2026-10-09-native-call-consumer-exactness-review.md)
  records both independent passes and the removal of the initially invalid
  selected-descriptor claim. Canonical DAG and production authority are unchanged.

- **Selected native literal argument checking (2026-10-09):**
  [literal source definition](2026-10-09-native-literal-call-checking-definition.md)
  and [MIN-ORIG-WHOLEARG/E/ER/S/LC](../theory/2026-10-09-native-id-original-wholearg-construction.md)
  construct an original WholeArgCompatible occurrence and a finite successful
  complete-inlet proof for native id's literal-0 Int/empty-residual case.
  The generic original Result-view operand, complete J alternatives, actual
  provider, Frame/Raw distinction, scopes and genuine finite proof choices
  are preserved. Independent caller/local laws remain inputs; complete old
  declaration/reference fibers, Code-Call formation, IF/M_E/DescMem and C0
  are not supplied. Both independent reviews passed and the native case is
  selected under current constructor authorization. The separately reviewed
  [native declaration](../theory/2026-10-09-native-whole-argument-checking-declaration.md),
  [native separation](../theory/2026-10-09-native-complete-call-typing.md), and
  [receiver/request theorem](../theory/2026-10-09-annotated-formal-seed-and-removal-theorem.md)
  retain their narrower scopes. Full original Call, annotated SEED_SOURCE/C5/C6,
  JOINT_DEC and production cutover remain open; see the
  [review and integration record](../progress/2026-10-09-source-semantic-attacks-review.md).

- **Selected Original-ResultLiteral formation (2026-10-09):**
  the approved [question answer](../questions/2026-10-09-original-literal-result-owner/approved-answer.md)
  selects literal Result formation and its Data_orig/Result-port registration
  at the bounded `Application_N` Name/Int seam. It does not construct the
  actual original Gen-Call-0 emission, O0/O1 protection inputs, kernel meaning,
  solving or publication. The bounded [record-map attempt](../progress/2026-10-09-literal-call-original-record-map-attempt.md)
  identifies the still-missing literal-coordinate original emission
  introduction; its first draft's “pending” wording is corrected by the
  post-integration addendum in that note.

- **Selected source-owned annotation formation (2026-10-10):**
  the approved [question answer](../questions/2026-10-10-source-annotation-typed-root-bridge/approved-answer.md)
  selects source-owned expression annotation formation with conditional
  Direct consumption, including the ordinary Any target-root case. This
  authorizes a detailed design only. Typed Any-root formation and its Top law,
  type-name resolution, production routing, failure/resource behavior and
  implementation remain open; keep this lane separate from Application_N.
  The bounded [Any-root owner attempt](../theory/2026-10-10-source-annotation-any-root-construction-attempt.md)
  finds no selected constructor for the written ordinary target root; it remains
  conditional research and makes no implementation claim.
  The [resolution-owner audit](../progress/2026-10-10-source-annotation-any-resolution-owner-audit.md)
  confirms that current HIR rejects the associated annotation before solver
  collection and selected current sources provide no written-Type resolver or
  Any builtin. The approved `source-annotation-any-name-resolution/q1` decision
  selects lowercase `any` as a built-in Type name with builtin precedence and
  no shadowing or uppercase `Any` alias; see the
  [decision record](2026-10-10-source-annotation-any-name-design.md) and its
  [integration receipt](../questions/2026-10-10-source-annotation-any-name-resolution/q1/receipt.md).
  This resolves name introduction only; the Any root, membership, Top law,
  Direct proof and implementation remain open.
  The independently reviewed [builtin descriptor-package attempt](../theory/2026-10-10-builtin-any-descriptor-package-attempt.md)
  narrows the previous root premise to the missing genuine builtin semantic
  declaration and complete membership/guard/evidence signature. It is a bounded
  obstruction, not global absence or new Any semantics; the ordinary Value
  meaning, hereditary Int-to-Any law and implementation remain open.

- **Reviewed one-case source annotation design (2026-10-10):**
  [design](../theory/2026-10-10-source-owned-annotation-any-design.md) assigns
  the proof-only `0 as Any` path to source association, literal formation,
  written-Type elaboration, ordinary Any-root production, Top/Direct checking
  and target-root publication. The Any root, written-type resolver and exact
  scoped law supplier remain conditional inputs. Compiler-referee/spec-auditor
  review closed after one minor wording repair and delta review. No compiler
  implementation, production routing, failure/resource behavior or cutover is
  authorized by this design gate.

- **Reviewed practical complete-Application candidate (2026-10-09):**
  [candidate](../progress/2026-10-09-practical-complete-application-inference-candidate.md)
  maps conditional collection, full contract ownership, solving, generalizing
  and publication for `f 1`. It rejects using the four-port shadow projection
  as the success criterion but remains conditional research, with no production
  implementation or cutover authority. The current source-owned blocker is
  authentic original literal Call emission formation plus the executable
  complete-kernel consumer; see the current status in `tasks/current.md`.

- **Reviewed literal Call emission decision candidate (2026-10-10):**
  [candidate](../theory/2026-10-10-original-literal-call-emission-extension-candidate.md)
  proposes a bounded tagged literal-origin emission direction beside the
  unchanged original Name/Name family, plus the exact future O0/O1 obligations.
  Compiler-referee and spec-auditor reviews closed after one batched repair.
  The user selected this as the next construction direction in
  `original-literal-call-emission/q1/d1`; the answer is integrated at `885e35264`.
  The later `original-call-argument-reify-owner/q1/d1` answer authorizes only
  a bounded design/construction gate for the generic Call-owned argument-Reify
  registration and exact ReturnImage/Delay attachment; its receipt is at
  `questions/2026-10-10-original-call-argument-reify-owner/receipt.md`.
  The reviewed [bounded source-rule candidate](../theory/2026-10-10-original-call-argument-reify-source-rule-candidate.md)
  specifies the ordered registration procedure and complete ReturnImage
  attachment interface. Its first independent review found a missing old
  active-license extension premise; the focused repair review closed that
  finding at `fc564e68f`. The candidate remains non-authoritative and
  conditional: actual `H_oldext` registry preservation/action, independent
  Delay input/license/latent attachment, and original source-introduction
  realization are unsupplied. It does not establish emitted membership or O0,
  formal/literal-1 acceptance, implementation, solving, publication, or F5
  cutover. The earlier native MIN-ORIG-WHOLEARG §4.1 construction is still
  limited to its fixed id/literal-0 case, and the extraction/portability
  discriminator retain their separate limits; see exact residuals in
  `tasks/current.md`. Three bounded supplier audits identify nearby selected
  owners but no exact formal/literal-1 constructor: old-license extension,
  independent Delay attachment, and original Reify introduction. Their
  conditional findings and source locators are linked from `tasks/current.md`;
  the actual-registry audit further finds that the complete `P` remains an
  input, so its lookup branch and old-consumer manifest cannot yet be
  instantiated. The earlier registry q1 asked whether to expand the bounded
  design gate upstream; q2/q3 later supplied the adopted bounded directions.
  Its obsolete unanswered file was removed in the
  [question-board cleanup](../progress/2026-10-10-question-board-cleanup.md). The independently
  reviewed [constructor proof](../theory/2026-10-10-original-call-reify-constructor-proof.md)
  repairs the old-image domain overclaim and proposes a typed tagged registry
  extension plus a distinct source-owned `J_lit`. The four choices are now
  adopted only as the bounded direction, and the proof assumes `P_old` rather
  than constructing the actual
  selected-source registry. The user's explicit 「完全契約で」 fixes the full
  Call contract. Approved `call-reify-registry-construction/q2` adopts that
  exact construction direction as a bounded design gate while retaining actual
  registry construction as open. q1 is withdrawn history in the cleanup record;
  q2 was integrated at
  `a4e789ee4`; its [receipt](../questions/2026-10-10-call-reify-registry-construction/q2/receipt.md)
  and [bounded direction](2026-10-10-call-reify-construction-direction.md)
  adopt exactly the four reviewed choices while retaining source construction
  and complete Call conformance as open gates. This does not authorize
  implementation, acceptance or F5 cutover. The unreviewed conditional
  [selected-source construction attempt](../theory/2026-10-10-selected-source-p-old-construction-attempt.md)
  identifies the first missing original-registration-to-`P_old` lookup/decoder
  bridge; exhaustive entry coverage and complete old-consumer closure remain
  open.

- **Reviewed concrete Call argument constructors; bounded direction adopted (2026-10-10):**
  [definition and proof](../theory/2026-10-10-original-call-reify-constructor-proof.md)
  constructs the actual source-child registration/license and complete
  suspension in an explicit tagged extension, with termination, inversion,
  whole action and exact old/native reduct preservation. For literal `1`,
  it constructs a distinct source-owned `J_lit` and proves ordinary R carrier
  validity plus full image adequacy at every independent ambient demand.
  The old ReturnImage, its full guards/alternatives and `Comp(empty,Int)`
  remain distinct retained objects. A two-event countermodel refutes the
  stronger inference to arbitrary fixed-old-J coverage. Both fresh math/spec
  delta reviews passed; [review and scope](../progress/2026-10-10-literal-constructor-proof-review.md)
  are checkpointed with the proof at `7b723269c`. The new registry
  interpretation, structural license, suspension attachment and literal
  image/domain rule are adopted only as the bounded direction recorded in
  `2026-10-10-call-reify-construction-direction.md`. This does not prove untagged
  `H_oldext`, bootstrap the complete original P, identify new roots with
  fixed old roots, close complete Call/inference gates or authorize F5.

- **Reviewed literal emission and complete L collection, unadopted (2026-10-10):**
  [definition and proof](../theory/2026-10-10-literal-emission-pipeline-proof.md)
  constructs the formal/Name/literal source spine, Call-owned argument operand,
  new concrete checking/operator/result declarations, acyclic Application/Code/
  result-consumer sequence, full contextual IF, tagged emission and local O0.
  It proves termination, exact inversion, whole action, unchanged old Keep
  semantics and finite ordered collection/extraction for the **defined**
  `RuleCall_L` envelope. The new `CertCall_L` has nine explicit dependent rows;
  no unavailable original generic certificate declaration is assumed.
  The complete old operator arms remain at their own original indices,
  including W/Z/Option 2, independent admission and output-dependent futures.
  Both independent fresh delta reviews passed; [review and scope](../progress/2026-10-10-literal-constructor-proof-review.md)
  are checkpointed at `c0d304113`. These new declarations/rules are unadopted,
  and this is not equality with an original literal rule, an original-consumer
  or Generalize eligibility bridge, a proof of law inhabitance, a semantic
  solver, complete Call acceptance or F5. The canonical DAG is unchanged.

- **Authoritative source-owned registry design gate (2026-10-10):**
  [scope](2026-10-10-source-owned-registry-design-gate.md), from q3/d1 integrated
  at `534d8c945`, authorizes bounded constructor design and independent review.
  It adopts no concrete registry API or RuleCall_L, and authorizes no compiler
  implementation, complete Call acceptance, solving, publication or F5 cutover.

- **Reviewed practical complete Call production proposal (2026-10-10):**
  [proposal](2026-10-10-practical-complete-call-production-gate.md) maps a
  finite dependent-interface graph that retains complete Call facts at their
  source owners, correlated solving evidence and atomic ordinary publication
  for the formal-Name/Int slice. Independent compiler-referee and spec-auditor
  reviews found no issue within the conditional proposal. It keeps actual
  `P_old`, the literal-to-formal ordinary-value/protection rule, effective
  complete solving and invoke public extraction open; it authorizes no
  implementation, default behavior, `f 1` acceptance or F5 cutover. See the
  [review record](../progress/2026-10-10-practical-complete-call-production-gate-review.md)
  and the separate [solver/publication seam map](../progress/2026-10-10-complete-call-solver-publication-seam-map.md).

- **Authoritative bounded source-owned original registry API (approved 2026-10-11):**
  [six-choice proposal](2026-10-10-original-registry-constructor-adoption-proposal.md)
  isolates the candidate's nominal recipes, raw Seal/decoder, owner/port/Entry/
  registration API, generated image roots, whole consumers and action boundaries.
  The user adopted its exact six choices only for the resolved nonrecursive
  formal/Name/Int pre-Call fragment; the validated
  [question receipt](../questions/2026-10-11-source-owned-registry-adoption/q1/receipt.md)
  records the scope. The prior
  [actual-kernel attempt](../theory/2026-10-10-original-registry-kernel-conformance-attempt.md),
  checkpointed at `de26db327`, stops at the original formal introduction's
  unprovided complete input telescope and typed raw-P substitution. Adoption
  now supplies a selected source-owned representation to investigate; it does
  not prove conformance to separately fixed original declarations, a complete
  Call, compiler implementation, inference closure, or F5 cutover. The
  candidate's conditional construction proof remains the mathematical basis.

  [Successor production dependency correction](../progress/2026-10-13-old-registry-production-proof-edge-retirement.md)
  retires a mandatory production edge to this particular old-registry route
  under the selected legacy-withdrawal authority. The API and its theorem
  conformance hypotheses remain scoped to that route; the complete source
  declaration/Entry/Call semantic law and native correspondence remain OPEN.

- **Reviewed structural source-formal-port Draft (2026-10-13; unapproved):**
  [constructor proposal](2026-10-13-source-formal-ports-declaration-proposal.md)
  retains the actual source header, flexible Desc and intrinsic port addresses
  in dependent structural outputs. Fresh delta review passed after repairs to
  their predecessor indices and contextual substitution. Genuine original
  carrier/port applications and introductions/maps into Entry-Value remain
  OPEN; this Draft is not adoption ready for actual invoke and supplies no
  production or F5 authority. It adds no mandatory old-registry prerequisite.

- **Reviewed source-owned invoke registry construction (2026-10-10):**
  [construction and proofs](../theory/2026-10-10-source-owned-original-registry-construction.md)
  build the actual formal/Name/literal pre-Call registry from source recipes,
  with seven source rows plus computed local declaration closure. Raw syntax
  is sealed before contextual typed decoding. Explicit NEW owner/port/entry
  interfaces give a complete type-argument rank proof, formal lookup/decoder
  square, entry inversion, shared proof-choice preservation, post-decoding
  consumer dependency closure and same-P reflection under lawful action.
  Both fresh mathematical and specification delta reviews passed after the
  late-typed-reference repair; [review record](../progress/2026-10-10-original-registry-construction-review.md).
  Proof checkpoint `fdda52fd8ec9eb1b3a691825a7b895b3a40fc753` was pushed before
  this shared-record update. The bounded six-choice representation has since
  been adopted for the resolved nonrecursive formal/Name/Int pre-Call
  fragment; see the [adoption authority](2026-10-10-original-registry-constructor-adoption-proposal.md).
  P_old/Reg/lookup/manifest inputs are eliminated in this defined pre-Call
  construction. Its conditional application to `my invoke f = f 1` is recorded
  in the [adopted pre-Call derivation](../theory/2026-10-11-adopted-invoke-precall-construction.md):
  its earliest actual-declaration premise is the unelaborated full `Fam_delta`
  application for owned carrier/receipt/Force/rebind ports. Its conditional
  construction is independently proof-reviewed; actual declaration
  conformance remains open. Arbitrary opaque original declarations are not
  presumed to conform. Complete original Call
  emission/checking, WholeArgCompatible, C0/admission, solving and publication
  remain open. The separate L theorem is not an original-consumer bridge.
  No canonical DAG promotion, language restriction, implementation or F5.

- **Authoritative exhaustive native signature formation (2026-10-08):**
  [signature definition](2026-10-08-native-signature-formation-definition.md)
  and [Theorem SIG](../theory/2026-10-08-source-signature-incidence-construction.md)
  construct support, independent licensing/attachment and their compiler
  correspondence from actual declarations/source/whole transformations.
  Complete constituent-origin partitions preserve inherited owners separately
  from receiving roots, with empty support fibers and one joint hidden package.
  All native licenses invert to actual formation-anchor packages; only the
  exact own-upper subfamily yields original E_C, with unchanged old objects.
  Actual primitive/C0/annotation laws, fixed consumer bridges, ROWS and
  production remain separate. Fresh math/spec delta reviews closed the
  accepted composite-owner defect; see the
  [integration record](../progress/2026-10-08-native-constructor-theorems-review.md).

- **Authoritative captured closure constructors (2026-10-08):**
  [complete closure definition](2026-10-08-captured-closure-constructor-definition.md)
  and [Step/Block/OuterTrace](../theory/2026-10-08-captured-call-closure-introduction.md)
  construct the approved nested step's membership and installed world together,
  with complete Value-entry effects and actual finite source witnesses.
  Actual captured f evidence and independent checking/guard/domain inputs
  remain; arbitrary outer descriptor membership and full C0 do not follow.

- **Authoritative native recursive interface (2026-10-08):**
  [native presentation definition](2026-10-08-native-recursive-interface-definition.md)
  and [OE/O-pair/ME-pair](../theory/2026-10-08-recursive-original-interface-embedding.md)
  supply the exact two-closure original interfaces, finite source witnesses
  and whole native background correspondence to the selected immutable
  interpretation. Missing native parameters receive explicit definitions;
  fixed-original meanings require actual laws and guard proofs. CompleteMem
  inventory, foreign models, broader recursion and production remain separate.
  Both new selections have independent math/spec review in the
  [integration record](../progress/2026-10-08-native-constructor-theorems-review.md).

- **Authoritative complete contextual source interfaces (2026-10-08):**
  [source-interface definition](2026-10-08-call-source-interface-definition.md)
  and [Theorem IF](../theory/2026-10-08-call-source-interface-construction.md)
  construct full source/structural/abstract-arm placements from actual
  source/operator and declaration/reference formation, with shared whole-map
  coherence. This extends the incoming selected acyclic SrcFrame+ result;
  its finite registered-cycle case proves static construction only. Original
  operator/phase/dispatch, hole/world, primitive licensing/admission, complete
  C0 and foreign-kernel/active-consumer laws remain genuine. SourceInterfaceFormation
  is no longer a separate placement premise on this constructor route. See the
  [independent review and integration](../progress/2026-10-08-call-interface-admission-review.md).

- **Authoritative contextual Function membership (2026-10-08):**
  [same-provider definition](2026-10-08-contextual-function-membership-definition.md)
  and [reviewed input realization](../theory/2026-10-08-call-semantic-input-realization.md)
  supply the original Name/Return/Delay input cases and actual-U argument
  acceptance at the same CalRet event without the extra raw ViewInlet premise.
  Complete receiver behavior follows from that same Function contract.
  Its selected [positive immutable recursive case](../theory/2026-10-08-simultaneous-immutable-root-introduction.md)
  introduces the exact two-closure Value-entry pair and installed root world
  together, using a proved declared-hole background lift. The native interface
  selection above supplies its original presentation; exhaustive fixed
  foreign-domain embedding remains separate, and no aggregate closes.
  Independent descriptor/history/primitive contracts and hereditary binding
  inputs remain; no exhaustive model, full C0 or production cutover is claimed.

- **Authoritative complete-operation contribution cases (2026-10-07):**
  [complete Call definition](2026-10-07-complete-call-contribution-definition.md)
  selects the independently reviewed C-Inv/C-Call and conditional dependent
  routing/accounting cases under the user's ongoing definition authorization.
  [C1-Call](../theory/2026-10-07-owned-call-contribution-construction.md) retains
  the authentic full callee/receiver/alternative operation with exact evidence
  fibers under independent C0. The later IF supplier above now constructs its
  complete diagram on the stated source/contract route; full J0 still needs
  independent complete C0 and the genuine original contracts. No source
  execution of Option 2 extras is required. Section 5 also selects the
  captured-Call `A-UpperCallRef` and `LC-OwnCall` constructor cases with
  injective retained-case inclusions; aggregate ATTACH/LIC_FORWARD/LIC_INVERT,
  fixed-kernel conservation, production semantics and cutover remain open. No
  concrete W/Z grammar is selected.

- **Reviewed complete source-input construction (2026-10-07):**
  [Call-input proof](../theory/2026-10-07-call-input-construction-proof.md)
  constructs the finite acyclic resolved source tree, including the exact
  nested Lambda/Bind/Call term, with exact erasure. Its independent semantic
  fragment proves Name/Return/constant-delay and actual-provider/live-world
  input consequences. A batched repair and fresh compiler-referee delta pass
  close the initial four findings. The later selected original input cases
  above realize its Name/Return/Delay consequence without adopting its raw
  ViewInlet requirement. General complete C0, exhaustive production membership
  and cutover remain separate. See the
  [completion review](../progress/2026-10-07-source-constructor-completion-review.md#7-completed-source-inputs-and-actual-return-consequence).

- **Authoritative shared static Call ownership (2026-10-07):**
  [static source constructor definition](2026-10-07-original-call-owner-definition.md)
  completes the existing source-formation direction under the user's current
  permission to proceed by definitions. The independently reviewed
  [O1-static proof](../theory/2026-10-07-call-owner-construction-proof.md)
  constructs the shared slot and paired lexical/checking upper-owner facets
  from one actual O0/source certificate and independently certified seed,
  including the approved nested
  source. Registration forms a schema; actual exposure forms typed membership.
  Complete Call typing, contribution/joint incidence, semantic membership,
  other source cases and aggregate gates remain independent. See the
  [completion review](../progress/2026-10-07-source-constructor-completion-review.md).

- **Authoritative original Call formation (2026-10-07):**
  [adopted formation definitions](2026-10-07-original-call-formation-definition.md)
  record the user's direct approval of the published §10 signature-demand and
  Call-effect constructors, including the exact full-invocation root
  interpretation. [O0-selected](../theory/2026-10-07-adopted-call-formation-o0.md)
  proves local static root/typed incidence and whole-index coherence for actual
  emitted Gen-Call-0 records; the approved nested source is included. The
  [review and consumer account](../progress/2026-10-07-call-construction-proof-review.md#7-approved-definition-and-local-o0-integration)
  preserved O1/C0/C1/J0 and all original broader domains; the later O1-static
  completion is recorded above. No all-source
  generation, aggregate ORIGINAL_ASSOC closure or production cutover follows.

- **Global successor proof-economy audit (2026-10-07):**
  [production proof architecture](2026-10-07-successor-production-proof-architecture.md)
  proposes four genuine semantic theorem families and one actual implementation/
  lifecycle invariant, with a construction responsibility map, dependency-level
  research separation and exact O0 formalization boundary. The
  [A/B/C/D audit](../progress/2026-10-07-successor-proof-surface-audit.md) covers
  every non-CLOSED canonical node and major sublemmas; the
  [Pro handoff](../theory/2026-10-07-successor-pro-theorem-handoff.md) contains
  exact target statements. No original semantic rule, DAG status/dependency,
  production contract or cutover is adopted by this audit. Source principality,
  all compatible contexts and exhaustive Option 2 extras remain required.

- **Fixed-original-family Call-effect comparison candidate (2026-10-10):**
  [original Call-effect typing clause candidate](2026-10-10-original-call-effect-typing-clause-candidate.md)
  gives optional signature-position and original-occurrence typing rules over
  fixed old semantic families, proves their syntactic whole-substitution laws
  relative to an independently supplied typed telescope action, and states the
  old-fiber sections and active-primitive pullback needed for conservative
  interpretation. It also gives a finite countermodel to free-evidence
  conservativity when an active old predicate changes. The clauses remain
  Draft: their old-family sections/pullbacks are unproved. This is distinct
  from the adopted local O0 definition above; neither result proves the other's
  comparison or broader semantic claims. No production implementation is
  authorized by this candidate.

- **Authoritative exact recursive singleton execution boundary:**
  [recursive self-init executable boundary](2026-10-07-recursive-self-init-executable-boundary.md)
  applies the existing approved `recursive-self-initialization/q1 d1` answer
  only to the exact singleton `my f = f`. Execution acceptance deterministically
  rejects before initialization/RHS self-read while preserving F4's `Never`
  inference. Independent compiler-referee/spec-auditor review passed the source
  rule and its envelope/inference/adequacy proofs. `REC_INIT_SELF` is CLOSED;
  other recursive initializers, actual compiler enforcement and successor
  cutover remain separate. The linked receipt records unchanged approval
  provenance and this governing-source application.

- **Handler-protection notation and selected compose release:**
  The [October 15 compose clarification](2026-10-15-compose-scoped-effect-release.md)
  selects `('a ['e] -> ['f] 'b) -> ('c -> ['e] 'a) -> 'c -> ['e?, 'f] 'b`.
  Release removes the `'e` scope's protection also from occurrences of `'e`
  within output effect `'f`, including `f = id`; other scopes and effect
  membership remain. This supersedes only the earlier compose expectation.
  Internal push/pop-like processing remains possible; no representation or
  theorem is adopted. The [native experiment checkpoint](../progress/2026-10-15-native-scoped-compose-experiment.md)
  records implemented scoped transport and three finite source observations;
  full source proof and handler subtraction remain open. The older general
  [handler protection-release notation](2026-10-05-handler-hygiene-public-provenance-notation.md)
  is Draft only. The user's corrected meaning for `'e?` is: for a contribution
  independently established as originating from `'e` and emitted from that
  slot, turn off handler protection. The `'e` attribution selects the affected
  contribution and remains unchanged; it does not express an input-to-output
  relation. Provenance/source component and row membership are preserved.
  Event identity and lineage are separate evidence, not the marker's meaning.
  It is neither an
  optional-flow marker nor a provenance edge, and it does not perform handler
  subtraction. It removes the protection-based barrier to ordinary handler
  eligibility, without granting capture or changing ordinary matching.
  Attribution, release timing, ordinary post-release eligibility,
  overlap composition and projection from current evidence remain open. It
  selects no grammar, carrier, or implementation and does not alter the
  Authoritative callback-context contract or existing proof gates.
  [`research_handler_provenance_projection.py`](../../tools/research_handler_provenance_projection.py)
  remains a historical independent support/provenance characterization. Its
  finite edge result is not evidence for `'e?`'s protection-release meaning;
  it does not derive source incidence or establish a principal projection.
  See its [progress record](../progress/2026-10-05-handler-provenance-projection-playground.md).
  [`research_handler_protection_release.py`](../../tools/research_handler_protection_release.py)
  separately checks a finite post-attribution/post-emission frame under
  supplied source-component and protection evidence, rejecting family-wide
  and sticky-protection mutants. It supplies emission as a coordinate
  separate from attribution and protection; event identity is only a toy
  evidence join key. It does not derive attribution/emission or establish
  that `Rel_C` and typed-boundary evidence realize the release; nested
  boundaries and actual resumption remain open. See its
  [progress record](../progress/2026-10-05-handler-protection-release-playground.md).
  [`research_handler_protection_path_projection.py`](../../tools/research_handler_protection_path_projection.py)
  checks one candidate query-time projection over supplied typed-path
  evidence. Its product-state query agrees with bounded raw-walk enumeration
  on 37,124 graph/marker/source/target configurations across 530 directed graphs through three typed positions. Route crossing
  is only a hypothesis for locating the release point, not the meaning of
  `'e?`; it does not establish source attribution, release lifetime, or
  adequacy. See its
  [progress record](../progress/2026-10-05-handler-protection-path-projection.md).
  [`research_handler_protection_filter.py`](../../tools/research_handler_protection_filter.py)
  checks a conditional filter over supplied `Inc_C` witnesses. It keeps raw
  incidence and `Grant` intact while filtering only protection, and rejects a
  mutant that removes released witnesses from both queries. It does not derive
  the source release predicate. See its
  [derivation record](../progress/2026-10-05-handler-protection-filter-derivation.md).

- **Authoritative source-formation direction — inferred Function call views:**
  [inferred Function call views](2026-10-05-inferred-function-call-views.md)
  records the approved direction to infer one shared role-indexed callback
  contract from declarations, uses and relevant recursive components, with
  stable slot/profile identity, typed paths and one correlated `nu,K,D`.
  Unannotated `f` receives a provisional fully protected Handler view whose
  later non-Handler determination must use ordinary-value evidence; an
  annotation on `[io]` permits only its specified removal. The concrete
  rules, principality/source-adequacy proofs, production conformance and
  implementation remain open. The document preserves callback-literal B and
  does not rewrite actual callable roles. The later direct user clarification
  selects directional protection from a protected inferred variable to the
  output-effect occurrence of an original upper Function use, without
  back-protecting an existing lower/provider effect. Its scoped formalization
  is [directional protection from an inferred variable to a Function upper view](2026-10-06-directional-inferred-effect-protection-addendum.md);
  its section 2.1 records the October 15 concrete clarification: `signal`
  survives relay's Catch and the `answer` variable binding to reach the
  enclosing block. Full source generation, soundness/principality and
  production cutover remain open.

- **Authoritative candidate source interpretation — nested block result and capture:**
  [nested-block Function source realization addendum](2026-10-06-nested-block-function-source-realization-addendum.md)
  records the approved sequential binding, final-expression return, lexical
  resolution and retained outer capture for exactly
  `my apply f = { my step x = f x; step }`. It resolves the syntax
  architecture's deferred block-value interpretation only for that candidate;
  current production acceptance, source adequacy, call-view registration and
  inference implementation remain gated. Approval provenance is the integrated
  [`nested-block-function-source-realization/q1 a1`](../../questions/2026-10-05-nested-block-function-source-realization/receipt.md).

- **Executable proof-search direction:**
  [inference research playgrounds](2026-10-04-inference-research-playgrounds.md)
  is Authoritative user direction permitting isolated executable models before
  proof closure for structural FMP, callback bridge, and principality. Finite
  search is evidence only; production inference routing remains gated.
  The October 14 [`yu-playground`](../../tools/inference-playground/README.md)
  runs the actual private source inference path and displays retained
  constraints, Value SCCs, extrusion pairs and settlement. Its
  [implementation checkpoint](../progress/2026-10-14-inference-playground.md)
  records the reviewed observation boundary, bounded reports and source limits.
  Current bounded callback/principality models are
  [`research_callback_lift.py`](../../tools/research_callback_lift.py) and
  [`research_principal_support.py`](../../tools/research_principal_support.py),
  [`research_principal_row_match.py`](../../tools/research_principal_row_match.py),
  and [`research_callback_entry.py`](../../tools/research_callback_entry.py).
  The scalar `Sat_j`/total-coordinate probe is
  [`research_callback_sat_lift.py`](../../tools/research_callback_sat_lift.py).
  [`research_principal_contract_join.py`](../../tools/research_principal_contract_join.py)
  checks the finite typed-pullback common-contract join.
  [`research_callback_callable_projection.py`](../../tools/research_callback_callable_projection.py)
  checks the higher-order authority-preservation boundary of the approved
  typed projection.
  [`research_callback_nested_value_projection.py`](../../tools/research_callback_nested_value_projection.py)
  composes scalar saturation with a returned package's dependent future call:
  the source projection remains included, but equality fails when a widened
  scalar changes the retained callable's request. A fixed-challenge owner-swap
  mutant also changes future request provenance. This is finite
  characterization only; see its
  [progress record](../progress/2026-10-05-callback-mixed-value-future-call-playground.md).
  [`research_compose_hygiene.py`](../../tools/research_compose_hygiene.py)
  checks that shared `b` row spelling does not grant capture for annotation-free
  `compose`.
  [`research_callback_ab_solution_equivalence.py`](../../tools/research_callback_ab_solution_equivalence.py)
  exhausts 65,536 finite B/A relation pairs, checking exact solution
  preservation for entailed coordinate propagation with the final query
  retained, then samples 2,048 tagged method/adapter/residual/evidence cases
  and shrinks endpoint-copy and evidence-erasure failures. See its
  [progress record](../progress/2026-10-05-callback-ab-solution-equivalence-playground.md).
  [`research_callback_scoped_lift.py`](../../tools/research_callback_scoped_lift.py)
  exhausts a finite total-coordinate lift at its original binder scopes and
  shrinks three scope-mutation failures; it does not close production membership
  factorization. See the
  [scope-lift record](../progress/2026-10-05-callback-scoped-lift-playground.md).
  [`research_callback_consumer_factorization.py`](../../tools/research_callback_consumer_factorization.py)
  differentially checks finite `Force >>= rebind >>= body >>= consumer`
  request/resumption composition and derives `d-`/`d+`/`b+` occurrence views
  from the composed trace; it does not interpret production bounds. See the
  [consumer-factorization record](../progress/2026-10-05-callback-consumer-factorization-playground.md).
  [`research_callback_endpoint_source_join.py`](../../tools/research_callback_endpoint_source_join.py)
  joins those finite source observations to the existing B endpoint trace,
  checking the event-derived `d-`/`d+`/`b+` identities. It does not derive
  production source evidence or descriptor membership; see its
  [progress record](../progress/2026-10-05-callback-source-endpoint-join.md).
  [`research_mixed_effect_subtraction.py`](../../tools/research_mixed_effect_subtraction.py)
  characterizes 96 fixed histories under selected-first shallow handling,
  one raw-suffix resumption, and a terminal outer-family filter. Its minimized
  same-family pair shows why support-wide cancellation cannot establish
  complete-image absence; its spec audit found no issue within that bounded
  model. It does not model annotation semantics or general handler images; see
  the [descriptor derivation record](../progress/2026-10-05-function-effect-descriptor-derivation.md).
  [`research_effect_component_membership.py`](../../tools/research_effect_component_membership.py)
  checks the selected origin-insensitive callback capture rule against 256
  finite typed views: direct and caller-owned `Force` events agree when their
  contract, incidence, and active boundary agree, while family-only matching
  is rejected. This does not derive surface annotation-to-profile elaboration;
  see the [membership reconciliation record](../progress/2026-10-05-effect-component-membership-playground.md).
  [`research_effect_attachment_subtraction.py`](../../tools/research_effect_attachment_subtraction.py)
  checks 256 event/attachment projections and differentially matches 96 cases
  from the shallow-resumption probe. It shows that consuming one attached
  contribution does not erase a same-family point still present in the
  complete output image; it does not derive source attachment. See the
  [support/attachment record](../progress/2026-10-05-effect-attachment-subtraction-playground.md).
  The [conditional concrete-profile derivation](../progress/2026-10-05-concrete-capture-profile-derivation.md)
  unfolds the selected `Captureν` rule under an already supplied `Γ_b`,
  `Inc_C`, and active typed port. It establishes origin-insensitive local
  eligibility, not surface annotation elaboration or mixed-row membership.
  [`research_callback_admission_hiding.py`](../../tools/research_callback_admission_hiding.py)
  exhausts the finite admission-uniform hiding lemma and minimizes a failure
  when the premise is removed. See its
  [progress record](../progress/2026-10-05-callback-admission-hiding-playground.md).
  [`research_inequality_endpoint_dispatch.py`](../../tools/research_inequality_endpoint_dispatch.py)
  checks the four endpoint dispatch cases and the approved nontransitive
  optional-record witness over a finite variable-edge graph, then enumerates
  lower/upper middle witnesses and rejects direct concrete composition as a
  complete existence test; it does not define general replay policy or a
  complete solver. See its
  [progress record](../progress/2026-10-05-inequality-endpoint-dispatch-playground.md).
  The optional-record nontransitivity witness also refutes lifting the
  candidate pure source/recursive-group preorder adequacy proofs by treating
  local concrete successes as a transitive relation: a `Sub` chain through
  `{}` derives a type that the direct Name endpoint comparison rejects. The
  conditional preorder proofs remain valid in their stated structural
  fragment. See the [source-adequacy obstruction](../progress/2026-10-05-source-adequacy-concrete-transitivity-obstruction.md).
  A current HIR coverage audit finds surface `as` syntax retained through
  association only as wrapper/range (the target type subtree is dropped) and
  rejected before constraint generation, so the witness is
  not an accepted production cast-chain bug and current rejection selects no
  successor source restriction. See the
  [source-boundary coverage characterization](../progress/2026-10-05-source-boundary-coverage-audit.md).
  The current HIR-backed Lambda realization candidate for `id` and `zero`
  inspects their actual Function facts and public schemes, then checks a finite
  typed-observation lift; a separate bounded state-machine test exercises two
  `Force(D) >>= B` resumption splits while preserving the Pure value's actual
  role under a Handler callback view. A follow-up starts from the actual HIR
  `id` and `zero` artifacts, enumerates handled Force histories of length zero
  through two over two values and two states, then resumes the designated
  consumer from each callback's returned state while checking that callback
  entry is not replayed. Neither test identifies
  its candidate relation with production bounds. See its
  [progress record](../progress/2026-10-05-source-indexed-function-realization-playground.md).
  Its newer HIR-backed returned-Function check exhausts 96 declaration-order
  and parameter-renaming variants of `id`, `wrap ignored = id`, and two aliases;
  it confirms root identity, routed source uses, fresh closed-use instantiations,
  and nested principal diagonal schemes. Current HIR still has no application
  lowering; a test-only exact-trace composition covers 1,314 bounded
  wrapper-return/future-call histories against those HIR identities. Production
  invocation and endpoint adequacy remain open. Review caught and the test
  repaired a circular expected-state check; details are in the progress record.
  The historical raw unary-lambda Error-token probe and its separate header
  predicate are superseded by the approved
  [production parser and construction proof](../progress/2026-10-15-unary-lambda-parser.md).
  The research adapter now consumes real LambdaExpression children and Rowan
  ranges; parenthesized/ML application nesting and negative admission controls
  remain checked. Its candidate maps `host (\x -> x)` to an Apply with an
  identity-lambda argument, but still supplies no production HIR or typed
  evidence. Historical investigation details remain in the
  [HIR/source-core audit](../progress/2026-10-04-hir-source-core-boundary.md).
  Its test-only mixed-call candidate preserves nested application arguments,
  then mirrors typed-core §6 `(I,d,n)` shape for five ordinary-call forms
  under finite monomorphic Gamma. It records only structural-shadow triples;
  production lowering, complete Function constraints, and callback endpoints
  remain open. A new test starts from the actual `BindingBody` CST of
  `my call f x = f x` and builds the existing Apply candidate; production
  lowering still rejects the multi-parameter header before reaching that
  body, and has no resolved Apply node. See the same HIR/source-core audit.
  A test-only scoped candidate now turns the actual `call` and `higher`
  declaration CSTs into nested lambda/application shapes with parameter-index
  resolution. The parenthesized same-line addendum closes the `compose`
  argument parse error, and its exact declaration now reaches the scoped
  candidate. Production still rejects multi-parameter headers. A test-only
  scoped synthesis now builds typed-core §6 lambda/result skeletons from the
  actual `call` and `compose` candidates; its mutant check detects loss of the
  inner computation effect from `compose`'s whole argument. It uses only an
  opaque fiber label, not a real `(ν,K,D)` interpretation or complete Function
  query, and proves no principal scheme or execution adequacy. See the
  [HIR/source-core audit](../progress/2026-10-04-hir-source-core-boundary.md)
  for scope and verification limits.
  [`research_scoped_compose_execution.py`](../../tools/research_scoped_compose_execution.py)
  differentially checks bounded recursive-source versus generated-core
  execution for canonical `call`/`compose` Value-entry trees. It exercises
  delayed arguments, receipt/Force/rebind ordering, resumed state, occurrence
  identity, and pending suffixes, killing four deliberate mutants. The
  primitives are supplied and finite; this does not parse source, interpret
  `(nu,K,D)`, solve Function effects, or establish callback/production
  adequacy. See its [progress record](../progress/2026-10-05-scoped-call-compose-execution-probe.md).
  The focused test
  [`research_parsed_scoped_call_compose_execution_bridge`](../../crates/yu-hir/src/lib.rs#L1582)
  now starts from the actual parsed declaration CSTs, applies the existing
  scoped candidate/skeleton builders, then compares recursive source
  evaluation with an independent stack evaluator. It checks 128 bounded
  configurations and kills receipt-order and stale-state mutants. The
  environment, primitives, and one-request behavior are supplied; no
  production HIR, typed-flow solving, handler semantics, Function membership,
  or adequacy theorem is established. See its
  [progress record](../progress/2026-10-05-parsed-scoped-execution-bridge.md).
  [`research_function_shadow_obstruction.py`](../../tools/research_function_shadow_obstruction.py)
  executes the finite Value-versus-Computation entry witness against the
  identical value-only Function shadow; it is not a source or endpoint-query
  result. See its
  [progress record](../progress/2026-10-05-function-shadow-obstruction-playground.md).
  Exact limits and minimized obstructions are in the
  [progress report](../progress/2026-10-04-callback-principal-playgrounds.md).
- **Completed narrow experiment:**
  [experimental parent/use transport](2026-10-04-intrusion-experimental-transport.md)
  is Authoritative for a `cfg(test)` graph transport prototype only. Its
  differential tests do not establish source root classification or bound
  adequacy. The [2026-10-05 test follow-up](../progress/2026-10-05-intrusion-transport-test-followup.md)
  records expanded malformed-partition and allocation-failure checks. The
  separate structural FMP theorem below now closes the pure
  existence gate; research playground authority remains as recorded.

- **Reviewed structural FMP theorem — classification A:**
  [finite fence completion](2026-10-04-structural-fmp-fence-completion.md)
  constructs a regular model from every arbitrary permitted model of the same
  fixed normalized pure package. At most `8^N` states preserve exact shared
  recursive descriptors, mandatory Record width, Function variance, invariant
  coordinates and arbitrary rigid permission sets. The complete quotient
  equivalence proves finite-quotient conflict reflection and the former BR
  residual. Two independent reviews are clean; no extra source premise or
  compiler implementation is selected. See
  [proof/review record](../progress/2026-10-04-structural-fmp-proof.md).
- **Reviewed effective-search corollary:** under finite fixed-head/label
  input, decidable identity for the finitely many input primitive/rigid atoms,
  and decidable membership checks for input rigid atoms, FMP's `8^N` witness
  bound yields a terminating exhaustive satisfiability procedure for this pure
  package. It does not decide residuals
  with `Guard`, `Phi`, `K,D`, effects or source admission and has no production
  authority. See the
  [corollary derivation](../progress/2026-10-05-pure-structural-effective-decision-corollary.md).
- **Executable finite-fence research candidate:**
  [`check_structural_fence_completion.py`](../../tools/check_structural_fence_completion.py)
  runs the reviewed profile construction outside production. Its initial
  differential/exhaustive loop exposed five implementation defects, now
  minimized and retained as regressions. Focused tests, one- and two-root
  exhaustive package families, targeted distinct rigid permissions, and
  bounded shared-graph searches through three nodes pass; independent review
  and narrow repair reviews are closed, as recorded
  in the [playground record](../progress/2026-10-05-structural-fence-playground.md).
  The finite searches are characterization evidence, not a proof, production
  algorithm, or resource policy. Remaining inference work centers on the
  production callback and principality bridges.
- **Earlier reviewed finite-feedback theorem:**
  [finite feedback quotients](2026-10-04-structural-finite-feedback-quotients.md)
  preserves any fixed finite number of mutual feedback rounds on one finite
  surjective monoid quotient, including full domain/head/child coherence.
  Its classification C and open BR status are historical: finite fence
  completion now proves FMP and BR. The finite-stage theorem and the
  non-cofinal failed-quotient examples remain valid.
  [`tools/research_structural_feedback.py`](../../tools/research_structural_feedback.py)
  is the first executable restricted-package playground: it checks the
  complete feedback/coherence schedule for `q=Function(x,Int), x<:q`, sweeps
  cutoff quotients, exhausts labelled two-generated monoids through size 4,
  and independently checks graph witnesses. It is bounded characterization
  evidence only; the separate proof above establishes FMP. Details are in the
  [progress follow-up](../progress/2026-10-04-structural-fmp-feedback-rank.md#executable-finite-quotient-playground-follow-up-2026-10-04).
  [`tools/research_gamma_quotients.py`](../../tools/research_gamma_quotients.py)
  generates 495 small packages in the one-fixed-Function/one-Int/one-free-root
  fragment, including separate duplicate bounds, and checks 222,255
  package/quotient pairs through monoid size four. All surviving graphs are
  independently checked; this generated fragment still does not establish
  unrestricted FMP. See the
  [generated-package search record](../progress/2026-10-04-structural-fmp-feedback-rank.md#generated-package-quotient-search-2026-10-04).
- **New reviewed structural existence result:**
  `notes/design/2026-10-04-preclosed-structural-regular-witness.md` proves
  arbitrary-tree/regular-tree equivalence and a terminating witness
  construction when every flattened variable has constructor bounds in both
  directions. Multiple open recursive anchors, mandatory Record width,
  Function contravariance and invariant coordinates are included. This
  source-checkable condition constructs fresh graphs beyond anchor selection;
  it does not cover one-sided/unbounded roots or full joint inference.
  `tools/check_preclosed_structural_witness.py` is a research checker only.
- **Reviewed callback abstraction boundary:**
  `notes/progress/2026-10-04-callback-local-abstraction-boundary.md` proves
  that an endpoint-only interpretation can erase the value dependence needed
  by exact source-recipe inversion. This is not a callback counterexample.
  A finite locally saturated scalar generator has a projected first-order
  lift with independent admission. The later source-indexed realization
  below transports whole generated typed observations through higher-order
  histories; the scalar theorem itself does not establish that result or the
  actual production endpoint bridge.
- **Closed source contract:** callback literal B constraint generation and
  B-equivalent A optimization are recorded in the Authoritative callback
  design, §2.1. The earlier expected-context, Handler-role, independent
  endpoint, and ordinary `F_lit <: F_cb` requirements were already in scope;
  the explicit B-normative label, optimization allowance, and equivalence
  dimensions record the user's 2026-10-04 clarification. No API or algorithm
  is selected.
- **Reviewed conditional source-generated results:** the separate
  `notes/design/2026-10-04-source-generated-callback-structural-theorems.md`
  proves full Pure-value bound containment for an explicit positive
  source generator and shared-body conservative extension, with independent
  challenge admission; it also proves arbitrary-to-regular structural
  completion when each free component has closed anchors or one open anchor,
  under the stated rigid-scope condition. These are conditional mathematical
  results, not full production-generation or principal-inference theorems.
- **Future data-existential compatibility:** the Authoritative
  `notes/design/2026-10-04-existential-data-witness-compatibility.md` permits
  future constructor/package-local existential witnesses without requiring
  every hidden type to become a public data parameter. This is a compatibility
  constraint only; no data-existential syntax, inference support, proof scope,
  solver carrier or implementation is selected. It records the user's
  illustrative `ref 'e 'a` sketch (`run` universally quantifies `'b`; the
  write path separately existentializes it) and read/write paths as a
  candidate only; their quantifier interaction and typing/runtime rules remain
  open. Existing
  operation/request existential designs remain separate.
- **Reviewed direct callback follow-up:**
  [source-indexed endpoint realization](2026-10-04-source-indexed-callback-realization.md)
  constructs reference membership and query-independent admission rules and
  proves their whole-bound crosswalk with Theorem C. Applying the approved
  typed projection once to whole observations covers all finite latent and
  resumption histories. The new user request reopened direct proof attacks;
  this closes the constructed reference's crosswalk, while current production
  conformance and full B evidence generation remain open. Two independent
  reviews certify only that limited scope. See the
  [combined proof record](../progress/2026-10-04-callback-principality-direct-followup.md).
- **Reviewed residual attack — certificates and ordinary uses:**
  [certified callback transport and finite constrained uses](2026-10-04-certified-callback-and-constrained-use.md)
  derives all finite-history membership/admission transport from finite
  local certificates. Its callback comparison is pointwise at the complete
  fiber; additional hiding is proved when checked admission is constant
  across the forgotten fiber. Whole-copy/graft/direct-query construction
  supplies a finite ordinary use for each public view; exact projection is
  the remaining scoped entailment. No additional map calculus or explicit
  universal-preimage descriptor is required for that route. Production
  certificate derivation, legal common descriptors and all-view query
  completeness remain open, with the actual exported root unchanged.
  Independent compiler/spec review and repaired hidden-admission finding are
  recorded in the [residual attack](../progress/2026-10-04-callback-principality-residual-attack.md).
- **Reviewed experiment-guided callback/allowance attack:**
  [coverage and source-preserving composition](2026-10-05-callback-coverage-and-source-joins.md)
  proves total-definition elimination, exact linked bound equality on checked
  fibers and a necessary/sufficient Coverage law for legal old-witness
  marginals. A finite source dependency closure gives a safe-hiding class;
  higher-order and scalar-selector source examples defeat independent
  marginal/representative reconstruction. The
  [new checker](../../tools/research_callback_admission_coverage.py) exhausts
  4,096 finite encodings. Production conformance, legal common descriptors and
  all-view direct-query evidence remain open, classification C. See
  [proof/review record](../progress/2026-10-05-experiment-guided-main-gate-attack.md).
- **Reviewed source factor-cover proof and actual-query preservation:**
  [source factor coverage](2026-10-05-source-factor-cover-and-query-preservation.md)
  supplies a finite sufficient criterion for exact source relation joins and
  a sharp converse uniform over independent factors on nontrivial products.
  Exactness preserves every unchanged client and existing direct evidence.
  A fixed supplied-primitive XOR/provider example defeats all proper marginals
  of its ternary dependency; 148,224 finite cases corroborate the proof.
  Production generalization/use membership and common-component typed-view
  introduction remain open, with totality and all-view quantifiers unchanged.
  Review status is in the [attack record](../progress/2026-10-05-factor-cover-main-gate-attack.md).
- **Conditional source contracts and common allowance:**
  [source contracts](2026-10-05-source-contracts-and-common-allowance.md)
  specify finite emission, active constrained-root interpretation and local
  whole-query proof rules. Conditional constructor correspondence, guarantee-only
  common extension and all finite source-allocation-view factorization use the
  actual common export and original residual. Approved Option 2 is respected:
  a positive guarded production abstraction permits unanchored root extras and
  transports paired base/envelope proofs. The concrete abstraction rules are
  proposed, not selected; unrestricted all-view/source coverage and production
  conformance remain open. Review and finite evidence are in the
  [conditional proof record](../progress/2026-10-05-source-contract-conditional-proof.md).
- **User-approved production Function-bound membership policy (Option 2):**
  production bounds may admit endpoint-compatible observations beyond the
  source-generated Theorem C relation, but matching ports alone do not admit
  arbitrary continuations, origins, authority, or dependencies. The exact
  exhaustive membership/admission rule and actual-to-checked proof remain
  open; no extra member or implementation is selected. See the
  [approved answer](../../questions/2026-10-05-production-function-bound-membership/approved-answer.md)
  and [receipt](../../questions/2026-10-05-production-function-bound-membership/receipt.md).
  A direct main-gate audit finds the required exhaustive, comparison-independent
  production membership/admission interpretation is still absent from current
  HIR/F5 owners; it records the exact premise without selecting `W`/`Z`, a
  carrier, or implementation. See the
  [interpretation audit](../progress/2026-10-05-production-complete-function-interpretation-audit.md).
  Typed-core §6 is Draft and proposes a whole-carrier source-application
  obligation with typed path/contract evidence; it does not specify the
  endpoint/path translation into an ordinary `A <: B` query or a complete
  source-admission rule. The required gate is exhaustive, comparison-
  independent production admission/satisfaction and `D_C ⊆ D_A`,
  `P_A ⊆ P_C` containment over the approved basis. Source-generation
  correspondence is one sufficient route for bounded reference members;
  Option 2 permits independent containment proofs and production-only members.
  Current HIR emits no callback application node. No new carrier is
  established. Concrete-success noncomposition follows from the existing
  optional-record witness; adapter-evidence composition remains a source proof
  obligation. See the [inlet/admission audit](../progress/2026-10-05-production-function-inlet-admission-audit.md)
  and [endpoint-dispatch characterization](../progress/2026-10-05-inequality-endpoint-dispatch-playground.md).
- **User-approved production Function-denotation basis (A):**
  [the q1/d1 handoff](../../questions/2026-10-05-production-function-denotation/approved-answer.md)
  selects the existing complete typed-observation `Rel_C` fiber, constrained
  by independent endpoint/role/path/origin/continuation/scope/authority/
  dependency interpretation, with separate comparison-independent context
  admission. This closes the A/B basis choice, not the local `DescMem` or
  admission clauses. The direct follow-up identifies that missing judgment;
  no new carrier or `W/Z` rules are selected. See its
  [audit record](../progress/2026-10-05-production-function-denotation-followup.md)
  and [receipt](../../questions/2026-10-05-production-function-denotation/receipt.md).
- **Active callback gate — production conformance:**
  `notes/design/2026-10-04-production-callback-endpoint-generation-draft.md`
  specifies the bounded application HIR/lowering, B step 6 finite endpoint
  rule, and Theorem C checked lift without adding a carrier. The rule reuses
  source segments, operand tuples, binder scopes, `nu,K,D`, and existing
  occurrence/path/Flow/Observe/subtraction evidence. Theorem C remains limited
  to prebuilt Pure values; inline literals use the ordinary `F_lit <: F_cb`
  comparison. The production target is `D_C ⊆ D_A` and
  `∀c ∈ D_C, P_A(c) ⊆ P_C(c)` under an exhaustive, comparison-independent
  membership/admission rule. Theorem C and `P_ref` remain source-generated
  results. The older source route through
  `D_C ⊆ D_GC ⊆ D_GA ⊆ D_A`, actual-member factorization through `J_arg`,
  entry/rebind, body, designated result consumer and `J_call`, plus checked
  generator embedding, remains sufficient but is no longer mandatory for
  every production member. Any production-only member needs retained-evidence
  factoring or a separate full checked-containment proof; port shape alone
  does not admit arbitrary continuations, origins, authority, or dependencies.
  The total-coordinate lift preserves the old tuple inside the generated
  relation. The merged scalar
  local-abstraction theorem only covers projected first-order observations
  and is not production authority. B-literal
  occurrence/attachment projection and
  raw/HIR parser recovery remain generation-conformance obligations. The
  design is Draft and implementation is not authorized. Historical proof
  attacks remain in
  `notes/progress/2026-10-04-value-entry-bind-projection.md` and
  `notes/progress/2026-10-04-direct-main-gate-attacks.md`. A fresh production
  owner trace for identity and scalar Lambda bodies is in
  `notes/progress/2026-10-04-lambda-endpoint-owner-trace.md`.
- **Structural gate:** normalized pure regular-witness existence is closed by
  the finite-fence FMP theorem, including descriptor prefix shifts and
  variance/width-directed suffix descent. The finite residual presentation,
  principal/effective projection and production source/effect correspondence
  remain distinct. The complete address quotient retains coherence,
  activations and arbitrary rigid permissions; arbitrary `Guard`/`Phi/K,D`
  and optional Records are outside the theorem. The direct MSO route still
  fails, and the standard guarded-BPA reduction still requires a different
  recursive-constructor family. A
  reviewed information-meet invariant blocks aperiodic tiling reductions
  under finite-depth, all-translates decoding assumptions; marker provenance
  also blocks prefix-pop/suffix-append alone. A descriptor-monoid subtree-meet
  fold fails on a regular two-variable example but does not refute FMP.
  The exact constructor-family mismatch for the guarded-BPA result and the
  additional comparison-relation boundary are mapped in
  `notes/progress/2026-10-04-bpa-recursive-constructor-transfer-audit.md`.
  The current error-free production HIR's structural value shadow has a
  separate finite source-generation proof for `Λ = ∅` and thus a regular
  witness under Theorem S; it is explicitly not an equivalence to F5's
  polarized four-port Function constraints. See
  `notes/progress/2026-10-04-production-hir-empty-record-shadow.md`.
  A source-generation theorem checks the actual F5 value-skeleton projection
  across current binding HIR (integer, alias, and one-parameter lambda forms)
  when cross-SCC definition uses target alias chains ending in integers. The
  finite source/SCC check establishes Theorem S incidence after actual internal and
  restricted incoming routes. Arbitrary structured incoming schemes and the
  retained coupled effects remain outside the result; see
  `notes/progress/2026-10-04-production-f5-value-skeleton-hir-incidence.md`
  and its narrower predecessor
  `notes/progress/2026-10-04-production-f5-value-skeleton-selector.md`.
  A reviewed extension admits cross-SCC targets ending in an own-parameter
  identity lambda, alias-only cycle, or a finite chain of ignored-parameter
  lambdas ending at an integer. Its additional premise is source-checkable
  one-anchor incidence after actual F5 value projection/routing/normalization;
  simultaneous redirection proves a regular witness, preserving F5 `Top` as
  an opaque proof token only. This is neither a semantic interpretation of
  `Top` nor a claim that all Yulang sources meet the premise. Arbitrary
  structured scheme source correspondence and coupled effects remain open.
  See `notes/progress/2026-10-04-identity-incoming-incidence-extension.md`.
  Those source incidence results are separate from the full pure FMP proof.
  See the direct-main-gate progress record for the historical attempts.
- **Principal schemes:** the source-generated common-allowance theorem remains
  open. Source rules first need to construct role-indexed complete Function
  views; conditional on that, they still need to interpret scoped abstract
  effect allowances as correlated port views before fixed-fiber totality and
  all-view factorization can be proved. Annotation/callback-context overlap is
  unresolved. No counterexample or stronger uniform-quantifier obstruction is
  established. The production callback endpoint crosswalk is separate. See
  `notes/progress/2026-10-04-principal-scheme-acceptance-criteria.md`.
- **Reviewed principal-allowance localization:**
  [joint presentation and safe context preimages](2026-10-04-common-allowance-context-preimage.md)
  proves finite intensional forward amalgams, the domain-safe universal
  preimage equivalence, and complete-contract joins with the exact required
  challenge condition. A finite monotonicity countermodel rules out a general
  positive-only preimage construction. Legal shared descriptor realization
  and admissible maps for all public views remain unproved, with
  `∀s∈Sξ. ∃a. Qξ(s,a)` and `∀V. ∃m_V` unchanged. This is not a source
  counterexample or a new effect-component semantics.
- **Other open gates:** source State/reference bridge and global source
  acceptance/principality/lifecycle remain open; see `tasks/current.md` for
  the compact active summary and linked progress records for evidence/history.
  The [bounded StateSlot restart playground](../progress/2026-10-05-local-state-restart-playground.md)
  checks captured-alias visibility and activation separation only under an
  explicit candidate store model; it does not close missing source-step
  equations. The [multi-shot resume probe](../progress/2026-10-05-local-state-multishot-playground.md)
  adds branch-local replacement/read histories and rejects snapshot-capture
  and shared-mutable-store mutants under supplied candidate equations; it
  does not define the missing Yulang State/resumption semantics.

These pointers summarize navigation only; authority and status remain those of
the source design documents and explicit user decisions.

| Document | Status | Authority scope | Approved / state | Useful locator or gate |
|---|---|---|---|---|
| `notes/progress/2026-10-05-residual-admission-source-premise-audit.md` | Read-only design-source characterization; no source or implementation authority | Which source premise remains for the reviewed conditional canonical-graft membership theorem | Structural upper/permission transport is already proved; primitive Guards/Phi/K,D interpretation over the changing endpoint and derived-comparison context remains unspecified. No source counterexample is established; preserve existential original assignments. |
| `notes/design/2026-10-05-source-contracts-and-common-allowance.md` | Reviewed conditional theorem package; base compiler/spec/repair and Option 2 mathematical/conformance reviews closed | Additional source-generated assumptions permitted; approved Option 2 allows conservative root extras; concrete formation/abstraction clauses remain Draft; no implementation authority | Local source-base correspondence; guarantee-only common extension; actual-export allocation-view factorization; finite complete-query calculus; guarded positive abstraction with unanchored extras; 648 absorption and 648 allocation cases plus 884,736 finite abstraction comparisons | Concrete membership/abstract primitives and query rules remain proposed. Current production conformance, unrestricted source/value/capture/view coverage, all full principal schemes and residual/lifecycle gates remain open. |
| `notes/design/2026-10-05-source-factor-cover-and-query-preservation.md` | Reviewed limited mathematical theorems; two independent clean reviews | Source-local decomposition of existing complete relations; no representation or implementation decision | Complete factor coverage proves exact reconstruction and preservation of every unchanged client/direct-evidence relation; sharp uniform necessity on nontrivial products; fixed observable parity route counterexample; 148,224-case research checker | Full production membership, legal common-component formation/typed-path interpretation and all-valid-view extension through the designated export remain open. Classification C; structural FMP remains A. |
| `notes/design/2026-10-04-source-indexed-callback-realization.md` | Reviewed limited mathematical construction; no implementation authority | Source-associated reference endpoints in Theorem C's decorated immutable envelope | Finite root membership/admission clauses give a bidirectional constructor correspondence with generated bounds. Whole-observation typed projection preserves all finite latent and resumption histories. Two independent reviews closed with one minor owner-name correction. | Option 2 permits production-only observations under an exhaustive rule; it does not make `P_ref` mandatory production semantics. Exact production membership, actual-to-checked containment, and all-source B decoration generation remain open. |
| `notes/design/2026-10-04-common-allowance-context-preimage.md` | Reviewed semantic results and exact remaining realization obligations; no implementation authority | Complete forward relations, safe universal context preimages and common semantic contracts at one fixed fiber | Finite joint forward presentation; image/preimage equivalence with independent admission; finite separation from uniform positive formulas; least common semantic contract with exact domain condition. Two independent clean reviews. | Legal common descriptors and all-view solution-preserving instantiation remain unproved. The later constrained-use theorem supplies the finite ordinary map construction and replaces that separate concern with its exact-projection entailment. No new descriptor kind, row rule or main-gate closure. |
| `notes/design/2026-10-04-certified-callback-and-constrained-use.md` | Reviewed limited mathematical theorems; compiler/spec review and mathematical repair delta closed | Finite existing-presentation certificates, fixed-fiber callback transport, admission-uniform hiding, and finite ordinary constrained uses | Complete membership/admission inversion for all finite histories; safe-hiding lemma and countermodel to unrestricted hiding; whole-copy/graft/direct-query construction with exact public projection iff scoped extension; explicit designated-root distinction | Production input/certificate derivation, safe hiding of any remaining admission dependencies, legal common descriptor realization and direct-query completeness for all valid public views remain open. Classification C; no semantics, carrier, rejection rule or implementation change. |
| `notes/design/2026-10-04-structural-fmp-fence-completion.md` | Reviewed mathematical theorem; classification A; no compiler implementation authority | Current normalized pure structural carrier, exact descriptors and arbitrary rigid permissions | Arbitrary-tree satisfiability implies a permitted simultaneous regular graph with at most `8^N` states. Three-edge arbitrary-tree fences, finite distance profiles, native Record landmark proofs, exact successor identity and a same-address rigid shadow establish FMP, complete finite-quotient conflict reflection and BR. Two independent clean reviews and exhaustive finite-algebra checks. Executable research candidate and finite checks are recorded separately; they add no theorem or authority. | No additional source predicate; full production/source and Function/effect correspondence, arbitrary joint predicates, principal residual/projection and lifecycle remain open. Proof/review: `notes/progress/2026-10-04-structural-fmp-proof.md`; executable characterization: `notes/progress/2026-10-05-structural-fence-playground.md`. |
| `notes/design/2026-10-04-preclosed-structural-regular-witness.md` | Reviewed conditional theorem and research checker; no compiler implementation authority | Two-sided constructor bounds in the finite pure structural package, with the stated rigid-permission premise | Finite closure decides arbitrary-tree and regular-tree satisfiability; reachable pairs of nonempty variable subsets construct a simultaneous regular witness of at most `(2^n-1)^2` nodes, including multiple open anchors, recursive equations, Record width, Function contravariance and invariant coordinates. Independent theorem/checker review found no issues. | The predicate is checked on the generated package, not established for all Yulang sources. One-sided/unbounded roots are outside this conditional construction and covered separately by the full pure FMP theorem. Effects, joint predicates, principal projection and full source adequacy remain open. Verification: `notes/progress/2026-10-04-preclosed-structural-witness-review.md`. |
| `notes/design/2026-10-04-source-generated-callback-structural-theorems.md` | Reviewed conditional mathematical theorems; no implementation authority | User permits additional source-generated hypotheses; no existing source contract is superseded | Theorem C: explicit positive source relation generator, exact shared-body lift by fresh total-function coordinates, query-independent source challenge rules, and full conservative bound containment in one `ν,K,D`; callback transport repair independently re-reviewed. Theorem S: root-only closed-anchor components plus guarded single-open-anchor reconstruction, arbitrary-to-regular reflection, terminating existence construction, and an `N+M` witness bound. A separately reviewed conditional extension handles multiple open anchors when a finite selector redirects each free component to an incident descriptor and directly certifies every original comparison; its finite checker is a terminating positive recognizer, and a satisfiable non-selector example shows this remains incomplete. | Full pure structural regularity/FMP is now proved separately by finite fence completion. Production/raw-source correspondence, arbitrary callback annotations, State/imports/general schemes, arbitrary joint effects/guards, principality and lifecycle remain open. Failure of any source predicate is outside the theorem, not a rejection policy. Proof and review records: `notes/progress/2026-10-04-source-generated-theorems.md`, `notes/progress/2026-10-04-multi-anchor-selector-witness.md`. |
| `notes/design/2026-10-04-production-callback-endpoint-generation-draft.md` | Draft; design/proof gate only; no implementation authority | Proposed raw/HIR application node and lowering, callback B step 6 completed endpoint construction shape, and source-to-endpoint correspondence with Theorem C | Reuses source graph, operand tuples, binder scopes, `nu,K,D`, existing occurrences and provenance; checked lift is old-tuple-preserving total-coordinate extension. The user-approved Option 2 policy permits production-only endpoint-compatible observations but selects no extra members. Theorem C's finite generator audit remains the source-reference result; production membership and full actual-to-checked containment remain open. The prior G crosswalk is sufficient, not mandatory. No carrier/implementation authority follows. |
| `notes/progress/2026-10-05-function-effect-descriptor-derivation.md` | Focused derivation attempt; no annotation or implementation authority | Value-entry callback execution composition and the mixed abstract/concrete effect-descriptor gap | Derives the complete invocation operational skeleton with result-consumer qualification; same-family shallow resumption rejects support-only global cancellation | Comparison-independent source annotation clause, complete production descriptor membership/admission, and actual-to-checked containment remain open; no carrier insufficiency established. |
| `notes/design/2026-10-03-callback-context-delivery.md` | Authoritative bounded source contract; no compiler/API implementation authority | **Closed source contract:** callback literal context selects Handler/boundary before body constraints; endpoints are independently synthesized; completed interface checked by ordinary `F_lit <: F_cb`. B is normative/reference generation. A is permitted only as B-equivalent scheduling/partial evaluation; it preserves accepted programs, principal solutions, method/adapter choices, and residual/evidence semantics. Existing Pure values retain actual role and §21 entry; callback slot supplies a typed invocation view. | §§2–2.1 and 4. Expected-context delivery, independent endpoints, and ordinary inequality were already in the Authoritative contract. The user’s 2026-10-04 clarification explicitly names B as normative and A as an optimization subject to observational/solution equivalence. No API or optimized algorithm is selected. | The latest user request reopened direct proof attacks; the limited reference-realization result is in `notes/design/2026-10-04-source-indexed-callback-realization.md`. Production endpoint conformance and the B port-construction bridge remain tracked in `notes/design/2026-10-04-production-callback-endpoint-generation-draft.md`; earlier countermodels and proof attempts remain historical in `notes/progress/2026-10-04-direct-main-gate-attacks.md` and `notes/progress/2026-10-04-value-entry-bind-projection.md`. |
| `notes/design/2026-10-05-inferred-function-call-views.md` | Authoritative user-approved source-formation direction; no complete inference rule or implementation authority | Shared role-indexed callback contract from relevant declarations, definitions, uses, and recursive components; stable slot/profile, typed paths, owner/receiver and one original joint `nu,K,D`; Q-independent admission | Unannotated `f` in the approved `apply f x = f x` pattern starts with a fully protected Handler view and is resolved from ordinary-value evidence; absence of annotation causes full protection, while the specified `[io]` annotation permits only that effect's removal | Exact source judgments, role-resolution and annotation-to-profile rules, uniqueness/principality, source adequacy, exhaustive Option 2 conformance and inference implementation remain open; callback B and actual callable roles remain unchanged. See the [approved handoff](../../questions/2026-10-05-function-call-view-formation/receipt.md). |
| `notes/design/2026-10-06-directional-inferred-effect-protection-addendum.md` | Draft formalization of a directly selected user rule; no full-theorem or production authority | Protected inferred variable exposed by an original upper Function view protects that view's output-effect occurrence; no reverse protection of an existing lower/provider effect | Direct user wording selects this scoped direction; the addendum records it without adopting the superseded E/R profile table | Source-wide seed/exposure generation, typed incidence and receipt/capture correspondence, full seed/refined solution preservation, soundness, principality, admission, source adequacy and production Option A/2 remain open |
| `notes/design/2026-10-02-parametric-component-linking.md` | Draft; prior linking/binder and §7 executable-linking packages independently reviewed; no implementation authority | graph grafting, joint relational linking and contextual recertification | §7 constructs a merged kernel from finite supplied open templates before query lowering and joint safety/image saturation | general Function comparison, source-template generation, effective complete checking, instance completeness and lifecycle remain open |
| `notes/design/2026-10-02-heap-backed-client-interactions.md` | Draft; M3 semantic/conformance package reviewed; no implementation authority | finite command driver and heap carrier for a template-closed interaction signature | typed packet pool covers unbounded retained handles without supplied finite client code; conditional command-prefix and weak-store simulation | source interface encapsulation, command/fault refinement, finite predicates and acceptance bridge remain open; no class-3 witness |
| `notes/design/2026-10-02-counting-aware-row-projection.md` | Draft; M3 semantic/conformance package reviewed; no implementation authority | row membership plus correlated request capacities | finite exact projection with residual threshold at most `b 2^h`; separate finite-row and arbitrary-subset interpretations | type/domain predicates, full invocation checking and source principality remain open; no source row-domain choice |
| `notes/design/2026-10-03-scoped-structural-projection.md` | Draft; M3 theorem and invariant/closed-import delta independently reviewed; no implementation authority | scoped checking and symbolic projection in a regular structural fragment | best visible comparators; declared variance/invariant support; five-profile closed-import transformer retaining original coordinates | flexible constraint solving, declared bounds, complete effectful/family interfaces and lifecycle remain open; no source-envelope restriction |
| `notes/design/2026-10-03-scoped-constraint-solving.md` | Draft; M3 equality/closed-saturation theorem package independently reviewed; no implementation authority | scoped rational equality quotient and closed structural subtype solving | relative most-general quotient with arbitrary lexical permission-set propagation; finite greatest-relation saturation after fixed quotient | open-head/Record-extension residual factorization, source generation, effectful/family interfaces and lifecycle remain open; no non-finite witness or source-envelope restriction |
| `notes/design/2026-10-03-open-residual-factorization.md` | Reviewed; prior §7.4.3 two-label proposal reviewed; Sol's arbitrary finite-alphabet §7.4.3 extension received clean M3 compiler_referee/spec_auditor review after one minor task-record repair; no implementation authority | candidate principal constrained presentation for open structural bounds after scoped equality quotienting | finite descriptor-pair normalization and two-direction greatest-relation factorization, conditional on stable finite scope/evidence contexts; exact one-class mandatory-Record fiber with fixed regular field endpoints; finite unguarded structural interval inhabitation and witness for closed endpoints; §7.4 separates full-fiber variation from erasure; §7.4.1 decides unguarded structural existence when `Λ=∅`; source-checkable closed monomorphic lambda/integer `Gen₀` fragment now has a separate `Λ=∅` generation induction and an `N+1` regular-witness corollary (see `notes/progress/2026-10-04-empty_record_source_fragment.md`); §7.4.2 decides one-label existence by category/depth branches; §7.4.3 decides arbitrary finite input-alphabet existence by least path domains and regular head propagation with a finite pushdown construction; a separately reviewed root-only theorem provides regular witnesses and an exact automaton for the normalized regular solution image over free roots plus closed descriptors (see `notes/progress/2026-10-04-root-only-regular-witness.md`); three queue-encoding probes refute only their stated patterns and prove no general impossibility (see `notes/progress/2026-10-04-fixed-descriptor-queue-encoding.md`); procedures retain original inequalities and select one witness only | shifted open-descriptor equations with variance-aware active descent now have simultaneous regular completion in the normalized pure fragment by `notes/design/2026-10-04-structural-fmp-fence-completion.md`; the direct MSO construction remains invalid; complete Yulang source generation and coupled effects are not identified with that pure package; full joint field/permission/guard/Phi solving, finite joint projection with unknown Records/feedback, exact full unnormalized fiber and principal residual, source bridge, effectful/family interfaces and lifecycle remain open |
| `notes/design/2026-10-03-concrete-compatibility-boundary.md` | User-approved semantic direction; proof and implementation authority remain gated | one endpoint-dependent `A <: B` solver; no transitive composition of successful concrete comparisons; coupled Function effects and existing subtraction/attachment evidence; source role before port interpretation; §9 records the approved polarity-sensitive deep-handler mixed-row fragment | §§3–8 and §9; callback source decisions in `notes/design/2026-10-03-callback-context-delivery.md` §§2–4. Frozen Oracle `Never`/`Any`/effect and reference behavior remain characterization only | **Open:** executable mixed-component membership and annotation-to-occurrence bridge; targeted-removal proof from complete handler image; soundness/principality and callback Pure-value clauses; source local-State/reference bridge. No new carrier/API/implementation is approved |
| `notes/design/2026-10-03-finite-bound-replay-closure.md` | Draft; reframed as internal solver-state closure after the single-inequality clarification; §8.2 conditional template received architect pre-write and compiler-referee review, two minor premise-qualification repairs closed; fixed-lane source audit confirms the Function annotation/checking bridge and candidate branch contract are missing; not a theorem | finite closure of fixed endpoint-dependent inequality solver states | endpoint transitions and replay create tasks of the same `A <: B` solver; §8.2 separates application/callee/candidate roots and states local-exactness premises for a fixed boundary-conservation result | joint Function descriptor elaboration/local exactness, source soundness/completeness of replay routes, structural child closure, consumer evidence and source-wide context remain open |
| `notes/design/2026-10-03-source-context-finite-closure.md` | Draft; repaired conditional finite-context theorem and §4 supplied-derivation root/context corollary; compiler-referee/spec-auditor delta reviews clean | finite context/provenance closure for one supplied finite linked open-template graph and initial roots for representation-preserving annotation checks | bounded state/hyperedge universe under explicit finite carriers; proof-label erasure preserves supplied annotation/check roots and typed evidence | raw annotation/conversion generation, source-carrier construction, template coverage, scheme instances, derived-query closure, lifecycle and effective residual solving remain open. The separate reviewed callback B root-enumeration lemma is recorded in `notes/progress/2026-10-04-callback-initial-root-enumeration.md`; it does not close this Draft's source-wide theorem |
| `notes/design/2026-10-03-staged-extrusion-solution-relation.md` | Draft; M3 theorem package and uniform-parent delta independently reviewed; no implementation authority | exact ordered extrusion, finite consequence replay and relative uniform-parent construction | diagonal conservative extension, signed retry, finite discovery and least uniform signed tuple for a fixed strategy in a complete lattice | source-scoped extension, finite syntax, conditional extremal countermodel applicability and source principality remain open; exact extrusion is not mandatory for all scoped targets |
| `notes/design/2026-10-02-operation-instance-binding-package.md` | Draft; equality, lexical-frontier and extrusion-edge guard deltas independently reviewed; no implementation authority | request witness retention, uniform arm proofs and generation-time scope checks | §8 derives lexical prefixes for unsealed equality; pins a raw-extrusion guard bypass and links the separate solution-relation package | scoped extrusion completeness/principality, complete subtype checking, sealed/general frontiers and lifecycle remain open |
| `notes/design/2026-10-02-symbolic-request-register-quotient.md` | Draft; M3 package and bound clarification reviewed; no source/implementation authority | finite correlated symbolic-point kernel | constructs states/predicate profiles from named points, equality, unary queries and bounded registers; uniform edge lifting avoids spurious kernel fault paths | source interaction and full OpCompat remain open; §7 records operation-local signature parameters independent of family equality; not a complete caller driver |
| `notes/design/2026-10-02-parametric-open-row-presentation.md` | Draft; M3 package and premise repair reviewed; no implementation authority | finite open point-row constraints and eligible row-variable projection | structural membership circuits retain one family assignment; whole-block alternatives; finite-support witness; zero-preserving monotone recursive row closure | finite parametric schema, not fixed grounded query basis or full Function/handler inference; joint source interaction and acceptance bridge remain open |
| `notes/design/2026-10-02-source-result-synthesis-choice.md` | Authoritative source result rule A; no compiler implementation authority | preserve known computation interfaces in result synthesis | `Result(Value(A))=Comp(empty,A)`; `Result(Computation(E,A))=Comp(E,A)`; lookup/transport/synthesis inert; extra layer requires explicit introduction; result-interpretation polymorphism rejected | choice closed by user; core §6 derives result/consumer skeletons and endpoint transport; general checking and principal solving remain open |
| `notes/design/2026-10-02-typed-computation-core-elaboration.md` | Draft; M3 packages, operation-consumer repair and parameter-role construction independently reviewed; no implementation authority | source-generated parameter roles/consumers, complete-call ports, interaction directions and scoped checking | §6 derives charter §21's value-default/explicit-retention roles and §18 forwarding; §§7–9 retain checking, complete invocation and domain distinctions | full annotation/typed-path generation, joint emitted-constraint solving, general Function comparison and principal inference remain open |
| `notes/design/2026-10-02-source-call-scheduling-choice.md` | Authoritative source choice A; no compiler implementation authority | inert first-class computation introduction and whole-argument reification | user clarified originally intended Oracle semantics; explicit receiver elimination under known interface, no pre-entry prefix or recursive latent force | pending choice closed; derive source consumers/elaboration and simulation; frozen placements require observational equivalence |
| `notes/design/2026-10-02-source-computation-role-elaboration.md` | Draft; scoped role/source-map/obstruction and entry packages reviewed; no implementation authority | computation introduction versus explicit execution/value conversion; common invocation entry expansion | §12 gives conditional inert introduction/elimination and call realization with initial relatedness, future use and resumption; no automatic result completion | derive source producer/consumer/annotation elaboration under charter §17; principal regular/parametric query closure and source acceptance remain open |
| `notes/design/2026-10-02-typed-source-owner-realization.md` | Draft; owner/control and typed-view extension reviewed; outside selector extent selected | decorated-source owner spans and common transport preservation candidate | charter §14 closes extent premise; corrected constructor induction and bounded encoding reviewed | original evidence is never rebound; pending match is ordinary bind outside the candidate; no implementation authority |
| `notes/design/2026-10-02-typed-boundary-realization-draft.md` | Draft; transport, adapters and structural observation package reviewed | typed `Flow` and emission-context `Observe`; finite structural adapters | borrowed-owner counterexample closed by projection before dispatch; package and admission-position repair reviews clean | raw-source executable decorations, abstract identity correlation, unknown shapes, uniform clients and source acceptance remain open; no implementation authority |
| `notes/design/2026-10-02-source-realization-and-symbolic-basis.md` | Draft; prior packages and §9 admission/row package independently reviewed; no implementation authority | finite symbolic basis, exact query lowering and joint guarded constraints | §9 expands explicit concrete capture admission and eliminates eligible local rows in the named-query fragment by consistent membership matrices | semantic endpoint equality/disequality, broader source annotation normalization, complete effectful checking and source principality remain open |
| `notes/design/2026-10-02-finite-abstract-safety-presentation.md` | Draft; generic mathematics independently reviewed; no implementation authority | finite heap abstraction and principal inductive safety-certificate interface | package review and repaired-error-reflection delta review complete; successor adoption, source refinement, symbolic basis, modular interactions, and acceptance bridge open | greatest admitted assignment domain and least joint observation; conservative abstract judgment, not exact source acceptance |
| `notes/design/2026-09-29-scc-intrusion-redesign-charter.md` | Reviewed research charter; selected amendments govern their scope | retire F5 Function generalization/closed-scheme target; soundness/principality before final Oracle acceptance compatibility | typed-value transport (§13), outside selection (§14), shallow/deep handling (§15), role-conditioned common invocation/entry mechanics (§16 as narrowed by §24), whole-argument reification (§17), result forwarding (§18), generic arm rejection/opening (§§19–20), value-default/explicit-retention parameters (§21), eager checks (§22), variable-only levels (§23), pure/handler receiver-role elaboration (§24); implementation authority remains open | source introduction/elimination precede optimization claims; finite classes and symbolic family lifecycle remain binding; §24 supersedes §16's universal handler receiver classification |
| `notes/design/2026-10-04-scc-intrusion-cross-edit-rebuild-addendum.md` | Authoritative narrow user decision; no implementation authority | cross-edit inference invalidation for the SCC-intrusion successor | User approved rebuilding changed inference components instead of requiring reverse-updatable intrusion/level/SCC state; stop downstream inference invalidation only after unchanged complete generalized canonical interface | interface fields/equality, component granularity, SCC split/merge, enclosing environments, and non-inference artifact invalidation remain open |
| `notes/design/2026-10-01-coupled-effect-interface-core-draft.md` | Draft; non-authoritative; not implementation-ready | candidate unified semantic carrier for ordinary effects, shallow handlers, typed-family constraints, and SCC lifecycle transport | exact candidate-machine simulation is closed; conditional finite saturation is proved for fixed finite `Q/P`, but their source construction and principal fiber-preserving projection remain open | one `Rel_C(ρ)` with fiber product, composition, restriction, and consistent interface transport; projection/image are derived views |
| `notes/design/2026-10-02-ordinary-computation-semantics-package.md` | Draft; ordinary escape behavior, active-incidence preservation, and concrete callback-boundary visibility selected; not implementation authority | ordinary computation machine for calls, closures, force, requests, event-relevant callback boundaries, and shallow handlers | package and delta reviews cover event-specific relevance, actual handler checks, closure re-entry, and typed transport; `Capture` now uses live `Inc_C`/`Path` with receipt, typed `Flow`, and event-specific `Observe`, including later latent views | common state-threaded `Run`/`ApplyValue`/`Force`/ordered `Step_H`; maker expiry removes only maker premises; `Force` reveals latent behavior but creates no authority; no persistent maker mask; source routing/re-entry and adequacy/principality remain open |
| `notes/design/2026-10-02-source-interface-adequacy-theorem.md` | Draft exact-interface theorem for candidate semantics; not implementation authority | one source-execution-to-complete-interface simulation for calls, closures, adaptation, `Force`, requests, and shallow handlers | candidate-machine package review closes initial relatedness, primitive source-rule images, latent future-use, and typed resumption preservation; it does not establish current Yulang typing ownership or finite representation | one assignment, per-event origin, joint `K,D`, actual ordered handler configuration, raw continuation/live-state fidelity, and call-frame re-entry without handler restoration; finite abstraction/principality remain open |
| `notes/design/2026-09-29-intrusion-abstract-semantics-draft.md` | Draft; exploratory; not implementation authority | candidate pure polarized graph model for SCC freeze, parent ports, per-use overlays, and final-acceptance obligations | 2026-09-30 user decision: polarity-only q erasure is not required; preserve meaningful source constraints; inference-stage formatting/acceptance phase need not match; final well-typed acceptance is the target | the earlier `Erase_d` discussion is Oracle characterization only; review and prove the constraint-retaining SCC candidate |
| `notes/design/2026-09-30-intrusion-q-bound-successor-draft.md` | Draft; unreviewed; not implementation authority | proposed successor for one-polarity variables with selected bounds | user approved retaining meaningful source constraints and waiving inference-stage formatting/phase parity; erasure is optional only with a preservation proof; exact graph/effect semantics and independent review remain open | retain selected constraints through member parents and per-use transport |
| `notes/design/2026-09-29-intrude-effect-hygiene.md` | Draft; historical hypotheses | parent substitution sharing and future effect-hygiene transport | F5-equivalence/no-change clauses are withdrawn from the active research gate by the user's 2026-09-29 correction | retain type-parent vs path/binder separation as a hypothesis; effect gate follows pure redesign |
| `notes/design/2026-09-29-scc-intrusion-generalization-sketch.md` | Exploratory / non-authoritative / unproved | possible SCC-preserving Simple-Sub generalization and instantiation representation | active target now follows the redesign charter; implementation authority none | establish the Oracle observation ledger; do not require F5 scheme equivalence |
| `notes/design/2026-09-29-pure-f5-intrusion-reference-model.md` | Reviewed historical protocol; withdrawn as active gate by user direction | former F5-equivalence protocol for parent intrusion | review evidence retained; it is not a pass condition for the redesign | use only as an audit record of rejected compatibility framing |
| `notes/design/2026-09-22-f5b-terminal-finish-evidence-boundary-addendum.md` | Authoritative; implementation complete | F5b terminal finish evidence split across the yu-types/yu-solver Cargo test boundary | user approved no cross-crate test hook/feature on 2026-09-22 after focused specification review | real terminal proof remains yu-types-owned; solver proves mapping/no-publication without synthetic overflow |
| `notes/design/2026-09-22-f5b-terminal-accounting-exhaustion-amendment.md` | Authoritative; implementation complete | F5b terminal exact-capacity accounting exhaustion and fallible finalization finish | user approved existing-error fallible finish on 2026-09-22 after clean M2 specification/resource review | narrowly replaces only infallible finish/accounting timing; no detailed counters, Term, or F5e measurement work |
| `notes/design/2026-09-22-f5b-closed-finalization-accounting-boundary-amendment.md` | Authoritative; implementation complete | F5b sealed result-attached byte accounting from closed finalization into existing F4 aggregate counters | user approved the narrow five-byte boundary on 2026-09-22 after clean M2 specification/resource review | replaces only F5b session finalizer/finish result declarations and live getter access; detailed counters remain F5e |
| `notes/design/2026-09-22-f5b-closed-finalization-term-owner-draft.md` | Authoritative; implementation complete | F5b closed-arena finalization gateway and batch-bound TermArena ownership | user approved sealed finalization, batch-bound store, logical clone ownership, and fixed 256-slot Term pages on 2026-09-22 after clean M3 review | resolves F5b inter-crate construction and standalone store contradictions only |
| `notes/design/2026-09-21-f5-general-function-scheme-foundation-draft.md` | Authoritative; implementation in progress | canonical one-parameter Function source/HIR, live variables, polarized general schemes, recursive bounds, and fresh instantiation | user approved 2026-09-21 after clean architect/compiler/specification/performance review | one atomic source-identity completion gate; F5a–F5e are internal implementation stages |
| `notes/design/2026-09-25-f5c-flat-indexed-stack-independent-draft.md` | Reviewed proposal; user approved non-shipping candidate implementation before numeric resource-boundary selection (2026-09-25); bounded FlatDraft fixtures, `yu-types` indexed finalizer, producer/memo/walker/source owners, checked conversion, ordered SCC all-member candidate, and independent same-time solver/finalizer physical ledger have scoped implementation closure; §15 repository-bounded capture campaign completed 2026-09-27; practical boundary and production acceptance remain open | proposed end-to-end flat F5c drafts and `yu-types` indexed transactional finalization for stack-independent structural depth | §15 candidate sequence passed focused M3 review; indexed API and §3/§7 evidence passed M3 delta review; implementation slices passed focused M2 review; all-member lane ledger reconciles actual capacities, emitted outputs, owner release, transfer/failure overlap, cumulative peaks, and solver/`yu-types` checkpoints; finalizer calls now check retained-base continuity and reconcile same-time source/memo/walker peaks without adding non-overlapping history; diagnostic history folds once per batch; nested source-owner growth/failure/transfer/drop events independently reconcile against the all-drafts walk; no production cutover, numeric cap, or acceptance approved | The source path now admits one-parameter Lambda recipes with integer or name bodies into boxed and flat candidates. The 16-case stable-core inventory has two Function-rich sources, but their nested/method shapes have not been confirmed eligible under that recipe and must not be used as practical measurements without an exact source audit. No numeric boundary follows from the current synthetic maximum. FlatDraft/source-arena incidence, memo reverse-parent/root-lane admission, journal rollback, and the per-invocation live intermediate-graph census have scoped closure; numeric-boundary approval and F5e Function products remain open. The closed-pure §44 per-use resource/rollback gate is complete |
| `notes/design/2026-09-28-f5c-no-numeric-resource-caps-addendum.md` | Authoritative; user approved exact text on 2026-09-28 | F5c removal of numeric input/work caps and fixed runtime cutoff; ordinary compressed-source complexity objective and resource failure contract | user approved exact reviewed addendum on 2026-09-28 after independent spec/compiler/performance reviews and targeted deltas | ordinary Function SCC ring target is `O(N² log N)` pending source-owner proof; mandatory F5 §26 scale runs remain; production/API cutover stays separate |
| `notes/design/2026-09-26-f5c-shared-walker-flat-sink-draft.md` | User-approved staged implementation (2026-09-26); private normalized candidate connects raw forest, shared R/Q selection, substitution, normalization, tracked SCC staging, and checked indexed conversion; ordered all-member orchestration and independent source/memo/walker/indexed/`yu-types` same-time ledger have scoped closure; production stays boxed | proposed shared `F5cWalkTask` interpreter, boxed compatibility sink, tagged flat candidate arena, ordered raw-root forest, and component rollback | M3 design reviews converged; candidate and lane slices passed focused M2 reviews; compound Q/R route parity, failure rollback, actual output request sums, post-drop capacity release, retained physical high-water values, and ledger mutation witnesses pass; 64 KiB boxed-normalization stack regression is repaired and reviewed | The §15 repository-bounded capture campaign is complete. F5d has connected the currently admitted top-level Lambda shapes to candidate Function graphs; audit any real source fixture against the narrow recipe before measuring it. No numeric boundary, production cutover, F5e, or overall F5c acceptance is selected. The closed-pure §44 per-use resource/rollback gate closed 2026-09-27 |
| `notes/design/2026-09-28-f5c-live-intermediate-graph-census-addendum.md` | Authoritative; formula selected by primary under user delegation and reviewed by compiler_referee/spec_auditor; scoped implementation closed after M2 spec/performance review and spec delta (2026-09-28) | checked logical-size census per F5c normalization invocation for its Normalizer nodes and child-ID slots | defines only the census and lifetime; no numeric threshold, production cutover, or F5c acceptance is selected | checked projected lengths precede graph-lane growth; the actual batch path shares one Normalizer across staged members until drop; arithmetic, early rejection, late reserve failure/retry, and multi-member accumulation witnesses pass |
| `notes/design/2026-09-23-f5c-indexed-finalization-accounting-boundary-draft.md` | Draft; accounting-design slice clean at M2, whole candidate not ready; §§8–9 primary-authored and not independently reviewed | proposed indexed API and F5c stack-safety/accounting boundary; §9 provisionally prefers bounded current-API rejection | no limit or API approved; producer/error-path coverage, flat fallback, callback-local accounting reconciliation, and implementation proof remain open | §8 compares the three boundaries; §9 records the user's product priority and a conditional bounded-recursion direction, subject to source audit/review; authoritative Q/R, normalization and §44 choices remain fixed |
| `notes/design/2026-09-24-f5c-bounded-boxed-draft-gate-draft.md` | Reviewed initial 128 proposal; superseded as current candidate by 2026-09-25 stack probe | bounded `Node.height` rejection with boxed drafts and current §24 callback; candidate 256, exact caller-stack envelope unresolved | 256 finalization/destruction passes at 512 KiB debug and 64 KiB optimized, but overflows at 64/256 KiB debug; no production implementation authorized pending stack-boundary decision | original §§2–3 define the invariant; the 2026-09-25 handoff records the changed candidate and decision options; shallow-width/resource gates remain open |
| `notes/design/2026-09-23-f5c-producer-order-and-failed-route-sampling-addendum.md` | Authoritative for producer-order and failed-route sample decisions | Q/R binder encounter order and one conditional O(1) sample after a failed incoming-route rollback | user's delegated direction, primary adjudication after clean architect/M3 review, 2026-09-23 | first-surviving producer encounter; §44 first-member projection and route atomicity retained; mixed-height order is resolved by the 2026-09-24 addendum; closed-pure incoming-route implementation and lane proof closed 2026-09-27; remaining candidate, numeric-boundary, production-cutover, and F5e gates remain separate |
| `notes/design/2026-09-24-f5c-mixed-height-normalization-order-addendum.md` | Authoritative; implementation slice complete, broader F5c closure open | §25 versus §36 ordering when normalized Union/Intersection children have different postorder heights | user selected height-major option B on 2026-09-24 | §36 height-first ordering supersedes §25 only for conflicting mixed-height child order; §44 representative projection and resource bound remain unchanged |
| `notes/design/2026-09-24-f5c-normalization-counter-invariance-addendum.md` | Authoritative; implementation slice complete, broader F5c closure open | §36 root/member permutation counter invariance with exact stable-mergesort comparison accounting | user selected option B on 2026-09-24; primary-only implementation per user direction | canonical insertion/radix preordering before the prescribed stable mergesorts; adds `O(N+W)` work and two accounted scratch lanes; normalized order and §44 projection unchanged |
| `notes/design/2026-09-21-f4-fact-store-counter-visibility-addendum.md` | Authoritative; implementation complete | public visibility of the F4 fact-store rebuild counter | user selected private lane with public aggregate on 2026-09-21; final spec/performance delta review clean | resolves only the F4 §12/§13 accessor-list ambiguity; no semantic or resource-formula change |
| `notes/design/2026-09-21-review-repair-convergence-addendum.md` | Authoritative | repository-wide review/repair continuation and return-to-design policy | user removed numeric round limits on 2026-09-21; independent spec review closed the durable-workflow authority gap | supersedes numeric round caps and normal-round-limit clauses; preserves reviewer-count, role-separation, verification, and measurement controls |
| `notes/design/2026-09-21-f4-direct-bound-frontier-addendum.md` | Authoritative; implementation complete | synchronous direct-Var adjacency, atom frontier, and associated six public counter/test/resource contracts | user approved 2026-09-21; final M3 implementation certification clean | replaces cubic transitive replay and narrowly supersedes reverse/worklist/pair-omission rollbacks; schemes/projections/facts/provenance unchanged |
| `notes/design/2026-09-21-f4-bound-membership-summary-addendum.md` | Authoritative; implementation complete | exact value-only lower-bound membership summary, fixed-size canonical value-pair keys, and F4 storage/resource/test contract | user selected the fixed-size-key design on 2026-09-21; final M3 implementation certification clean | supersedes F4 §6 per-root expansion and §13 complexity clause; adds §12/§14 evidence/rollback only; §7/§15 unchanged |
| `notes/design/2026-09-21-oracle-aligned-f4-int-scheme-scc-draft.md` | Authoritative; implementation complete | Integer/Bottom scheme, lower/upper-bound propagation, positive coalescing/elimination, resolved binding-body Name components/facts, ordinary Never roots, finalized root projection, and static SCC generalization/instantiation | user approved 2026-09-21; final M3 semantic/spec/performance implementation certification clean | one atomic F4 semantic/API gate; direct-root Name and Function/application remain excluded |
| `notes/design/2026-09-21-oracle-aligned-static-scc-inference-session-draft.md` | Authoritative; F3a/F3b complete | concrete oracle-aligned inference owner and static SCC lifecycle superseding all R2 semantics | user approved 2026-09-21 after clean M3 review and clarified `Never` as ordinary bottom | R2 code safely withdrawn; private concrete session extracted with zero observable change; F4 semantic scheme gate is next |
| `notes/design/2026-09-21-recoverable-scc-execution-r2-draft.md` | Superseded; withdrawn as implementation candidate | historical recoverable component-outcome executor proposal | superseded in full by the oracle-aligned session design after direct Yulang2 audit | retain as rejected design history; do not implement its Failed/Blocked or generic-executor model |
| `notes/design/2026-09-21-scc-lifecycle-executor-r1-draft.md` | Superseded; withdrawn as implementation candidate | historical terminal-failure lifecycle proposal | superseded by user-approved recoverable R2 | retain lifecycle evidence only |
| `notes/design/2026-09-20-constraint-collection-scc-foundation-draft.md` | Authoritative; construction complete | structure-first inference foundation from Yulang constraint collection and definition SCC lifecycle | user approved 2026-09-20 after clean M3 review | F0 dependency collection, F1 static SCC kernel, and F2 batch integration complete; semantic SCC execution remains a later gate |
| `notes/design/2026-09-20-identity-function-simple-sub-r1-supersession-draft.md` | Reviewed; withdrawn as implementation candidate | historical identity witness and polarity derivation | user rejected its fixture-led order after audit found missing definition-use/SCC ownership | retain the identity witness only; do not implement its definition-order/no-SCC lifecycle |
| `notes/design/2026-09-20-simple-sub-direct-int-expansion-supersession-draft.md` | Superseded in active implementation-candidate scope | historical direct canonical integer and bounded expansion proposal | fixture-led successor chain is no longer active construction order | retain direct-Int evidence only; F0-F2 now precede semantic expansion |
| `notes/design/2026-09-20-canonical-int-endpoint-polarity-supersession-draft.md` | Superseded in active implementation-candidate scope | historical canonical-endpoint repair proposal | later user decision rejects its literal value component, exact interval, and root-`Unknown` contract | retain endpoint evidence only; active construction begins with F0-F2 |
| `notes/design/2026-09-20-integer-binding-scheme-name-instantiation-draft.md` | Superseded in active implementation-candidate scope | historical integer binding scheme/name proposal | fixture-led scheme/name sequencing is withdrawn | retain scheme evidence only; SCC lifecycle precedes generalization/instantiation semantics |
| `notes/design/2026-09-20-binding-body-definition-root-directed-subtype-draft.md` | Authoritative; construction complete | binding-body to definition-root subtype relation | user approved recommended integrated choice 2026-09-20; M3 implementation and delta reviews clean | one value-only body-to-root relation; no definition effect/name/generalization |
| `notes/design/2026-09-20-directed-subtyping-integer-slice-draft.md` | Authoritative; construction complete | first type/effect vertical slice for direct-root decimal integers | user approved integrated choice 1 on 2026-09-20; M3 implementation and delta reviews clean | directed lower/upper bounds, pure effect, artifact-scoped occurrence identity, reference `SolvedModule` |
| `notes/design/2026-09-20-hir-direct-root-expression-slice.md` | Authoritative; construction complete | direct-root OperatorChain HIR items | user approved and M2-reviewed 2026-09-20 | neutral Integer/Identifier root lowering; no types/evaluation |
| `notes/design/2026-09-20-successor-bracket-row-close-topology-supersession.md` | Authoritative; construction complete | BracketRow Item/Close raw-Error topology | user approved and M2-reviewed 2026-09-20 | direct Item Error; close-only `TypeDelimitedForeignClose > Error+` |
| `notes/design/2026-09-19-hir-simple-module-resolution-first-slice-draft.md` | Authoritative; implementation complete | first immutable `HirModule` and module-local simple-binding resolution slice | user approved 2026-09-19; M2 implementation and final delta reviews closed 2026-09-19 | public-parser preflight; simple `x`/`y` binding fixture; two-pass resolution |
| `notes/design/2026-09-19-hir-associated-chains-ownership-amendment.md` | Authoritative | ownership of nested results in the first `AssociatedChains` product | user approved the top-level-only topology 2026-09-19 after a performance audit exposed quadratic duplicate retention | nested chains stay only in their enclosing owned tree; no standalone duplicate entry |
| `notes/design/2026-09-18-hir-operator-association-first-slice-draft.md` | Authoritative; Gate 3 implemented | first `yu-hir` slice: operator-chain association phase input/output and the minimal pre-HIR product | user approved D1a/D2b/D3a/D4a 2026-09-18; implementation and M2 delta review closed 2026-09-19 | D1-D4 decisions, observable contract, nested-chain composition, rollback conditions |
| `notes/design/2026-09-18-hir-type-attachment-open-questions.md` | Draft memo; records no decision | open question: how a type attaches to an associated HIR expression | drafted by primary 2026-09-18; captured so the approved association slice can proceed without deciding it | identity tension, type placement options, prerequisite order, open questions |
| `notes/design/2026-09-08-successor-recovery-authority-amendment.md` | Authoritative; §4 private delimiter integration complete | accepted-input compatibility and independently selected successor recovery | user-directed 2026-09-08; legacy recovery equality/scalar prerequisites superseded; current pass is direct primary work per user | §§1–3 authority and invariants; §4 delimiter/PV numeric contract; §§5–6 direct verification scope and results |
| `notes/design/2026-09-08-successor-virtual-statement-current-item-recovery.md` | Authoritative; private O3b construction pending | VirtualStatementBlock current-Item Missing/Error publication | user recovery-selection delegation; existing Statement roles are boundedly selected for Virtual slots | role table; Error-leading/boundary/parent ordering; focused M2 evidence |
| `notes/design/2026-09-08-successor-if-current-item-recovery.md` | Authoritative; private O3b construction pending | If/Elsif introducer, inline body and Else body typed recovery | user recovery-selection delegation; existing IfExpression roles selected per immediate slot | role table; current-Item leading/boundary/retry contract; focused M2 evidence |
| `notes/design/2026-09-08-successor-case-like-structural-current-item-recovery.md` | Authoritative; private O3b construction complete | Case/Catch Block, Arm, first Pattern and Handler current-Item publication | user recovery-selection delegation; E12b/c/d/k roles selected without duplicate Pattern recovery | role table; protected newline/Item handoff; focused M2 and direct-Rowan schema evidence |
| `notes/design/2026-09-08-successor-case-like-arrow-body-current-item-recovery.md` | Authoritative; private O3b construction complete | Case/Catch Arrow and inline Body current-Item publication | user recovery-selection delegation; simultaneous absence selects one Arrow-primary typed record with Body expectation evidence | root-cause union, boundary/Error terminal contract, E12f/g/j successor mapping |
| `notes/design/2026-09-09-successor-case-like-separator-close-current-item-recovery.md` | Authoritative; private O3b construction complete | CaseLike inter-arm Separator and Catch braced local-close publication | delegated recovery selection; centralized CatchBlock completion preserves accepted trailing comma | E12h/i roles, close boundary ownership, focused M2 evidence |
| `notes/design/2026-09-09-successor-for-structural-current-item-recovery.md` | Authoritative; private O3b construction complete | For Pattern/InKeyword/BodyIntroducer and shallow Body publication | delegated recovery selection; finite In keyword and ordered colon/brace introducer expectations | owner transport, protected current Item, focused M2 evidence |
| `notes/design/2026-09-09-successor-type-declaration-header-current-item-recovery.md` | Authoritative; private O3b construction complete | TypeDeclaration Name and equality DefinitionIntroducer publication | delegated recovery selection; retry/EOF leading is TypeDeclaration-owned outside Error | form/no-cascade boundary and focused M2 evidence |
| `notes/design/2026-09-09-successor-enum-error-header-current-item-recovery.md` | Authoritative; private O3b construction complete | owner-local Enum/Error Name and BodyIntroducer publication | delegated recovery selection; ordered four-starter union without shared header extraction | no-cascade/leading ownership and focused M2 evidence |
| `notes/design/2026-09-09-successor-declaration-named-field-current-item-recovery.md` | Authoritative; private construction complete | shared declaration named-field Field/FieldName/FieldColon publication and caller-role transport | delegated recovery selection; body-level ownership review found the Struct-hosted driver also serves Enum/Error variants | forward classification, role transport, Error-leading and active-stop contract; sequence/separator/close and coherent physical move excluded |
| `notes/design/2026-09-09-successor-declaration-field-sequence-current-item-recovery.md` | Authoritative; private construction complete | shared declaration field sequence, separator, matching close, and neutral-owner extraction | delegated recovery selection; variant tuple separator reuses the retained payload-list role without a new vocabulary item | finite Struct/variant transport, close ownership, and `declaration/fields.rs` topology |
| `notes/design/2026-09-11-successor-declaration-field-foreign-close-topology.md` | Authoritative; construction complete | transparent `StructFieldForeignClose` around one existing Struct delimited Recover Error run | user approved option B 2026-09-11; M2 implementation and one test-evidence repair independently closed | raw kind 278, one-wrapper-per-run cardinality, narrow supersession, former collisions structurally distinct |
| `notes/design/2026-09-09-successor-cast-pattern-introducer-current-item-recovery.md` | Authoritative; private construction complete | Cast PatternIntroducer Missing/Error publication | delegated recovery selection; M2 preflight and delta review closed EOF physical-extent repair | lexical-only shared Item acquisition, one-error bare-Pattern retry, phase/outer-close handoff |
| `notes/design/2026-09-09-successor-cast-pattern-current-item-recovery.md` | Authoritative; private construction complete | initially absent Cast Pattern publication | delegated recovery selection; M2 owner review retains nested Pattern recovery | local-close and punctuation handoff without cascade |
| `notes/design/2026-09-09-successor-cast-pattern-close-current-item-recovery.md` | Authoritative; private construction complete | Cast Pattern local closing-parenthesis Missing/Error publication | delegated recovery selection; M2 preflight and delta review retain local-close priority and no-local-frame bypass | lexical Error run, no-cascade handoff, and selected same-line EOF extent |
| `notes/design/2026-09-09-successor-cast-target-introducer-current-item-recovery.md` | Authoritative; private construction complete | Cast TargetIntroducer Missing/Error publication | delegated recovery selection; M2 preflight and delta review retain phase priority and protected boundaries | lexical Type-vocabulary Error run, no-cascade retry, and selected same-line EOF extent |
| `notes/design/2026-09-09-successor-cast-body-introducer-current-item-recovery.md` | Authoritative; private construction complete | Cast BodyIntroducer Missing/Error publication | delegated recovery selection; M2 preflight and delta review retain exact form-starter handoff and protected boundaries | lexical-only form-punctuation acquisition, no-cascade retry, and selected same-line EOF extent |
| `notes/design/2026-09-09-successor-cast-body-current-item-recovery.md` | Authoritative; private construction complete | post-equals Cast inline Body Missing/Error publication | delegated recovery selection; M2 preflight and delta review retain Body/IndentedStatement separation and Cast EOF ownership | lexical Expression Error run, no-cascade retry, and protected boundary handoff |
| `notes/design/2026-09-09-syntax-phase-topology.md` | Authoritative; private construction complete | public syntax environment, diagnostic, and full-parse source topology | user-directed responsibility reconstruction; M2 topology review closed internal identity exposure | direct owner names, one-way assembly, and unchanged root API |
| `notes/design/2026-09-09-operator-compilation-topology.md` | Authoritative; private construction complete | header-to-table operator compilation separated from immutable table/trie ownership | user-directed responsibility reconstruction; scoped topology/split preflight and delta review | one-way header/compiler/table/scanner/chain flow; unchanged root API |
| `notes/design/2026-09-09-root-statement-topology.md` | Authoritative; private construction complete | source-root statement progression separated from source/header facade | user-directed responsibility reconstruction; scoped topology audit and delta review | preserves frozen reconciliation inside the source-root loop; fence/opaque cell blockers excluded |
| `notes/design/2026-09-08-successor-public-cutover-priority-amendment.md` | Authoritative; public cutover complete | prioritize rewrite header/root public connection and atomic legacy-parser removal | user's current explicit cutover-priority instruction; completed at `dfa481c4` | exhaustive private O3/O4 ordering superseded; header/root two-phase integrity and no-fallback removal retained; deferred Yumark owner work remains |
| `notes/design/2026-09-08-successor-type-contextual-boundary-correction.md` | Authoritative; private correction complete | accepted contextual TypePathSegment admission and fresh TypeCall contextual-boundary suspension | accepted-input authority plus direct user delegation; primary-only construction complete 2026-09-08 | selected rule, declaration-control classification, focused completion evidence; public cutover excluded |
| `notes/design/2026-09-08-successor-pv-current-item-recovery.md` | Authoritative; private PV-owned construction complete | current-Item PV recovery and all PV-owned typed sites | direct user recovery-selection delegation; primary-only implementation and checks 2026-09-08 | acceptance/supersession, PV1 site ledger, fresh/frozen/caller/fence controls; nested Type and O6 remain open |
| `notes/design/2026-09-08-successor-pe-current-item-recovery.md` | Authoritative; private P/E-owned construction complete | Parenthesized/EffectRow Item, Separator and Close recovery | direct user recovery-selection delegation; primary-only implementation/checks 2026-09-08 | current-Item retry, native local-close Error, caller/fence handoff, OuterTypeApply-only E activation; seven focused tests; aggregate O6 remains open |
| `notes/design/2026-09-08-successor-bracket-row-current-item-recovery.md` | Authoritative; private BracketRow-owned construction complete | BracketRow Item, Separator and Close recovery | direct user recovery-selection delegation; primary-only implementation/checks 2026-09-08 | shared non-Call Item-error scan, B close-only retry, caller/outer-close priority; six focused tests; aggregate O6 remains open |
| `notes/design/2026-09-08-successor-bracket-arrow-current-item-recovery.md` | Authoritative; private BracketRowArrow construction complete | mandatory arrow Missing and malformed retry after trailing row | direct user recovery-selection delegation; primary-only implementation/checks 2026-09-08 | total Item-error run, arrow/RHS retry without cascade, complete boundary handoff; five focused tests; distinct embedded T7c and O6 remain open |
| `notes/design/2026-09-08-successor-leading-row-head-current-item-recovery.md` | Authoritative; private LeadingEffectTypeHead construction complete | mandatory leading-row head and disabled second-row recovery; T7a/T7b witness correction | direct user recovery-selection delegation; primary-only implementation/checks 2026-09-08 | total nested-Item run replaces raw suffix scanning; seven focused tests; corrected bare-row embedded witnesses remain uncertified |
| `notes/design/2026-09-08-successor-record-field-current-item-recovery.md` | Authoritative; private field-internal construction complete | RecordFieldName/Colon/Type recovery and exact field-colon ownership | direct user recovery-selection delegation and accepted grammar; primary-only implementation/checks 2026-09-08 | shared forward colon/RHS Error, caller-first Missing, nested-record colon repair; eight focused tests; sequence follow-up completes the probe/outer slots; aggregate gates remain open |
| `notes/design/2026-09-08-successor-record-sequence-current-item-recovery.md` | Authoritative; private construction complete | RecordField/Separator/Close and malformed-name authority preflight | direct user recovery-selection delegation; primary-only implementation/checks 2026-09-08 | phase-aware owner loop, complete caller handoff, kind-matching recovery, native close-only Error; nine focused tests; T5f witness correction; aggregate/public excluded |
| `notes/design/2026-09-08-successor-forall-current-item-recovery.md` | Authoritative; private Forall-owned construction complete | Forall Binder/Boundary/Colon/Body and phase-owned forward recovery | direct user recovery-selection delegation and accepted grammar; primary-only implementation and checks 2026-09-08 | removes malformed-role lookahead and recursive retries, preserves terminal full body, repairs adjacent mandatory colon; T6/aggregate/public excluded |
| `notes/design/2026-09-08-successor-required-type-missing-roles.md` | Authoritative; helper publication and caller controls complete | shared required-Type Missing with explicit caller roles | existing outer-missing contract and user recovery delegation; primary-only implementation/checkpoint 2026-09-08 | caller conformance and tuple-progress follow-ups complete; caller bypass/SCC/aggregate/public still open |
| `notes/design/2026-09-08-successor-type-caller-conformance.md` | Authoritative conformance clarification; private controls complete | five caller expectations reconciled with existing narrow Type-owner contracts | primary pre-write audit under user no-subagent instruction; no production behavior change | retains every original literal; accepted and nonhorizontal controls; 432 caller/output tests pass at this checkpoint; later Equals correction closes tuple progress; aggregate gates remain open |
| `notes/design/2026-09-08-successor-required-type-equals-ownership.md` | Authoritative; private correction complete | required-Type Equals ownership and declaration-field forward progress | SD-T/PTA-O plus direct user recovery delegation; primary-only implementation/checks 2026-09-08 | existing EQUALS boundary, explicit Pattern transport, no loop workaround; capped tests pass and expanded owner/output 470 pass; ledger/SCC/public remain open |
| `notes/design/2026-09-08-successor-pattern-primary-current-item-recovery.md` | Authoritative; private substep complete | Pattern Primary/SymbolName/AliasBinding/AlternationRhs typed publication | direct user recovery delegation; primary-only M2 implementation and checks | explicit immediate slot roles, retry-leading outside Error, malformed alias layout boundary; 33 Pattern / 477 owner-output tests pass; delimiter/literal/SCC/public remain open |
| `notes/design/2026-09-08-successor-pattern-delimited-slot-publication.md` | Authoritative; private substep complete | Pattern element/spread/nested roles, delimiter sequence Missing and close Missing | existing Pattern/layout/matrix contracts and user recovery delegation; primary-only M2 | five child roles, three close owners, guarded RecordFieldName non-recovery proof; 40 Pattern / 484 owner-output tests pass; sequence Error/default Expression/SCC remain open |
| `notes/design/2026-09-08-successor-pattern-sequence-current-item-recovery.md` | Authoritative; private substep complete | Pattern sequence/close Error, Record structured wrong-kind units, literal Item admission | delegated successor recovery; primary-only M2 with one repair bundle | two scoped Record structured roles retain reservation/extent invariants; no raw Pattern Error; accepted layout literal correction; 48 Pattern / 533 related tests pass; default Expression/SCC/public remain open |
| `notes/design/2026-09-08-successor-pattern-default-expression-publication.md` | Authoritative; private substep complete | RecordDefaultExpression Missing, required OperatorChain wrapper and caller-close preservation | existing P7c/default grammar and delegated recovery; primary-only M2 | zero raw Pattern-owned recovery; accepted/rejected exact-Equals controls; 54 Pattern / 539 related tests pass; callee SCC/header/full/Yumark/public remain open |
| `notes/design/2026-09-08-successor-expression-operand-current-item-recovery.md` | Authoritative; private construction complete | shared mandatory-operand recovery, explicit If/CaseLike/For roles and ForIterable bypass | delegated recovery selection; M2 implementation with focused primary checks and read-only audit findings | typed Missing/Error, shared lexical Item scan and exact ` ]` witness implemented; tails/delimiters and joint certification remain open |
| `notes/design/2026-09-08-successor-expression-delimited-current-item-recovery.md` | Authoritative; private construction complete | shared Parenthesized/Call/Index/Projection current-Item recovery | delegated recovery selection; M2 implementation with independent specification and delta-regression audits | finite owner roles, close-only inherited protection, phase-aware Error runs and record-spread RHS are typed; Field/Path, Colon/With and joint certification remain open |
| `notes/design/2026-09-08-successor-expression-fixed-tail-current-item-recovery.md` | Authoritative; private construction complete | FieldTail/PathTail name-slot current-Item recovery | delegated recovery selection; M2 implementation, spec/regression review and one test-evidence repair | typed FieldName/PathSegment records, sigil-aware sealed Path retry and protected colon/stops; Colon/With and joint certification remain open |
| `notes/design/2026-09-08-successor-expression-colon-with-inline-current-item-recovery.md` | Authoritative; private inline construction complete | Colon/With inline slot recovery and canonical Statement lexical admission | delegated recovery selection; M2 implementation with specification/regression review | typed Colon/With slots, sealed literal-first Statement retry and selector factoring; indented transport/layout sequence and joint certification remain open |
| `notes/design/2026-09-08-successor-expression-indented-statement-role-transport.md` | Authoritative; private construction complete | shared indented Statement role transport and typed block-slot recovery | delegated recovery selection; M2 implementation with specification/recovery and regression audits | finite existing caller-role mapping, sealed lexical Error runs and protected-boundary handoff; current-depth layout sequence remains separate |
| `notes/design/2026-09-08-successor-expression-colon-layout-sequence-context.md` | Authoritative; private construction complete | current-depth Expression/Statement sequence ownership and Colon comma/layout-newline correction | delegated recovery selection; M2 implementation with specification/recovery and regression delta audits | source-free by-value owner context; Virtual, RecordPattern-default and Rule-list bridges are narrow existing owners, while Type/other-Pattern/Yumark transport remains open |
| `notes/design/2026-09-08-successor-string-literal-current-item-recovery.md` | Authoritative; private construction complete | non-Rule StringLiteral terminator/escape/interpolation typed recovery | delegated recovery selection; M2 implementation with specification/recovery and regression audits | six existing Literal roles; Virtual and Rule child owners remain separate |
| `notes/design/2026-09-08-successor-rule-literal-current-item-recovery.md` | Authoritative; private construction complete | Rule DSL closes/items/names/literal-boundaries typed recovery | delegated recovery selection; M2 implementation with specification/recovery and regression delta audits | ten existing Literal roles and authoritative Body/Paren newline stop |
| `notes/design/2026-09-08-successor-rule-expression-list-current-item-recovery.md` | Authoritative; private construction complete | Rule bracket/call/index ordinary ExpressionList typed recovery | delegated recovery selection; M2 implementation with specification/recovery, regression and static performance audits | dedicated Item/Separator roles, exact delimiter close owner and single-prefix coordinate emission; one-Item Error policy retained |
| `notes/design/2026-09-08-successor-braced-statement-sequence-current-item-recovery.md` | Authoritative; private construction complete | canonical braced Statement required-item, separator and local-close typed recovery | delegated recovery selection; M2 implementation, one repair and specification/recovery plus regression delta audits | existing Statement/Separator/close roles; protected nonlocal-close simplification; root/declaration/Virtual/public excluded |
| `notes/design/2026-09-08-successor-derives-current-item-recovery.md` | Authoritative; private construction complete | Derives RoleReference and ViaTarget typed recovery | delegated recovery selection; M1 implementation and specification review | existing derives roles; C15 boundary priority; declaration/Virtual/public excluded |
| `notes/design/2026-09-08-successor-declaration-variant-current-item-recovery.md` | Authoritative; private construction complete | declaration variant Item/Name/Separator/close typed recovery | delegated recovery selection; M2 implementation, one repair and specification/regression delta audits | existing Variant roles; Enum/Error shells and payload owners excluded |
| `notes/design/2026-09-08-successor-binding-current-item-recovery.md` | Authoritative; private construction complete | Binding Target/inline Body typed recovery and initial Pattern-role transport | delegated recovery selection; M2 implementation, test-only repair and specification/regression audits | existing Binding roles; indented child, dispatch and public integration excluded |
| `notes/design/2026-09-08-successor-declaration-companion-current-item-recovery.md` | Authoritative; private construction complete | declaration companion Introducer/Body/items/separators/brace-close typed recovery | delegated recovery selection; M2 implementation and specification/regression audits | existing Companion roles; selected colon-only Introducer expectation; caller/shell/public excluded |
| `notes/design/2026-09-08-successor-struct-header-current-item-recovery.md` | Authoritative; private construction complete | Struct Name and BodyIntroducer typed recovery | delegated recovery selection; M2 implementation, test-only repair and specification/regression audits | existing Struct roles; ordered body-starter union retained; fields/trailing/public excluded |
| `notes/design/2026-09-08-successor-mod-current-item-recovery.md` | Authoritative; private construction complete | Mod Name/TestName/BodyIntroducer/Body typed recovery and second-test identity correction | delegated recovery selection; M2 implementation, test-only repair and specification/regression audits | existing Mod roles; inline EOF/dedent ownership selected; dispatch/public excluded |
| `notes/design/2026-09-08-successor-role-current-item-recovery.md` | Authoritative; private construction complete | Role BodyIntroducer and inline Body typed recovery | delegated recovery selection; M2 implementation and specification/regression audits | existing Role roles; Head and braced/indented children excluded |
| `notes/design/2026-09-08-successor-impl-current-item-recovery.md` | Authoritative; private construction complete | Impl BodyIntroducer and inline Body typed recovery | delegated recovery selection; M2 implementation, boundary repair and specification/regression audits | existing Impl roles; first-colon Description attribution corrected; dispatch/public excluded |
| `notes/design/2026-09-08-successor-act-current-item-recovery.md` | Authoritative; private construction complete | Act BodyIntroducer Error and inline Body typed recovery | delegated recovery selection; M2 implementation, test-only repair and specification/regression audits | existing Act roles; bodyless terminal and attachment phases retained |
| `notes/design/2026-09-08-successor-d4e-required-type-role-correction.md` | Authoritative conformance clarification | D4e nonempty malformed Type is Primary Error, not caller FieldType Error | existing SD-T/SD-R and user recovery/documentation delegation; primary pre-write check 2026-09-08 | only role label superseded; exact witness/range retained, actual embedded evidence remains open |
| `notes/design/2026-09-09-successor-rowan-cst-only-amendment-draft.md` | Authoritative | direct Rowan CST, recovery-node shape, `CstOutput` removal and syntax-reference reconstruction | user-approved 2026-09-09 after independent review; begin direct-builder migration | Error token / structured Invalid split, recovery ownership, XML-like node notation, direct builder and Yumark gates |
| `notes/design/2026-09-09-successor-rowan-text-attribute-escaping-addendum.md` | Authoritative | reversible `text` spelling in XML-like Rowan CST notation | user-approved 2026-09-09 | canonical backslash/control escapes; no runtime XML or XML entities |
| `notes/design/2026-09-09-successor-error-invalid-topology-ordering-addendum.md` | Authoritative; topology construction complete | topology-only Error-token/Invalid-node migration before diagnostic-ledger retirement | user-approved 2026-09-09 after pre-write specification audit; M2 construction and compiler/recovery delta review closed | record/frozen/public diagnostics remain temporary; full slot schema still precedes their removal |
| `notes/design/2026-09-09-successor-cst-derived-diagnostics-amendment-draft.md` | Authoritative | CST-derived structural diagnostics, environment diagnostics and parser-ledger retirement | user-approved 2026-09-09 after M2 specification and compiler/recovery review | complete per-slot schema is a construction prerequisite; then remove parser/API diagnostic state in one migration |
| `notes/design/2026-09-10-successor-cst-slot-schema-catalog.md` | Draft; partial catalog-audited rows | non-normative organization of the required complete successor CST slot schema | created 2026-09-10 after user-approved two-layer artifact organization | coverage is separate and non-authoritative; full mapping/schema and independent audit remain open |
| `notes/design/2026-09-10-successor-record-pattern-separator-slot.md` | Authoritative; private construction complete | CST-visible separator-phase discriminator for RecordPattern structured Invalid recovery | user selected the local separator-slot wrapper 2026-09-10; M2 reviews closed | one `RecordPatternSeparator` around separator-phase Invalid only; item Invalid remains direct |
| `notes/design/2026-09-10-successor-record-pattern-foreign-close-slot-draft.md` | Authoritative; private construction complete | transparent CST slot for RecordPattern foreign-close raw Error | user approved the mechanism, name, cardinality and narrow supersession 2026-09-10; M2 pre-write/closure reviews closed | append-only `RecordPatternForeignClose`; direct item/separator Error remains phase-selected |
| `notes/design/2026-09-10-successor-expression-delimited-raw-slot-draft.md` | Authoritative; private construction complete | transparent raw Separator/foreign-close CST slots for expression delimiters | user approved the mechanism, names, five-owner scope, cardinality and narrow supersession 2026-09-10; M2 pre-write/closure reviews closed | append-only shared kinds 276/277; direct raw item Error and ProjectionRecord spread RHS remain direct |
| `notes/design/2026-09-10-successor-named-record-type-slot-draft.md` | Authoritative; private M2 construction complete | transparent Separator and terminal Close CST slots for NamedRecordType recovery | user approved names, accepted-close topology, leading ownership and narrow supersession 2026-09-11; pre-write, closure and delta reviews clean | appended kinds 279/280; Separator Missing/Error wrapper and one Close node per committed record, including accepted close |
| `notes/design/2026-09-10-successor-pv-foreign-close-slot-draft.md` | Authoritative; private M2 construction complete | transparent foreign-close CST slot for PolymorphicVariantType raw recovery | user approved local-close scope, name, cardinality, leading/handoff and narrow supersession 2026-09-11; pre-write and closure reviews clean | appended kind 281; `PolymorphicVariantForeignClose` only around locally consumed foreign closes |
| `notes/design/2026-09-12-successor-use-group-foreign-close-topology.md` | Authoritative; private M2 construction complete | transparent `UseGroupForeignClose` around locally consumed mismatched-close Error | user selected option A 2026-09-12; pre-write and closure audits clean | appended kind 282; one wrapper per existing consumed RParen/RBrace under UseGroup/UseExclusionGroup; direct GroupEntry Error and OperatorName unchanged |
| `notes/design/2026-09-12-successor-type-delimited-foreign-close-topology.md` | Authoritative; private M2 construction complete | shared transparent `TypeDelimitedForeignClose` around locally consumed P/E mismatched-close Error | user selected option A 2026-09-12; pre-write, compiler/recovery and repaired-delta audits clean | appended kind 283; immediate P/E parent selects delimiter; Item Error, Call/BracketRow, records and handoff unchanged |
| `notes/design/2026-09-12-successor-ml-separator-leading-ownership.md` | Authoritative; M2 construction complete | ML separator leading is direct enclosing OperatorChain content | user selected option A 2026-09-12; pre-write, compiler/recovery, regression and repaired-delta audits clean | uniform outer-leading topology; E5 admission/Index close/sibling continuation retained |
| `notes/design/2026-09-10-successor-braced-statement-slot-draft.md` | Rejected as unnecessary; no implementation authorization | historical candidate Separator Missing and terminal Close CST slots for BracedStatementBlock | bounded complete ordered-child evidence distinguishes required Statement, Separator and terminal Close despite shared immediate ancestry | no new node; future reopening requires an actual complete ordered-context collision or independent grammar requirement |
| `notes/design/2026-09-09-successor-error-admission-schema-clarification.md` | Draft; AssignmentTail direct-inline slice Authoritative | explicit per-slot admission of error-containing CST sequences | user-directed 2026-09-09 clarification; user approved the independently audited AssignmentTail direct-inline slice 2026-09-10 | no blanket Error/Invalid union; preserve the two structured `Invalid` owners and current continuation contracts |
| `notes/design/2026-09-09-successor-canonical-materialization-seam-draft.md` | Superseded by Rowan CST-only amendment | canonical AST/direct-CST materialization seam | the 2026-09-09 CST-only amendment supersedes its AST/materializer/output topology in full | historical preflight only; no construction |
| `notes/design/2026-09-09-successor-literal-syntax-product-draft.md` | Superseded by Rowan CST-only amendment | owned String/Rule syntax products required by canonical materialization | the 2026-09-09 CST-only amendment supersedes its AST product proposal in full | literal grammar/recovery authority remains separate |
| `notes/design/2026-09-09-successor-canonical-syntax-products-draft.md` | Superseded by Rowan CST-only amendment | candidate AST products for the canonical Statement surface | the 2026-09-09 CST-only amendment supersedes its AST product proposal in full | accepted/recovery authority remains separate |
| `notes/design/2026-09-09-successor-expression-structural-tails-draft.md` | Authoritative; private construction complete | expression assignment / `as Type` Yulang2 admission and selected successor recovery | current user acceptance/recovery delegation; M2 implementation and compiler/recovery + regression closure 2026-09-09 | one-character assignment acquisition, terminal single RHS, asymmetric annotation/Type recovery, propagated Type exit |
| `notes/progress/successor-typed-recovery-ledger.md` | Construction record, not authority | accumulating typed-output callsite/RB inventory | O3a Type/PV, Pattern-owned sites and required Expression operands mapped | typed roles and named non-recovery proofs; tails and remaining SCC, aggregate RB/header/full/Yumark/public remain open |
| `docs/yulang3-architecture.md` | Authoritative | Yulang3 compiler architecture, phases, runtime direction, testing/CI and cache principles | user-approved 2026-08-18 | §4.2.2 parser recovery/header discovery; §6.9 state-slot decision; §8.3 native + Perceus decision |
| `notes/design/2026-08-20-yu-syntax-chasa-architecture.md` | Authoritative | `yu-syntax` chasa grammar, AST/direct-CST ownership, recovery, dispatch and declaration addenda | user-approved addenda recorded in the document and task history | Navigate by named `FOO-G/J/T/R` and gate headings; do not read 1.7 MB indiscriminately |
| `notes/design/2026-09-02-yu-syntax-recursive-descent-rewrite-plan.md` | Authoritative | successor parser execution architecture and atomic migration from chasa to chasa-recover | user-approved 2026-09-02 after M3 review; Gate 4–6 private construction、literal L7、successor typed-output/recovery O0–O2 は完了。owner migration と joint certification は未完 | `I`/`R`/`S`, current-item completion, coverage ledger, and Gates 0–9 |
| `notes/design/2026-09-02-yu-syntax-expression-tail-handoff-addendum.md` | Authoritative | expression の `expr`/`tail` item-handoff 手続きの訂正 | M3 review 後に user-approved 2026-09-02。隔離された Gate 2 direct pilot は 2026-09-03 に完了 | 直接 Rowan 所有権、`level` による tail transfer、Yulang2 の handoff トポロジー |
| `notes/design/2026-09-03-yu-syntax-gate3-fixed-tail-pilot.md` | Authoritative | Gate 3 E2 Field/Path direct tail と E3 borrowed outer-close witness | user-approved 2026-09-03。isolated pilot は同日完了 | Gate 3 の exact scope、direct owner、recovery と deferred fixed item |
| `notes/design/2026-09-03-yu-syntax-gate4-6-scc-amendment.md` | Authoritative | Gate 4–6 の SCC construction、E12 register correction、dynamic operator successor evidence | user-approved 2026-09-03 after M3 review; token-level raw probe だけが戻り読み可。isolated G4a と G4b E5 valid witness は完了、G4b の残る owner controls は未完了 | §3 construction/certification boundary; §4 token-probe-only operator evidence |
| `notes/design/2026-09-03-yu-syntax-rewrite-direct-functions-no-iscut-amendment.md` | Authoritative; outer-state check bridge superseded | successor rewrite の direct function composition と `IsCut` shadow state の除去 | user-approved 2026-09-03; architect audit 済み。G4b へ適用 | direct `FnOnce`, no `IsCut` bridge; minimal-token amendment §2 restores unit-state-only `check` |
| `notes/design/2026-09-03-yu-syntax-minimal-rewrite-token-transaction-amendment.md` | Authoritative | successor rewrite の source-free CST-only topology と lexical `token` transaction | user-approved 2026-09-03; M3 scoped compiler/spec review 済み。最初は chasa-recover token/maybe slice | `token`/`maybe`、`Recover`/builder/item ownership、legacy range/AST assertion の置換範囲 |
| `notes/design/2026-09-03-yu-syntax-g4b-e5-index-call-correction.md` | Authoritative, superseded in primary-witness scope | successor rewrite の旧 E5 index-call witness 訂正 | `x[a(b)]` は nested-call close-owner の補助 control として残る | `)` CallTail / `]` IndexTail ownership |
| `notes/design/2026-09-03-yu-syntax-g4b-e5-index-ml-application-correction.md` | Authoritative | successor rewrite の E5 index ML application witness 訂正 | user-approved 2026-09-03; isolated valid witness completed | `x[a b]` one IndexItem; no rescan / no IndexSeparator |
| `notes/design/2026-09-04-yu-syntax-pv-nt8-same-slot-trivia-amendment.md` | Authoritative | PolymorphicVariant `NT-8 -> NT-6` same-slot retry の direct-CST trivia owner | user-approved 2026-09-04; implementation next | one recovered tag; same-line retry gap is direct Tag child, never Error child |
| `notes/design/2026-09-05-direct-tnd-statement-line-handoff-amendment.md` | Authoritative | direct bare nominal TypeDeclaration の statement-line provenance transport | M3 compiler/spec review and user-approved 2026-09-05 | old ambient-stack implementation routeだけをdirect four-state handoffへ置換する候補 |
| `notes/design/2026-09-05-direct-type-derives-episode-boundary-amendment.md` | Authoritative, C15 implemented | source-free direct TypeDeclaration `derives` construction と outer-TypeExpression contextual boundary | compiler/recovery・specification review and user-approved 2026-09-05; isolated C15 construction completed 2026-09-05; Gate 6 certification / public integration は含まない | direct immediate `TypeOuterBoundary`; fresh nested TypeExpression edge inventory |
| `notes/design/2026-09-05-yumark-fenced-block-comment-lexer-amendment.md` | Authoritative, isolated construction implemented | parsed fence Gate 4 の最初の multiline block-comment lexical construction API | user-approved 2026-09-05; compiler/recovery・specification review approved; isolated test-only construction completed 2026-09-05 | immediate part/item origin, one item-wide split carrier, boundary-first physical line judge; ordinary lexer unchanged |
| `notes/design/2026-09-05-yumark-parsed-yulang-fence-addendum.md` | Authoritative | `yulang` fence を root-style parsed code cell としてstreaming処理する後続 Yumark/rewrite gate | user-approved 2026-09-05; Gate 1、inert Gate 2、isolated Gate 3 witness は完了。full cell closure は rewrite Gates 4–7 の後 | exact info selector, same-depth §5.3 prefix judge, borrowed fence/transition algebra, current-item Vec→boxed split carrier, `YmYulangCodeCell`, rewrite Gates 4–9 prerequisite |
| `notes/design/2026-09-05-direct-literal-cone-addendum.md` | Authoritative, L0–L7 private construction and contextual RuleExpression entry complete | direct rewrite の normal/heredoc String、interpolation、`rule {}`、`~"..."`、Pattern literal の文法/CST/recovery/fence streaming | LC-1–LC-12 を user-approved 2026-09-05。isolated L0–L7、Gate-6 private Statement construction checkpoint、Expression/Pattern contextual `rule {}` entry は完了。typed E/P ledger と joint Gate 4–6 barrier は未完 | one-current-Item fragment handoff, exact quote runs, `%` virtual `Statement*`, separate Rule DSL, contextual `rule` successor-Item route, Pattern opener, typed recovery |
| `notes/design/2026-09-05-fenced-current-item-normalization-addendum.md` | Authoritative, N0–N3, Gate-6 checkpoint, and L6/L7 complete | private direct rewrite の統一 current-Item、foreign physical prefix、fence-aware raw observation と staged migration | user-approved 2026-09-05; N0a–N0c、N1、N2、N3/L5、all direct declaration shells、private canonical Statement dispatch、L6/L7 literal construction は完了。typed joint certification は未完 | `YmQuotePrefix` physical part、transient line fact、ordinary/fenced direct body、normalized grammar-owner migration |
| `notes/design/2026-09-06-yumark-prefix-trailing-whitespace-amendment.md` | Authoritative, implemented | active-prefix body row の最終 `>` 後にある水平空白の foreign-prefix / Yulang-whitespace ownership | user-approved and implemented 2026-09-06; independent specification/regression audit approved | full trailing-H close probe と one-H body-prefix extent の分離 |
| `notes/design/2026-09-05-item-emission-ownership-frontier-amendment.md` | Authoritative, N0a–N0c implemented | direct-rewrite `Item` のsealed physical ownership、一つだけのleading-emission frontier、fragment-aware emission とN0a–N0c移行 | user-approved 2026-09-05; N0aはcompiler/recovery・specification・regression/performance reviewとscoped deltaで完了。N0bはstatic zero inventoryによりno-op完了。N0cは2026-09-06にindependent legacy grammar repairとM2 delta review後のfinal package runで完了 | `first_unemitted_leading`のみ、derived carrier eligibility、PayloadView、terminal boundary adapter。N0c final `cargo test -p yu-syntax`: 906 passed, 0 failed, 2 ignored |
| `notes/design/2026-09-05-direct-expression-successor-acquisition-addendum.md` | Authoritative, successor mechanism partly superseded | direct-rewrite の fence-aware successor acquisition と旧 owner-local statement/declaration entry | user-approved 2026-09-05; §3・§4 construction order と対応する evidence は current-Item normalization addendum により限定 supersession。`TailExit`/pending-Item/recovery contract は継続 | historical L5a/L6a/L5b route、retained `Deferred` zero-effect semantics |
| `notes/design/2026-09-06-direct-declaration-companion-vertical-slices-amendment.md` | Authoritative, all four private owner slices implemented | direct rewrite の declaration-companion Gates 5–9 をownerごとのvertical sliceへ再順序化 | user-approved 2026-09-06; Type、Struct、Enum/Error pair、Act private slices completed after required M2 review。Gate 10 atomic public scopeはrewrite final-root closureまで維持 | companion addendum §13のdirect private construction orderだけを限定 supersession |
| `notes/design/2026-09-06-direct-struct-companion-trailing-close-amendment.md` | Authoritative | private direct Struct trailing companion のactual-close completeness | user-approved 2026-09-06 after architecture/compiler/spec re-entry; recovered nested body may trail only after actual matching close | shared recovery historyなし、Struct body starter phase rule、missing/mismatched close rejection |
| `notes/design/2026-09-06-direct-enum-error-companion-trailing-close-amendment.md` | Authoritative | private direct Enum/Error trailing companion のactual braced-close completeness | user-approved 2026-09-06 after specification re-entry; recovered variant body may trail only after actual matching close | Enum/Error equals-inline asymmetry、missing/mismatched close rejection、no recovery carrier |
| `notes/design/2026-09-06-successor-typed-output-recovery-amendment.md` | Authoritative; O0–O2 and O3a private construction complete | successor rewrite の single committed output、typed recovery records、range derivation、frozen-header reconciliation | O1/O2 complete 2026-09-07; Type/PV construction and callsite inventory complete 2026-09-08, O3b SCC next | accumulating ledger under notes/progress; O4 joint certification and O5–O7 header/full/Yumark/public remain open |
| `notes/design/2026-09-07-successor-structured-recovery-reservation-amendment.md` | Authoritative, output prerequisite complete | O3a PV wrong-kind tag の outer-before-inner structured Error record reservation | user-approved 2026-09-07 after M3 compiler/spec/performance review。最初のnarrow PV O3a checkpointが次 | one recovery-only ordered slot protocol; public scopeなし |
| `notes/design/2026-09-07-successor-structured-recovery-extent-validation-addendum.md` | Authoritative, prerequisite implemented | structured reservation の emitted extent検証だけ | M3 compiler/spec/performance delta review後に user-approved 2026-09-07 | §2 counter / sealed Item-start / exact byte delta; reservation amendment §§3/5/8 の未検証部分だけを限定 supersede |
| `notes/design/2026-09-07-successor-structured-recovery-prerequisite-ordering-addendum.md` | Authoritative, implemented | §7 PV structured recovery fixtureを可能にする Type/PV record publication order | implementation-preflight contradictionから起案、M3 review後に user-approved 2026-09-07。M3 implementation/delta review後に同日完了 | §§2.1–2.3 prefix Error / Parenthesized close Missing / structured TagName order; reservation amendment §8.3–8.4のみ限定 supersede |
| `notes/design/2026-09-07-successor-retry-leading-diagnostic-extent-amendment.md` | Authoritative, T2a local construction complete | valid retry Itemが所有するsame-line leadingを、CSTを動かさずError diagnostic extentだけへ含めるsealed recovery-only exception | T2a ArrowRhs `A ->@ B` implementation reviewがO2 Error-run capability mismatchを発見。M3 compiler/spec/performance reviewとone repair/delta後に user-approved 2026-09-07、同日only consumer実装完了 | §2 fifth sealed terminal operation; §4 T2a evidence; no other owner/public cutover |
| `notes/design/2026-09-07-successor-t2a-yumark-evidence-timing-correction.md` | Authoritative, T2a local construction complete | O3a T2a ArrowRhsのlocal successor evidenceと、O6 successor-Yumark embedded fact equalityの時期訂正 | user selected option 1 and M3 compiler/spec/regression review approved 2026-09-07、同日local subproof実装完了 | matrix contractを弱めず、legacy owner adoptionを再開しない。T2 matrix rowはO6までOpen |
| `notes/design/2026-09-07-successor-t2a-embedded-cst-topology-amendment.md` | Authoritative, T2a local construction complete | T2 ArrowRhsのlegacy Error CST `@ `からsuccessor Error CST `@`＋retry-owned spaceへの一セル出力delta | user selected option 1 and M3 compiler/spec/regression review approved 2026-09-07、同日one-cell topology実装完了 | record tupleとmatrix fact equalityは維持、他ownerへ波及なし |
| `notes/design/2026-09-07-successor-t2b-pathsegment-recovery-amendment.md` | Authoritative, T2b local construction complete | T2b Type(PathSegment) successor recovery、partial block-comment-leading Error operation、owner-local CST token-child delta、O6 embedded evidence timing | architecture preflight のsame-line application continuation/comment-bearing Error topology contradictionをM3 compiler/spec/performance review、two repair/deltaで閉鎖、user option 1 approved 2026-09-07。M3 implementation/delta reviewとone repair/micro-delta後に同日local subproof完了 | only the bounded T2b construction is authorized; matrix row stays Open until O6 |
| `notes/design/2026-09-07-successor-t3-typecall-recovery-amendment.md` | Authoritative, T3 core complete; shared horizontal correction complete | T3 TypeCallのtyped Missing slots/inherited type-ML separator、およびCallArgument retry-leading Error completion | T3 architecture preflightが既存fifth/sixth capabilityでは`T(@ A)`のlegacy CST/Item ownershipを実現できないと確認。M3 compiler/spec/performance review、one repair、compiler/spec delta reviewがclean。active replacement objectiveのrecommended-proposal authorityでapproved 2026-09-07。T3a/T3bともM3 implementation/delta review後にlocal subproof完了。shared P/E/Call legacy boundary baseline `c54c78c6` がT3a post-item horizontal caller/outer priorityを直接反証 | Call separator/provenance/T3b retain; 2026-09-08 recovery authority §§4–6 closes the horizontal correction; declaration-boundary residuals remain separate; matrix row stays Open until O6 |
| `notes/design/2026-09-10-successor-typecall-close-slot-node.md` | Authoritative; private construction complete | TypeCall terminal close phaseを`TypeCallClose` Rowan nodeで構造化し、argument Errorから区別する | user selected the structural node option 2026-09-10 after the close-slot CST ambiguity return | one node per terminal Call close path; reachable fallback is resolved only by the paired residual-policy amendment; no Error relexing/ledger/Invalid |
| `notes/design/2026-09-10-successor-typecall-close-residual-policy.md` | Authoritative; private construction complete | admitted TypeCall argument後の未分類residualをterminal close Errorとして回復する | user selected policy A 2026-09-10 after `T(A@)` fallback witness | residual fallback now reaches close recovery after existing dispatch; no separator/argument recovery fabrication |
| `notes/design/2026-09-07-successor-t4-delimited-register-correction-amendment.md` | Authoritative in retained scope; P/E/B/A recovery partly superseded | corrected T4/T7c role register and aggregate evidence obligations | approved 2026-09-07; current-Item P/E/B/A successors replace their retry-leading/eighth-terminal and relevant local-close representation requirements | P/E/B/A private construction complete 2026-09-08; aggregate T4/T7c and O6/public certification remain open |
| `notes/design/2026-09-07-successor-t4-inherited-type-ml-correction-amendment.md` | Authoritative for inherited provenance; shared horizontal correction complete | OuterTypeApply-only P/E activation and private provenance context | user option 1 approved 2026-09-07; P core then E activation completed under the 2026-09-08 current-Item P/E gate | the recovery-equality suspension is superseded; NonTypeApply activation is not broadened; aggregate Type/embedded/header/O6/public scope remains open |
| `notes/design/2026-09-07-successor-delimited-boundary-priority-correction.md` | Authoritative; private construction complete | shared Call/Parenthesized/EffectRow のphase-aware horizontal boundary-priority correction | fresh/post-separator generic caller・local close・nested outer-close legacy baselinesまでexecution-pinned。M3 compiler/recovery/specification review、two Draft repairs、clean delta review後にuser option 1 approved | conditional supersession and §2 disposition table; only its private Call/P/E construction is authorized; T4E construction remains excluded; 2026-09-08 recovery authority §§4–6 records closure |
| `notes/design/2026-09-07-successor-delimited-pv-extent-correction-addendum.md` | Authoritative; private construction complete | authorized Parenthesized horizontal gap inside existing PV TagName structured Error のthree-phase outer extent | direct legacy Initial/post-separator/post-item extentとflat topologyをexecution-pinned。M3 compiler/recovery/specification review、one Draft repair、clean delta後にuser option 1 approved | only existing P-in-TagName-Error range/evidence; PV parity, Call/E, variants code, public/O6 are excluded; 2026-09-08 recovery authority §§4–6 records closure |
| `notes/design/2026-09-07-successor-delimited-pv-effect-row-extent-addendum.md` | Authoritative; private construction complete | EffectRow ordinary-horizontal rows inside existing PV TagName structured Error のouter extent | direct legacy all six E rowsとbase/candidate successor extent差をexecution-pinned。M3 compiler/recovery/specification review clean後、recorded recommendation delegationでapproved | only E-in-TagName range/evidence; Call head admission, P, PV parity, variants code, public/O6 are excluded; 2026-09-08 recovery authority §§4–6 records closure |
| `notes/design/2026-09-07-successor-pv-wrong-kind-primary-completion-amendment.md` | Superseded; proposal not implemented | historical primary-only PV recovery proposal | 2026-09-08 current-Item PV recovery selects one scoped Type-expression Error with tight tails; no completion adapter | structured reservation/extent/frozen invariants retain independent authority |
| `notes/design/2026-09-07-successor-pv-payload-admission-capability-amendment.md` | Former Draft; legacy-parity premise superseded | historical scalar retry-witness problem record | 2026-09-08 recovery authority removes this construction prerequisite; no observer implemented | new recovery authority §§1–3; current-Item recovery replaces equality-driven design work |
| `notes/design/2026-09-07-successor-pv-scalar-frontier-evidence-plan.md` | Superseded as a prerequisite; evidence retained | historical old-Yulang3 recovery observations, not Yulang2 acceptance | 29 evidence slices preserved; no further exhaustive legacy matrix required | new recovery authority §§1–3; former §§3–5 are not an active queue |
| `notes/design/2026-09-07-successor-ambient-claim-context-prerequisite-amendment.md` | Authoritative, ordinary-only construction/proof pass complete | direct `any_ambient_owner_claims` のimmutable call-stack successor carrier | user option 1 selected 2026-09-07。`b85c32f3` はroot/indented replacement、inline forwarding、braced clear、own-Else/tail retirement、virtual/Yumark `None`、actual-entrance proof controlsをprivate実装。M3 compiler/spec/regression delta review clean | §§2–6; `claims`/PV output/scalar observer/public constructionは除外 |
| `notes/design/2026-08-20-phase2-parser-fixture-schema.md` | Authoritative | Phase 2 parser compatibility fixture product and observed parser/recovery contract | Authoritative; population/open questions continue separately | Problem statement and fixture schema sections |
| `notes/design/2026-08-30-declaration-module-split-plan.md` | Authoritative, completed | Mechanical module topology and visibility for splitting `declaration.rs`; zero behavior change | user-approved 2026-08-30; P1–P14 completed at `a4b98643` | 17-commit plan; no active implementation gate remains |
| `notes/design/2026-08-30-codex-only-orchestration-migration.md` | Authoritative, implemented | `yulang3` agent orchestration, design authority, durable rules, testing/incident placement | approved 2026-08-30; implementation prepared for PR merge | §14 four-commit migration plan |
| `notes/design/2026-08-30-codex-only-orchestration-approval.md` | Authoritative approval record | Status transition for the migration plan above | approved 2026-08-30 | Supersedes the plan's original Proposed header and implementation gate |
| `notes/design/2026-08-30-codex-only-orchestration-migration-report.md` | Implementation report | Scope/configuration/legacy audit for the migration | 2026-08-30 | Commit sequence, verification gate, deferred work |
| `notes/design/2026-08-30-declaration-companion-with-addendum.md` | Authoritative, implemented | Shared declaration-owned `with:` grammar/CST/AST/recovery for Struct/Type/Enum/Error/Act | user-approved 2026-08-30 after independent compiler/spec/performance review; Gates 1–10 completed 2026-09-01 | DC-G/J/T/R; owner matrix; public final-scope matrix and bounded production measurement recorded |
| `notes/design/2026-08-30-declaration-companion-gate2-recovery-amendment.md` | Authoritative | Gate 2 shared canonical Statement malformed-run recovery; permits one comment-atomic ordinary recovery correction | user-approved option 1 on 2026-08-30 | Canonical scanner contract and Gate 2 rollback/verification exception |
| `notes/design/2026-08-30-declaration-companion-gate2-performance-amendment.md` | Authoritative, completed | Gate 2 semantic-work performance gate and bounded verification after two whole-process rollbacks | user-approved 2026-08-30 after independent performance/spec review; Gate 2 completed 2026-08-30 | Supersedes only the enumerated Gate 2 performance/reviewer clauses |
| `notes/design/2026-08-31-declaration-companion-gate3-nud-sink-amendment.md` | Authoritative, completed | Gate 3 generic speculative NUD candidate ErrorSink transaction correction | user-approved option 1 on 2026-08-31; Gate 3 completed 2026-08-31 | Exactly one checkpoint/rollback pair in `expression_nud_candidate_input`; bounded focused/package verification |
| `notes/design/2026-09-01-doc-comment-yumark-addendum.md` | Authoritative | Standalone doc-comment declaration plus structured Yumark, commands, strict block close, raw fences, and command/apply Yulang arguments | user approved 2026-09-01 after M3 design review | Gates 1–2 complete; Gate 3 isolated structural grammar is next |
| `notes/design/2026-09-01-yumark-frame-transaction-storage-addendum.md` | Authoritative | Yumark frame transaction storage/checkpoint lifecycle only | user-approved 2026-09-01 after compiler/performance review | Supersedes only the original addendum §4 undo-log representation |
| `notes/design/2026-09-01-yumark-gate3-embedded-yulang-allocation-amendment.md` | Authoritative | Gate 3/4 shared embedded-Yulang bridge and committed LineState allocation | user-approved 2026-09-01 after compiler/spec review | Supersedes only the original Gate 3/4 allocation sentences |
| `notes/design/2026-09-02-yumark-gate3b-canonical-recovery-episode-amendment.md` | Authoritative | Gate 3b owner-local recovery episodes for embedded canonical Yulang payloads | user-approved 2026-09-02 after architecture re-entry exposed a shared-owner false premise | `LegacyAst` / `EmbeddedObservedAst` / `Direct`; no shadow parse or replay |
| `notes/design/2026-09-02-yumark-gate3b-recovery-adoption-matrix.md` | Authoritative appendix | Finite owner/witness/rollback matrix for Gate 3b recovery adoption | user-approved through the 2026-09-02 Gate 3b decision | Completes Gate 3b amendment §§4 and 6 |

## Index maintenance

For a new design, record path, status, authority scope, approval date, supersession, and the smallest useful section/gate locator. Do not copy the full decision into this index. Mark completed implementation gates without deleting the design history.
