# Yulang3 operating map

## Repository purpose and branch boundary

This branch is the Yulang3 compiler workspace. It contains syntax, HIR, types,
core IR, VM/native backends, benchmarks, tooling, design records, tests, and
public documentation.

The `yulang3` policy does not authorize changes to frozen `main`. Work only on
the branch and scope named by the task.

`AGENTS.md` is a map and a set of hard invariants, not the full rulebook.
Detailed active policy lives under `rules/`.

## Authority

Read `rules/design-authority.md` whenever a task touches a language, API,
semantic, architecture, performance, test-contract, or durable workflow
choice. The short order is:

1. the user's current explicit decision;
2. an in-scope `Authoritative` design/spec;
3. active repository rules;
4. confirmed code/test invariants;
5. general practice or model intuition.

For any Simple-sub inference or F5-replacement task, also read
[`notes/design/2026-10-11-yulang-inference-top-level-principles.md`](notes/design/2026-10-11-yulang-inference-top-level-principles.md)
before relying on older error-recovery or rollback clauses. It is Authoritative
for the inference algorithm, proof/implementation direction, efficiency, and
necessary abnormal-path safety.

Use `notes/design/INDEX.md` to locate the governing source. The index is not a
replacement for the source document.

## Before work

Inspect only the context needed for the task:

- `tasks/current.md`;
- `tasks/research-lab.md` for an active multi-gate inference research goal;
- `notes/design/INDEX.md` and the governing section;
- relevant `spec/` material;
- a relevant handoff or daily record;
- the owning entrypoint, tests, and call sites.

For goal-driven Yulang user decisions and explicit question-board requests,
read `rules/question-board.md` and `questions/` at turn start and before
dependent actions. The separate answering primary reads `questions/AGENTS.md`
in the worktree containing the uncommitted question. The answerer writes only
selected answer files without Git operations; the questioner discovers, validates
and commits the matching approved bundle. No worktree-wide ownership handoff
is required for these disjoint primary-owned paths.

Respect confirmed facts, rejected approaches, forbidden actions, and active
gates in handoffs. Do not restart an approved design or completed investigation
without concrete contradictory evidence.

## Task routing

Read `rules/orchestration-budget.md` before the role matrix. It controls the
default operating mode, reviewer count, review convergence, delta-review scope,
measurement budget, and progress-record ownership. Broader reviewer lists in
older rules describe eligible specialists, not an automatic panel.

Role boundaries and the full matrix are in `rules/agent-orchestration.md`.
Keep the user-selected primary (normally Luna); actual model/effort settings
come from `.codex/`, not historical tier names. The primary owns delegation;
only a `prover` with an explicit proof-coordinator packet may dispatch/contact
its own bounded leaf workers under `rules/agent-orchestration.md`. Other
children return evidence and recommended handoffs. No child inherits primary
authority, independent-review assignment, approval, or Git duties.

Use `rules/research-lab.md` for proactive parallel research. When two useful
assignments have independent inputs and safe ownership, dispatch them in
parallel instead of completing one before starting the other. A sustained
multi-gate research goal normally targets four to six useful active assignments,
subject to actual runtime capacity, resource budgets, and integration capacity.
Keep proof construction, counterexample search, executable experiments, and
source/legacy correspondence as distinct methods rather than duplicate prompts.
M0–M3 reviewer limits apply per coherent artifact; they are not a cap of one
research producer for the whole goal. Small mechanical tasks stay small.

Concurrent write-capable children are allowed on explicitly leased disjoint
files under `rules/git-concurrency.md`. Overlapping writes or unstable shared
dependencies require separate worktrees or serialization of only that seam.
One primary owns each worktree's Git integration. Each packet fixes authority,
baseline, inputs, owned outputs, resource budget, checks, and stop conditions.
Do not expand language semantics or production implementation authority merely
because more workers are available.

Use subagents as the primary working mechanism for bounded exploration,
implementation, and independent review whenever a role-shaped unit exists.
The primary agent retains authority resolution, user interaction, finding
adjudication, repository-state synchronization, and git integration; using a
subagent does not transfer those responsibilities.

- Use built-in `explorer` for read-heavy repository mapping.
- Use `architect` for unresolved decisions or behavior, including cross-layer questions not already settled by an Authoritative gate.
- Use `implementer` for confirmed code changes.
- Use `task_decomposer` for a small set of dependency-aware, executable research packets when the critical path is unclear; the primary schedules them.
- Use `next_action_selector` and `.agents/skills/yulang-next-action/SKILL.md` when the next productive action is unclear, records conflict on restart, or repeated attempts leave the same premise untouched. It selects one evidence-producing action; `task_decomposer` splits that direction when needed. Already-ready work proceeds directly; selection does not run after every result.
- Use `prover` for constructive proofs and exact source-to-proof bridges on leased research paths, with bounded Sol parallelism or Astra escalation when justified.
- For a substantive open constructive proof obligation or source-to-proof bridge, allocate a bounded proof lane alongside independent implementation work; do not wait for every compiler gate to close or for a user to repeat "use prover". Try a real `prover` spawn, then immediately use the supported fallback in `rules/agent-orchestration.md` if named spawning fails. Never replace proof work with an environment-setup task.
- Apply the `yulang-proofs` skill when it is available. A missing skill or custom role is not a proof blocker: read the governing rules and `.codex/agents/prover.toml` directly and continue. Only tool results establish actual agent/model execution.
- Use `researcher` for complementary counterexample, executable-model, and source-correspondence work on leased research paths.
- Use `theory_curator` for meaningful theory-status/dependency synchronization, not new proofs or per-probe bookkeeping.
- Use `compiler_referee` for semantics, root cause, soundness, recovery, and IR invariants.
- Use `spec_auditor` for exact design/spec/test-contract conformance.
- Use `regression_auditor` for sibling paths, fixtures, diagnostics, parity, and public surfaces.
- Use `performance_auditor` for materially uncertain hot-path, asymptotic, resource, or heavy-verification risk.
- Use `docs_writer` for confirmed public documentation, not internal progress bookkeeping.

Do not select current roles from legacy Level numbers, Fable/Sonnet
availability, or ad hoc model-tier prose.

## Proof-first critical-path scheduling

For a new or substantially changed core Simple-sub mechanism whose correctness
or ordinary inference behavior depends on an open class-A/B proof obligation,
**prioritize proving or refuting its decisive invariant before committing to a
proof-dependent implementation strategy.** The primary assigns a constructive
proof, an adversarial falsification or source-coverage check, and independent
review as appropriate before scheduling a large dependent implementation slice.
Pin the original theorem, quantifiers, accepted source behavior, and exact
construction/consumer premises. A plausible design, approved implementation
plan, conditional lemma, or successful test is not proof of its central premise.

Order the shared critical path as: (1) establish or refute the required theorem
or the specific feasibility invariant that controls the design choice;
(2) establish the source-to-construction/consumer correspondence needed to use
that result; (3) integrate the proof-supported implementation and verify it.
If a full theorem requires executable source evidence, permit only the smallest
bounded, reversible, explicitly provisional instrumentation, prototype or
implementation slice needed to establish that evidence before proof closure.
Keep its dependent production/cutover gate OPEN; do not convert such scaffolding
into settled architecture merely because tests pass. Continue genuinely
independent approved fixes and implementation work. Proof priority does not
require completing all global metatheory before writing any compiler code.

When a failed proof or genuine counterexample invalidates a chosen
construction, pause the affected implementation and return the exact
contradiction to the existing independent design-review and user-approval path.
Do not silently reopen or change an Authoritative semantic decision without
that process. Never salvage a failed proof by narrowing the supported source
domain, changing native Simple-sub behavior, or relabeling a required A/B
obligation as optional research. The parent proof gate retains its owner and
OPEN/BLOCKED status until its original claim is genuinely resolved.

## Proof closure and implementation handoff

**The objective of proof work is to discharge the original obligation, not to
perform an activity called proving.** For each correctness or natural-inference
obligation (classes A/B in `rules/compiler-engineering.md`), the primary keeps
a stable parent gate with its original theorem, quantifiers, source domain,
accepted semantics, required evidence and responsible owner. A delegated
lemma, bounded search, conditional derivation, review, test run or research
checkpoint may finish its own packet but does **not** finish that parent gate.

A theorem is proved only when its actual conclusion follows for the original
scope from premises independently established at their source/operational
owners, with no unproved bridge, missing case or assumed implementation
behavior hidden in the statement. A genuine source-qualified counterexample
may instead refute the claim. Require fresh independent proof review before
promoting a theorem's status. Keep abstract mathematics, source correspondence,
compiler implementation and production/cutover gates distinct: success in one
does not automatically close the others.

For every open parent gate, consume each `prover` result rather than merely
filing it: apply a completed lemma to the parent proof, dispatch its *specific*
remaining premise to the responsible proof/source/implementation lane, or mark
the parent explicitly OPEN/BLOCKED with the exact missing evidence and owner.
A leaf's honest report of a reduced premise is a useful handoff, not a
successful parent-goal outcome. Do not count a new note, alternative phrasing,
higher probe count or independently reviewed *conditional* lemma as closure.
When repeated attempts leave the same premise untouched, change the proof
method or investigate the owning construction under the proof-obligation
economy rules; do not automatically create another equivalent proof packet.

**Bridge established proofs into the compiler.** For any proof relevant to
implemented inference, require a concrete correspondence handoff identifying
the original claim, owning source constructors, constraint generation and
accumulation, propagation/transport, consumer/discharge sites, preserved
invariant, exact evidence and test/assertion obligations. Check whether the
current implementation enforces the necessary invariant on *all relevant
paths*, including rollback, replay and diagnostics when applicable. If it
does not, the primary assigns an authorized `implementer` packet and keeps
the implementation gate OPEN until its code, focused verification and required
review are integrated. A mathematical proof that needs no code change may
close its own theorem gate; a test pass or code change alone never proves
soundness, principality or another general theorem.

Bounded proof workers may stop when their allocated budget or genuine
obstruction is reached; do not fabricate a proof, silently strengthen its
hypotheses, or keep a worker running indefinitely. The **parent** obligation
nevertheless retains an owner and an honest OPEN/BLOCKED status until a valid
proof, counterexample, authorized scope change or superseding decision
resolves it. Keep independent implementation work moving where safe without
mistaking that progress for completion of the proof.

## Primary-agent responsibilities

The primary agent owns user interaction, task classification, authority
resolution, reviewer isolation, finding adjudication, staging, commits, PRs,
pushes, progress-record synchronization, and final reporting. After final
verification and required record synchronization, inspect the resolved upstream
ref and every commit in its outbound range before pushing the current working
branch. Push by default only when that whole range is intended and coherent;
otherwise defer with the concrete safety blocker. Never force-push without
explicit user instruction.

An explicit user request authorizes the primary to complete its bounded,
in-scope outcome and the ordinary steps needed to make it reviewable, including
delegation where the operating rules call for it, required review, record
synchronization, and safe coherent checkpoints. Do not stop after a routine
substep to ask whether to continue or repeat a permission request already
covered by the user's instruction. Ask only when a genuine user decision would
materially change scope, semantics, production authority, resources, or another
binding constraint; continue independent authorized work while that decision
is pending.

Keep long-running work backed up at frequent, meaningful checkpoints; do not
wait for the entire multi-gate task to finish before committing and pushing.
After each completed coherent gate or substantial verified natural slice,
synchronize its records, commit that scope, inspect the full outbound range,
and push promptly while the range is still coherent. For parallel research,
also use the research-lab commit conveyor: a frozen disjoint research-only
artifact may be checkpointed and pushed before shared task/theory/index
synchronization when it is explicitly non-authoritative and satisfies
`rules/research-lab.md`'s `commit-ready` criteria. That checkpoint preserves
work; it does not declare the gate complete. For a gate that spans
multiple sessions, preserve and push safe sub-slices, label incomplete
checkpoints honestly, and record the exact next gate and residual risks. Do
not split an atomic change or push a broken, unrelated, or unreviewed range
merely to meet cadence. If a safe push is blocked, keep the useful coherent
local checkpoint and record the concrete blocker; resolve it before allowing
another large completed slice to accumulate.

Pending question directories and unapproved drafts under `questions/` are
explicitly excluded from every checkpoint commit. Keep them unstaged,
uncommitted and visible in Git status, including approved local answers, until
the questioning primary validates and commits the matching question/draft/answer
bundle. The answering primary never performs Git mutations. Tracked instructions and
blank templates are infrastructure, not pending questions.

Before work, choose the lightest sufficient M0–M3 mode, set reviewer,
verification, and measurement budgets, and state the convergence criteria. The
role catalog is not a mandatory panel. Separate the research concurrency budget
from each artifact's reviewer budget. Adjudicate all reviews assigned to that
artifact before one batched repair; unrelated lanes keep running. The primary
coordinates the critical path and integrates evidence rather than personally
performing every proof, probe, and record update in sequence.

The primary's own reread does not count as independent review. A producer never
certifies its own output. Subagents do not stage, commit, push, rewrite history,
or ask interactive permission questions.

Before declaring a coherent gate complete, update `tasks/current.md` and any
required `notes/progress/` or design-status record. Record-only updates do not
trigger a new code-review panel or broad test suite. If synchronization is
deferred, name the exact path and reason.

When a genuine user decision remains, stop only the affected work and present
the exact options and consequences. Do not guess. Continue safe independent
work when possible.

Do not stop the active task because an unrelated file, documentation edit,
concurrent change, or out-of-scope defect appears. Isolate it from staging and
the active diff; when an agent caused the unrelated change, restore only that
known target safely, then continue the authorized task. Escalate only when the
unrelated state overlaps the exact files or invariants needed for the active
work, makes safe integration impossible, or requires a genuine user decision.

## Hard invariants

- Do not implement a new durable decision before user approval is recorded.
- Do not reopen a sufficiently specified Authoritative gate without a concrete contradiction or scope expansion.
- Fix the cause at its owning responsibility; do not mask a symptom downstream.
- Do not make approved ordinary compiler behavior less natural merely to simplify a proof. Treat recurring proof/reconstruction obligations as design feedback; before adding another semantic clause, proof-only relation, or reconstruction layer, apply the proof-obligation-economy rules in `rules/compiler-engineering.md`. This rule does not itself weaken an Authoritative semantic contract or close an existing proof gate.
- Do not alter snapshots, golden files, fixtures, diagnostics expectations, semantic assertions, or test names merely to match current output.
- Do not mix unrelated cleanup, formatting drift, later gates, or broad refactors into a focused change. Warnings observed in a touched package or direct dependency are an exception to scope deferral, not to commit coherence: audit and fix a safe, ownership-local pre-existing cause in a separate coherent commit, while a warning caused by the active diff closes in that diff's commit. Do not defer solely because a warning predates the active diff. If a safe fix needs broader authority, record its exact owner and blocker in `tasks/current.md`.
- Account for new work on hot paths; invoke performance review only under the material-risk trigger and measurement budget in `rules/performance.md`.
- Do not run an unfamiliar broad or heavy test suite before checking its current resource behavior.
- Do not repeat broad checks after record-only or comment-only updates.
- Do not blanket-stash, hard-reset, or clean a working tree that may contain valuable concurrent work.
- Never assign simultaneous writers to the same file or shared mutable output.
  Disjoint-file child writers require explicit leases and stable read inputs
  under `rules/git-concurrency.md`; otherwise use separate worktrees or serialize
  the overlapping seam. Children never mutate the Git index or branch refs.
  Keep the question-board's separate primary-only approval/integration duties.
- Every spawner must explicitly set `fork_turns: "none"` on every supported
  `spawn_agent` call. Only the bounded proof-coordinator exception in
  `rules/agent-orchestration.md` permits child delegation; its leaf workers
  cannot delegate again. Do not inherit parent conversation history. Supply
  the required task scope, governing sources, constraints, and file locators
  in the task message, respecting the same information boundaries.
- Do not call work complete while required task/progress/design records remain silently stale.
- During policy, skill, or configuration maintenance, do not edit compiler code unless the same task explicitly authorizes it. This is not a ban on ordinary authorized compiler implementation.

## Rule routing

- overall rule index: `rules/INDEX.md`
- operating modes, reviewer limits, review convergence, delta review,
  measurement and record budgets: `rules/orchestration-budget.md`
- parallel research, assignment packets, replenishment, and compute budgets: `rules/research-lab.md`
- workflow and handoffs: `rules/workflow.md`
- goal-driven questions and approved answer handoffs: `rules/question-board.md`
- compiler structure, natural behavior, proof-obligation economy and diagnostics: `rules/compiler-engineering.md`
- chasa parser idioms: `rules/parser-chasa.md`
- bug fixing: `rules/bug-fixing.md`
- performance and adaptive measurement budget: `rules/performance.md`
- tests and broad/heavy-suite budget: `rules/testing.md`
- public documentation: `rules/documentation.md`
- git/worktrees/concurrency: `rules/git-concurrency.md`
- observed agent failure patterns: `rules/codex-quirks.md`

Read the relevant files in full; do not load unrelated rules mechanically.

## Communication boundary

The Japanese conversation rules below apply only to direct, user-visible
communication from the primary agent.

Subagent-to-primary reports are internal working communication and use concise
technical English unless the delegated artifact itself requires another
language.

### Intermediate user-visible updates

Do not narrate ordinary progress, exploratory findings, partial edits, failed
attempts, or temporary worktree states to the user. Work silently until a
coherent result is ready.

Send an intermediate user-visible message only when it is necessary to obtain
a genuine user decision, report a blocker that prevents meaningful progress,
or disclose a material risk that changes the authorized scope. A status update
explicitly requested by the user is also allowed. In every other case, report
the completed result, verification, and remaining decisions only in the final
response.

### Command-output visibility

Do not relay raw command output, tool output, build logs, or subagent work
inspection to the user by default. User-visible progress updates summarize only
the decision-relevant result: changed paths, verification outcome, findings,
blockers, and remaining risk. Keep command output internal and bound any tool
capture to the smallest amount needed for the task.

Inspecting a subagent's work must use its concise report and narrow diff/status
evidence; never print command output merely to establish what the subagent
did. Show raw output only when the user explicitly requests it, or when a
short, directly relevant excerpt is necessary to explain a failure. State why
the excerpt is needed and redact or omit unrelated material.

Generated artifacts do not inherit the conversation style. Documentation,
README files, specifications, release notes, diagnostics, UI text, code
comments, and design records use the register required by their audience and
existing conventions.

## 行動

相手の話を最後まで聞く。
助言は押し付けず、選択肢と理由を示す。
ただし、危ない設計・壊れやすい変更・性能を悪くする変更が見えている場合は、やわらかくても明確に止める。

不明点があっても、すぐ質問で止まらない。
既存ファイル、タスク文脈、テスト、命名から推測できることは先に調べる。
それでも判断できない場合だけ、短く確認する。

## Verification and final report

Run the smallest safe checks governed by `rules/testing.md` and the selected
mode. Builds and tests are deterministic evidence, not independent review.
Performance experiments obey `rules/performance.md`; report sample and process
counts rather than silently expanding a measurement table.

Before integrating, inspect branch, status, explicit staged paths, diff scope,
and concurrent work. Report what changed, governing authority, selected mode
and reviewers, exact checks, measurement budget consumed, progress/design
records updated or deferred, omitted verification, commits/branch, and
remaining risks or decisions.

Before a user-visible response, also verify that direct conversation follows
the Japanese communication rules above and that generated artifacts did not
inherit them.
