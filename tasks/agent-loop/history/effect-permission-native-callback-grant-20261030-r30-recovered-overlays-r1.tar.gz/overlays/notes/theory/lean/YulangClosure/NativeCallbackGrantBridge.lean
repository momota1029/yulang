import YulangClosure.CallbackHygieneCorrespondence

/-!
R29 construction revision 1, constructed but unchecked.
Baseline dd3d5ee22; final Rust/certificate pins are intentionally not supplied yet.
This finite observation projection does not define source typing or assert a
native simulation. receiving.rs CallbackResultSchema::from_parameter,
callback_entry, callback_entry_for_apply, callback_use, execution, observe,
local_grant and callback_grant are separate owners. machine.rs selects a direct
Parameter/Observe Name at Apply, opens the callback result execution and mints
the actual request before Catch selects its resolved operation and arm.

Site projection retains root/occurrence only. Byte spans are deliberately erased:
several native guards compare only those coordinates. No full-span identity
claim follows. Concrete effect IDs must be injectively encoded by the source
extractor; display names, row roots and result values are never identity keys.
The selected callback has no effect type arguments. General type arguments,
symbolic rows, RootComp, whole History, and original A/B remain OPEN.
-/
namespace YulangClosure.NativeCallbackGrantBridge
open CallbackHygieneCorrespondence

/-- Coordinates actually compared by the native guards; no byte-span theorem. -/
def siteKey (s : Site) : Site := ⟨s.root, s.occurrence, 0, 0⟩

def receiptKey (r : Receipt) : Receipt := {r with site := siteKey r.site}

structure NativeEntry where
  handle : Id .entry
  annotation : Annotation
  receiver : Id .invocation
  value : Id .payload
  incomingValue : Id .payload
  incomingView : Id .view
  view : Id .view
  formalReceipt : Receipt
  deriving DecidableEq, Repr

structure NativeName where
  entry : Id .entry
  resolvedFormal : Id .formal
  site : Site
  receipt : Receipt
  deriving DecidableEq, Repr

structure NativeUse where
  handle : Id .use
  entry : Id .entry
  sourceView : Id .view
  callee : Site
  apply : Site
  resultView : Id .view
  resultReceipt : Receipt
  deriving DecidableEq, Repr

def permission (e : NativeEntry) : Permission :=
  ⟨e.annotation.definition, e.annotation.binding, siteKey e.annotation.lambdaSite,
   e.annotation.formal, e.receiver, .callbackResult, e.annotation.families⟩

def entry (e : NativeEntry) : Entry :=
  ⟨e.handle, permission e, e.incomingView, e.view, e.value, receiptKey e.formalReceipt⟩

def name (n : NativeName) : NameRead :=
  ⟨n.entry, n.resolvedFormal, siteKey n.site, receiptKey n.receipt⟩

/-- Native Use has no stored owner or Name receipt. Those come from the actual
result receipt and direct-Name constructor, never a family-name comparison. -/
def callbackUse (e : NativeEntry) (n : NativeName) (u : NativeUse) : CallbackUse :=
  ⟨u.handle, u.entry, u.resultReceipt.owner, u.sourceView,
   e.formalReceipt.handle, n.receipt.handle, siteKey u.callee, siteKey u.apply,
   u.resultView, receiptKey u.resultReceipt⟩

/-- Aggregate of distinct constructor/store checks. In particular the Name
checks belong to callback_entry_for_apply, not callback_grant. Exact original
receipt slots are retained in the raw records; only their keys are compared. -/
def ConstructorChecks (e : NativeEntry) (n : NativeName) (u : NativeUse) : Prop :=
  e.annotation.port = .callbackResult ∧
  e.value = e.incomingValue ∧
  e.formalReceipt.owner = e.receiver ∧
  e.formalReceipt.view = e.view ∧
  siteKey e.formalReceipt.site = siteKey e.annotation.lambdaSite ∧
  e.formalReceipt.formal = some e.annotation.formal ∧
  n.entry = e.handle ∧ n.resolvedFormal = e.annotation.formal ∧
  n.receipt.owner = e.receiver ∧ n.receipt.view = e.view ∧
  siteKey n.receipt.site = siteKey n.site ∧ n.receipt.formal = none ∧
  u.entry = e.handle ∧ u.resultReceipt.owner = e.receiver ∧
  u.sourceView = e.view ∧ siteKey u.callee = siteKey n.site ∧
  u.resultReceipt.view = u.resultView ∧
  siteKey u.resultReceipt.site = siteKey u.apply ∧ u.resultReceipt.formal = none

instance (e : NativeEntry) (n : NativeName) (u : NativeUse) :
    Decidable (ConstructorChecks e n u) := by unfold ConstructorChecks; infer_instance

def validateConstructors (e : NativeEntry) (n : NativeName) (u : NativeUse) : Bool :=
  decide (ConstructorChecks e n u)

/-- Generic success inversion; actual Rust extraction is a separate premise. -/
theorem constructor_success_use {e : NativeEntry} {n : NativeName} {u : NativeUse}
    (success : validateConstructors e n u = true) :
    UseReady (entry e) (name n) (callbackUse e n u) := by
  have checks : ConstructorChecks e n u := of_decide_eq_true success
  rcases checks with ⟨_, _, fo, fv, fs, ff, ne, nf, no, nv, ns, nn, ue, uo, uv, uc, rv, rs, rn⟩
  exact ⟨rfl, fo, fv, fs, ff, ne, nf, no, nv, ns, nn, ue, uo, uv,
    rfl, rfl, uc, rfl, rv, rs, rn⟩

/-- Production ExecutionView has no callback-use field. The use is recovered
from the result ViewKind, independently of the request origin projection. -/
structure NativeExecution where
  view : Id .view
  receipt : Id .receipt
  occurrence : Nat
  deriving DecidableEq, Repr

/-- Production Observation; construction-time bounds are test-only evidence. -/
structure NativeObserved where
  execution : NativeExecution
  observer : Nat
  event : Id .event
  deriving DecidableEq, Repr

structure NativeObservation where
  entryRecord : NativeEntry
  nameRecord : NativeName
  useRecord : NativeUse
  execution : Execution
  /- The owning Receiving.executions table, indexed by occurrence. -/
  executionTable : List (Id .view × Id .receipt)
  /- These are copied from the request owner, not from candidate JSON. -/
  requestObservations : List NativeObserved
  requestConstructionBounds : List Nat
  selectedObservationIndex : Nat
  candidateObservation : NativeObserved
  candidateConstructionBound : Nat
  nextObserver : Nat
  request : Request
  deriving DecidableEq, Repr

def ExecutionChecks (b : NativeObservation) : Prop :=
  b.executionTable[b.execution.occurrence]? = some (b.execution.view, b.execution.receipt) ∧
  b.requestObservations[b.selectedObservationIndex]? = some b.candidateObservation ∧
  b.requestConstructionBounds[b.selectedObservationIndex]? = some b.candidateConstructionBound ∧
  b.candidateObservation.observer < b.candidateConstructionBound ∧
  b.candidateConstructionBound ≤ b.nextObserver ∧
  b.candidateObservation.event = b.request.event ∧
  b.candidateObservation.execution =
    ⟨b.execution.view, b.execution.receipt, b.execution.occurrence⟩ ∧
  b.execution.useHandle = b.useRecord.handle ∧
  b.execution.view = b.useRecord.resultView ∧
  b.execution.receipt = b.useRecord.resultReceipt.handle ∧
  b.request.origin = .callback b.execution

instance (b : NativeObservation) : Decidable (ExecutionChecks b) := by
  unfold ExecutionChecks; infer_instance

def validateExecution (b : NativeObservation) : Bool := decide (ExecutionChecks b)

/-- A finite slice of supplied records. Membership here does not establish a
native execution history, annotation formation, liveness or actual emission. -/
def portSlice (b : NativeObservation) : State :=
  { entries := [entry b.entryRecord], names := [name b.nameRecord],
    uses := [callbackUse b.entryRecord b.nameRecord b.useRecord],
    executions := [b.execution] }

theorem constructor_success_port {b : NativeObservation}
    (constructors : validateConstructors b.entryRecord b.nameRecord b.useRecord = true)
    (execution : validateExecution b = true) :
    PortReady (portSlice b) b.request (permission b.entryRecord) := by
  have useReady := constructor_success_use constructors
  have checks : ExecutionChecks b := of_decide_eq_true execution
  rcases checks with ⟨_, _, _, _, _, _, _, handle, view, receipt, origin⟩
  apply Or.inl
  refine ⟨entry b.entryRecord, by simp [portSlice], name b.nameRecord,
    by simp [portSlice], callbackUse b.entryRecord b.nameRecord b.useRecord,
    by simp [portSlice], b.execution, by simp [portSlice], rfl, ?_, handle, view, receipt, origin⟩
  simp only [checkedUse, if_pos useReady]

/-- Catch records are separate from result values and callback permission. -/
structure NativeCatch where
  consumer : Consumer
  installed : InstalledCatch
  /- Selected live dynamic Catch frames, with installation handles distinct from sites. -/
  liveInstallations : List InstalledCatch
  arm : Arm
  activeOwners : List (Id .invocation)
  pendingRequests : List Request
  emittedRequests : List Request
  deriving DecidableEq, Repr

def CatchChecks (b : NativeObservation) (c : NativeCatch) : Prop :=
  b.request ∈ c.pendingRequests ∧ b.request ∈ c.emittedRequests ∧
  c.installed ∈ c.liveInstallations ∧
  c.consumer.owner ∈ c.activeOwners ∧ c.consumer.owner = b.entryRecord.receiver ∧
  b.request.operation.family ∈ b.entryRecord.annotation.families ∧
  c.consumer.operation = b.request.operation ∧ c.consumer.event = b.request.event ∧
  c.consumer.payload = b.request.payload ∧
  c.consumer.handler = c.installed.handle ∧
  siteKey c.consumer.catchSite = siteKey c.installed.site ∧
  c.consumer.owner = c.installed.owner ∧ c.arm ∈ c.installed.arms ∧
  c.consumer.arm = c.arm.handle ∧ siteKey c.consumer.armSite = siteKey c.arm.site ∧
  c.consumer.operation = c.arm.operation

instance (b : NativeObservation) (c : NativeCatch) : Decidable (CatchChecks b c) := by
  unfold CatchChecks; infer_instance

def validateCatch (b : NativeObservation) (c : NativeCatch) : Bool := decide (CatchChecks b c)
def consumerKey (c : Consumer) : Consumer :=
  {c with catchSite := siteKey c.catchSite, armSite := siteKey c.armSite}
def armKey (a : Arm) : Arm := {a with site := siteKey a.site}
def installedKey (h : InstalledCatch) : InstalledCatch :=
  {h with site := siteKey h.site, arms := h.arms.map armKey}
def catchSlice (b : NativeObservation) (c : NativeCatch) : State :=
  {portSlice b with permissions := [permission b.entryRecord],
   active := c.activeOwners, installed := c.liveInstallations.map installedKey,
   pending := c.pendingRequests, emitted := c.emittedRequests}

theorem constructor_success_catch {b : NativeObservation} {c : NativeCatch}
    (constructors : validateConstructors b.entryRecord b.nameRecord b.useRecord = true)
    (execution : validateExecution b = true) (caught : validateCatch b c = true) :
    CatchReady (catchSlice b c) b.request (consumerKey c.consumer) (permission b.entryRecord) := by
  have port := constructor_success_port constructors execution
  have checks : CatchChecks b c := of_decide_eq_true caught
  rcases checks with ⟨pending, _, installedMember, active, owner, family, operation, event, payload,
    handler, catchSite, installedOwner, armMember, arm, armSite, armOperation⟩
  refine ⟨pending, by simp [catchSlice], active, owner, family, ?_, operation, event,
    payload, installedKey c.installed, ?_, handler, catchSite,
    installedOwner, armKey c.arm, ?_, arm, armSite, armOperation⟩
  · exact port
  · exact List.mem_map.mpr ⟨c.installed, installedMember, rfl⟩
  · exact List.mem_map.mpr ⟨c.arm, armMember, rfl⟩

/-- Publishing permission leaves actual inflow untouched, even in this slice. -/
theorem permission_does_not_emit (s : State) (p : Permission) :
    ({s with permissions := p :: s.permissions} : State).pending = s.pending ∧
    ({s with permissions := p :: s.permissions} : State).emitted = s.emitted := ⟨rfl, rfl⟩

/-!
The following records erase SourceEffectId and HirParameterId to injective typed
IDs supplied by extraction. Display strings are never compared. NativeEntry and
NativeUse are selected constructor records enriched with incoming and direct-Name
coordinates; the decision below ignores those extra coordinates exactly where
the production callback_grant does. Production Observation has no bound field.
-/

inductive NativeOwner where
  | moduleRun
  | invocation (id : Id .invocation)
  deriving DecidableEq, Repr

inductive NativeViewKind where
  | ordinary | rootComp
  | callbackEntry (entry : Id .entry)
  | callbackResult (use : Id .use)
  deriving DecidableEq, Repr

/-- Native receipts also admit ModuleRun. The selected positive callback
projection embeds an independently checked Invocation receipt below. -/
structure NativeReceipt where
  owner : NativeOwner
  view : Id .view
  site : Site
  formal : Option (Id .formal)
  deriving DecidableEq, Repr

def nativeReceipt (r : Receipt) : NativeReceipt :=
  ⟨.invocation r.owner, r.view, r.site, r.formal⟩

structure NativeView where
  value : Id .payload
  kind : NativeViewKind
  deriving DecidableEq, Repr

/-- Ordered tables are copied from the Receiving owner. No table membership is
inferred from equal effect families or from a successful model predicate. -/
structure NativeStore where
  entries : List NativeEntry
  uses : List NativeUse
  receipts : List NativeReceipt
  /- Receiving.receipt_index, as key/value associations; ordering is irrelevant. -/
  receiptIndex : List (NativeOwner × Id .view × Option (Id .formal) × Id .receipt)
  /- Source code entries filtered to Name(Parameter formal, Observe). -/
  directNameInstructions : List (Site × Id .formal)
  views : List NativeView
  executions : List (Id .view × Id .receipt)
  nextObserver : Nat
  activeInvocations : List (Id .invocation)
  deriving DecidableEq, Repr

/-- The conjuncts of production receiving.rs::callback_grant after its six
successful lookups. Source-site comparison erases byte spans only. -/
def CallbackGuard (e : NativeEntry) (u : NativeUse)
    (resultReceipt formalReceipt : NativeReceipt) (entryView resultView : NativeView)
    (x : NativeExecution) (owner : NativeOwner) (receiver : Id .invocation)
    (family : Nat) : Prop :=
  u.resultView = x.view ∧ u.resultReceipt.handle = x.receipt ∧
  u.sourceView = e.view ∧ e.receiver = receiver ∧
  owner = .invocation receiver ∧
  entryView.kind = .callbackEntry u.entry ∧
  e.value = entryView.value ∧ e.value = resultView.value ∧
  resultReceipt.owner = owner ∧
  resultReceipt.view = u.resultView ∧ resultReceipt.formal = none ∧
  siteKey resultReceipt.site = siteKey u.apply ∧
  formalReceipt.owner = owner ∧
  formalReceipt.view = e.view ∧
  formalReceipt.formal = some e.annotation.formal ∧
  siteKey formalReceipt.site = siteKey e.annotation.lambdaSite ∧
  family ∈ e.annotation.families

instance (e : NativeEntry) (u : NativeUse) (rr fr : NativeReceipt)
    (ev rv : NativeView) (x : NativeExecution) (o : NativeOwner)
    (r : Id .invocation) (f : Nat) : Decidable (CallbackGuard e u rr fr ev rv x o r f) := by
  unfold CallbackGuard; infer_instance

/-- A direct executable transcription of callback_grant's lookups and guard.
The entry/result receipt handles used for lookup come from the use and entry
records, not from the candidate observation's displayed owners. -/
def sourceCallbackGrant (s : NativeStore) (useHandle : Id .use)
    (x : NativeExecution) (owner : NativeOwner) (receiver : Id .invocation)
    (family : Nat) : Bool :=
  match s.uses[useHandle.ordinal]? with
  | none => false
  | some u =>
    match s.entries[u.entry.ordinal]?, s.receipts[u.resultReceipt.handle.ordinal]? with
    | some e, some rr =>
      match s.receipts[e.formalReceipt.handle.ordinal]?,
          s.views[e.view.ordinal]?, s.views[u.resultView.ordinal]? with
      | some fr, some ev, some rv => decide (CallbackGuard e u rr fr ev rv x owner receiver family)
      | _, _, _ => false
    | _, _ => false

/-- Each observation is tested against its actual request event, current observer
counter and execution store, then against the actual CallbackResult view kind.
Construction-time bounds authenticate extraction; they are not this guard. -/
def sourceObservationGrant (s : NativeStore) (event : Id .event)
    (owner : NativeOwner) (receiver : Id .invocation) (family : Nat)
    (o : NativeObserved) : Bool :=
  if o.event = event ∧ o.observer < s.nextObserver ∧
      s.executions[o.execution.occurrence]? = some (o.execution.view, o.execution.receipt) then
    match s.views[o.execution.view.ordinal]? with
    | some ⟨_, .callbackResult handle⟩ =>
      sourceCallbackGrant s handle o.execution owner receiver family
    | _ => false
  else false

def sourceCallbackScan (s : NativeStore) (event : Id .event)
    (owner : NativeOwner) (receiver : Id .invocation) (family : Nat) :
    List NativeObserved → Bool
  | [] => false
  | o :: rest => if sourceObservationGrant s event owner receiver family o then true
      else sourceCallbackScan s event owner receiver family rest

/-- Exact callback prefix of local_grant. The RootComp continuation is an
arbitrary Bool, so this definition makes no RootComp correspondence claim. A
successful callback short-circuits independently of that continuation. -/
def sourceLocalGrant (s : NativeStore) (observations : List NativeObserved)
    (event : Id .event) (owner : NativeOwner) (family : Nat)
    (rootCompContinuation : Bool) : Bool :=
  match owner with
  | .moduleRun => false
  | .invocation receiver =>
    if receiver ∈ s.activeInvocations then
      if sourceCallbackScan s event owner receiver family observations then true
      else rootCompContinuation
    else false

/-- These are owner-table joins, not an assumed successful Grant. Together with
ConstructorChecks they connect the direct Name/Apply constructors to the same
entry/use/receipts tested by the decision. -/
def StoreJoins (s : NativeStore) (b : NativeObservation) : Prop :=
  s.entries[b.entryRecord.handle.ordinal]? = some b.entryRecord ∧
  s.uses[b.useRecord.handle.ordinal]? = some b.useRecord ∧
  s.receipts[b.entryRecord.formalReceipt.handle.ordinal]? = some (nativeReceipt b.entryRecord.formalReceipt) ∧
  s.receipts[b.useRecord.resultReceipt.handle.ordinal]? = some (nativeReceipt b.useRecord.resultReceipt) ∧
  s.views[b.entryRecord.view.ordinal]? =
    some ⟨b.entryRecord.value, .callbackEntry b.entryRecord.handle⟩ ∧
  s.views[b.useRecord.resultView.ordinal]? =
    some ⟨b.entryRecord.value, .callbackResult b.useRecord.handle⟩ ∧
  s.executions = b.executionTable ∧ s.nextObserver = b.nextObserver ∧
  b.entryRecord.receiver ∈ s.activeInvocations ∧
  s.receipts[b.nameRecord.receipt.handle.ordinal]? = some (nativeReceipt b.nameRecord.receipt) ∧
  (.invocation b.entryRecord.receiver, b.entryRecord.view, none,
    b.nameRecord.receipt.handle) ∈ s.receiptIndex ∧
  (b.nameRecord.site, b.nameRecord.resolvedFormal) ∈ s.directNameInstructions ∧
  ∃ incomingKind, s.views[b.entryRecord.incomingView.ordinal]? =
    some ⟨b.entryRecord.incomingValue, incomingKind⟩

instance (s : NativeStore) (b : NativeObservation) : Decidable (StoreJoins s b) := by
  unfold StoreJoins; infer_instance

def validateStoreJoins (s : NativeStore) (b : NativeObservation) : Bool :=
  decide (StoreJoins s b)

/-- Source constructor joins suffice for the actual callback decision. Family
membership is the resolved source row check, not native Grant success. -/
theorem constructors_callback_guard {b : NativeObservation}
    (constructors : validateConstructors b.entryRecord b.nameRecord b.useRecord = true)
    (execution : validateExecution b = true)
    (family : b.request.operation.family ∈ b.entryRecord.annotation.families) :
    CallbackGuard b.entryRecord b.useRecord (nativeReceipt b.useRecord.resultReceipt)
      (nativeReceipt b.entryRecord.formalReceipt)
      ⟨b.entryRecord.value, .callbackEntry b.entryRecord.handle⟩
      ⟨b.entryRecord.value, .callbackResult b.useRecord.handle⟩
      b.candidateObservation.execution (.invocation b.entryRecord.receiver)
      b.entryRecord.receiver b.request.operation.family := by
  have checks : ConstructorChecks b.entryRecord b.nameRecord b.useRecord := of_decide_eq_true constructors
  rcases checks with ⟨_, _, fo, fv, fs, ff, _, _, _, _, _, _, ue, uo, uv, _, rv, rs, rn⟩
  have executionChecks : ExecutionChecks b := of_decide_eq_true execution
  rcases executionChecks with ⟨_, _, _, _, _, _, observed, _, view, receipt, _⟩
  rw [observed]
  exact ⟨view.symm, receipt.symm, uv, rfl, rfl, by rw [ue], rfl, rfl,
    congrArg NativeOwner.invocation uo, rv, rn, rs,
    congrArg NativeOwner.invocation fo, fv, ff, fs, family⟩

/-- The source store is independently joined to the constructor records before
rewriting the six lookups. No UseReady/PortReady/Grant premise is supplied. -/
theorem constructors_callback_decision {s : NativeStore} {b : NativeObservation}
    (constructors : validateConstructors b.entryRecord b.nameRecord b.useRecord = true)
    (execution : validateExecution b = true)
    (stores : validateStoreJoins s b = true)
    (family : b.request.operation.family ∈ b.entryRecord.annotation.families) :
    sourceCallbackGrant s b.useRecord.handle b.candidateObservation.execution
      (.invocation b.entryRecord.receiver) b.entryRecord.receiver
      b.request.operation.family = true := by
  have joins : StoreJoins s b := of_decide_eq_true stores
  rcases joins with ⟨e, u, fr, rr, ev, rv, _, _, _⟩
  have constructorsChecks : ConstructorChecks b.entryRecord b.nameRecord b.useRecord := of_decide_eq_true constructors
  rcases constructorsChecks with ⟨_, _, _, _, _, _, _, _, _, _, _, _, ue, _⟩
  have guard := constructors_callback_guard constructors execution family
  simp only [sourceCallbackGrant, u, ue, e, rr, fr, ev, rv]
  exact decide_eq_true guard

/-- A successful tested member makes the callback prefix return true; earlier
members may themselves succeed or fail, matching the native ordered loop. -/
theorem callback_scan_of_member {s : NativeStore} {event : Id .event}
    {owner : NativeOwner} {receiver : Id .invocation} {family : Nat}
    {observations : List NativeObserved} {o : NativeObserved}
    (member : o ∈ observations)
    (grant : sourceObservationGrant s event owner receiver family o = true) :
    sourceCallbackScan s event owner receiver family observations = true := by
  induction observations with
  | nil => cases member
  | cons first rest ih =>
    simp only [List.mem_cons] at member
    rcases member with same | later
    · subst first
      simp [sourceCallbackScan, grant]
    · simp only [sourceCallbackScan]
      split
      · rfl
      · exact ih later

/-- Sufficient callback branch of actual local_grant, over the request-owned
vector. Both successful decisions are derived; RootComp is never needed. -/
theorem constructors_local_grant {s : NativeStore} {b : NativeObservation}
    (constructors : validateConstructors b.entryRecord b.nameRecord b.useRecord = true)
    (execution : validateExecution b = true)
    (stores : validateStoreJoins s b = true)
    (family : b.request.operation.family ∈ b.entryRecord.annotation.families)
    (rootCompContinuation : Bool) :
    sourceLocalGrant s b.requestObservations b.request.event
      (.invocation b.entryRecord.receiver) b.request.operation.family
      rootCompContinuation = true := by
  have joins : StoreJoins s b := of_decide_eq_true stores
  rcases joins with ⟨_, _, _, _, _, rv, executions, counter, active, _⟩
  have executionChecks : ExecutionChecks b := of_decide_eq_true execution
  rcases executionChecks with ⟨table, selected, _, bound, current, event, observed, _, view, _⟩
  have member : b.candidateObservation ∈ b.requestObservations :=
    List.mem_of_getElem? selected
  have observer := Nat.lt_of_lt_of_le bound current
  have callback := constructors_callback_decision constructors execution stores family
  have tested : sourceObservationGrant s b.request.event
      (.invocation b.entryRecord.receiver) b.entryRecord.receiver
      b.request.operation.family b.candidateObservation = true := by
    have observedView : b.candidateObservation.execution.view = b.execution.view :=
      congrArg NativeExecution.view observed
    have observedOccurrence : b.candidateObservation.execution.occurrence = b.execution.occurrence :=
      congrArg NativeExecution.occurrence observed
    have observedReceipt : b.candidateObservation.execution.receipt = b.execution.receipt :=
      congrArg NativeExecution.receipt observed
    have observedTable : s.executions[b.candidateObservation.execution.occurrence]? =
        some (b.candidateObservation.execution.view, b.candidateObservation.execution.receipt) := by
      simpa only [executions, observedView, observedOccurrence, observedReceipt] using table
    have observedResult : b.candidateObservation.execution.view = b.useRecord.resultView :=
      observedView.trans view
    have observedKind : s.views[b.candidateObservation.execution.view.ordinal]? =
        some ⟨b.entryRecord.value, .callbackResult b.useRecord.handle⟩ := by
      simpa only [observedResult] using rv
    have valid : b.candidateObservation.event = b.request.event ∧
        b.candidateObservation.observer < s.nextObserver ∧
        s.executions[b.candidateObservation.execution.occurrence]? =
          some (b.candidateObservation.execution.view, b.candidateObservation.execution.receipt) :=
      ⟨event, by simpa only [counter] using observer, observedTable⟩
    simp only [sourceObservationGrant, if_pos valid, observedKind]
    exact callback
  have scan := callback_scan_of_member member tested
  simp [sourceLocalGrant, active, scan]

/-- The checked Catch result uses the same projected request and dynamic
installation, independently of the runtime result integer. -/
theorem constructors_checked_catch {b : NativeObservation} {c : NativeCatch}
    (constructors : validateConstructors b.entryRecord b.nameRecord b.useRecord = true)
    (execution : validateExecution b = true) (caught : validateCatch b c = true) :
    checkedCatch (catchSlice b c) b.request (consumerKey c.consumer)
      (permission b.entryRecord) =
      some ⟨b.request, consumerKey c.consumer, permission b.entryRecord⟩ := by
  have ready := constructor_success_catch constructors execution caught
  simp only [checkedCatch, if_pos ready]

/-- One shared record bundle supplies the callback port, actual callback/local
Grant decision prefix and selected R26 consumer. Application to native bytes
still requires independently authenticated extraction, not these propositions. -/
theorem constructors_callback_and_catch {s : NativeStore} {b : NativeObservation}
    {c : NativeCatch}
    (constructors : validateConstructors b.entryRecord b.nameRecord b.useRecord = true)
    (execution : validateExecution b = true)
    (stores : validateStoreJoins s b = true)
    (caught : validateCatch b c = true)
    (rootCompContinuation : Bool) :
    PortReady (catchSlice b c) b.request (permission b.entryRecord) ∧
    sourceLocalGrant s b.requestObservations b.request.event
      (.invocation b.entryRecord.receiver) b.request.operation.family
      rootCompContinuation = true ∧
    checkedCatch (catchSlice b c) b.request (consumerKey c.consumer)
      (permission b.entryRecord) =
      some ⟨b.request, consumerKey c.consumer, permission b.entryRecord⟩ := by
  have catchChecks : CatchChecks b c := of_decide_eq_true caught
  rcases catchChecks with ⟨_, _, _, _, _, family, _⟩
  exact ⟨constructor_success_port constructors execution,
    constructors_local_grant constructors execution stores family rootCompContinuation,
    constructors_checked_catch constructors execution caught⟩

/-!
Parent application: constructor_success_port and constructor_success_catch supply
only R26's finite callback/Catch guards; constructors_local_grant connects the
same request-owned vector to the source callback prefix independently of any
RootComp continuation. constructors_checked_catch applies the guard to R26's
actual checkedCatch consumer. No History, result value or native success is an
unexplained premise. All validation successes here still require an authenticated
concrete source-store extraction; arbitrary supplied records are not provenance.

First remaining premise/owner: the Rust lane must freeze the actual certificate,
independent request snapshot, construction-bound side evidence, table joins,
resolved-ID injection, annotation formation and selected installation/arm.
Luna must provide its final certificate hash and fresh serial audit receipt.
No concrete instance is constructed until those bytes exist. Whole History,
annotation generation/propagation, RootComp, symbolic rows/type arguments, original
A/B, full source scope and shared strategy, principality, termination, production
and independent review remain OPEN.
-/
end YulangClosure.NativeCallbackGrantBridge
