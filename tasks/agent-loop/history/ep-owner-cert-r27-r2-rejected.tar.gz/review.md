# R27 R2 Rust preflight review — REJECT

Sprint: `EFFECT-PERMISSION-OWNER-CERTIFICATE/20261030-R27`  
Contract SHA-256: `2cc9c8ae08a6fcbf98f237e6a1640ceb042a456a6beaadc448fa0a0308b431f0`  
Schema r2 SHA-256: `84187379d1a81b1965c34c027e7532198bebc4c4110eaa1c05808bada6bf6d8c`  
Inputs r3 SHA-256: `06fcdb4292b3364b9a40b75dcb9b57419ff0bfb50628d422cd5ec69ad0e5c6bc`  
Review identity: `/root/effect_permission_owner_certificate_r27_rust_preflight`  
Review window: 2026-10-29 21:39:06–21:41:17 UTC; conservatively charged 150 seconds.

## Verdict

**REJECT.** This limited exact-hash Rust pre-execution review authorizes no compile or runtime. The candidate JSON and mutation outcomes remain uncertified.

At review entry and exit, the candidate hashes matched:

- `machine.rs`: `c75a719580a032959693713f67db6ab73f7a8a0440855c409db6cbd94aa2566a`
- `receiving.rs`: `7a8eeab787f127064d5689b1ee5fbbfc409b4a307905d0f42d538f5d3d628f25`

The handoff, schema, input manifest, contract and amendment pins matched the supplied identities. The reviewer read source before relying on the handoff. The archived R1 source identities also matched.

## Blocking findings

### 1. The same replay boundary is required as both consumed and live

In `machine.rs` 3724–3728 and 4105–4107, the revised causal check requires the captured-root replay’s `OwnerReturn` to have been popped into the write request suffix, while the residual-stack check still requires an `OwnerReturn` in the remaining live stack. The fixture has no second enclosing resumption that could supply another live `OwnerReturn`.

The trace enters `receive` and `relay` through ordinary `ReceiverReturn` frames. The signal handler invokes its continuation once through `k 11`; template replay installs its sole `OwnerReturn`. The write then propagates outward to `receive`, popping that `OwnerReturn`, the continuation invocation boundary and the relay invocation boundary. When the outer write Catch is selected, the receive boundary and Catch remain live, while the replay boundary is in `forwarding_transitions`, not `consumer.frames`. `Frame::OwnerReturn` is constructed only by the Owner replay path at 2372, so the positive assertion at 4105 fails before mutation execution or receipt generation.

Required correction: authenticate the specific consumed replay boundary through the forwarding chain, and require only boundaries actually retained in the residual stack. Preserve complete boundary coverage across the combined forwarding and retained projections; do not remove the ownership check.

### 2. The unrelated-replay mutation requires a nonexistent second replay

In `machine.rs` 4204–4206, the mutation searches for a different replay occurrence and calls `.expect()` when absent. The approved companion has one continuation capture and one invocation. Its signal request is created after the native operation invocation returns (1698–1735, 1454–1463, 2934–2950, 3170–3194); that operation’s `ReceiverReturn` is already consumed before signal propagation. The suffix before relay’s Catch contains ordinary block/control and computation-view frames; relay’s invocation boundary lies below its Catch. `capture_template` constructs Bind/View nodes and one appended outer Owner (2210–2264), and `k 11` traverses that template once. There is exactly one Owner replay in `companion.owner_replay_evidence`.

Required correction: do not fabricate a second occurrence or silently skip the mutation. Use a genuinely observed distinct replay only if it exists in the approved source domain and execution envelope; otherwise mutate an existing causal link with an applicable, guarded target and require rejection. Do not claim second-replay substitution coverage.

## Other reviewed changes and remaining gate

The callback now selects `answer` while the companion selects `main`; the observation-only root lookup is `cfg(test)`; replay tags are attached at OwnerReturn push and removed on return/forwarding; pre-unwind transitions are event-filtered; ordered forwarding observations are separate from the template projection and retained stack. The reviewer found no production execution-decision change. The other existing mutations, wrong-event mutation and dropped-boundary mutation have identified targets/change and rejection paths.

These positive source observations do not establish test or mutation outcomes. After a future repaired-source ACCEPT and separate primary authorization, execution must still establish compilation, unchanged results `1`/`23`, actual target/change/rejection for every mutation, and a parsable certificate whose forwarding chain reaches the receiving consumer. No JSON was generated or certified here.

Unchecked Lean remains outstanding for the combined R27 contract but is not a dependency of this separated Rust source preflight. This rejection closes no source/native correspondence, parent theorem, soundness, principality, termination or production gate.

The review was read-only. No edits, Git, tests, Cargo/rustc, formatter, build, runtime, Lean/Lake/checker or descendants were run. Total review budget charged through R2 is 280/1,000 seconds; 720 seconds remain, reserving at least 400 seconds for later generated evidence review. Effective model/effort remains UNKNOWN.
