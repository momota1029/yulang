import YulangClosure.CallbackHygieneCorrespondence

/-!
R28 stage 1, constructed but unchecked. Source pin c9e315208cb04bcc4fe8c3595d929fb76538f1cd.
This finite observation projection does not define source typing or assert a
native simulation. receiving.rs CallbackResultSchema::from_parameter,
callback_entry, callback_entry_for_apply, callback_use, execution, observe,
local_grant and callback_grant are separate owners. machine.rs selects a direct
Parameter/Observe Name at Apply, opens the callback result execution and mints
the actual request before Catch selects its resolved operation and arm.

Site projection retains root/occurrence only. Byte spans are deliberately erased:
several native guards compare only those coordinates. No full-span identity
claim follows. Concrete effect IDs must be injectively encoded by the source
extractor; display names, row roots and result values are never identity keys.
The selected callback has no effect type arguments. General type arguments,
symbolic rows, RootComp, whole History, and original A/B remain OPEN.
-/
namespace YulangClosure.NativeCallbackGrantBridge
open CallbackHygieneCorrespondence

/-- Coordinates actually compared by the native guards; no byte-span theorem. -/
def siteKey (s : Site) : Site := ⟨s.root, s.occurrence, 0, 0⟩

def receiptKey (r : Receipt) : Receipt := {r with site := siteKey r.site}

structure NativeEntry where
  handle : Id .entry
  annotation : Annotation
  receiver : Id .invocation
  value : Id .payload
  incomingValue : Id .payload
  incomingView : Id .view
  view : Id .view
  formalReceipt : Receipt
  deriving DecidableEq, Repr

structure NativeName where
  entry : Id .entry
  resolvedFormal : Id .formal
  site : Site
  receipt : Receipt
  deriving DecidableEq, Repr

structure NativeUse where
  handle : Id .use
  entry : Id .entry
  sourceView : Id .view
  callee : Site
  apply : Site
  resultView : Id .view
  resultReceipt : Receipt
  deriving DecidableEq, Repr

def permission (e : NativeEntry) : Permission :=
  ⟨e.annotation.definition, e.annotation.binding, siteKey e.annotation.lambdaSite,
   e.annotation.formal, e.receiver, .callbackResult, e.annotation.families⟩

def entry (e : NativeEntry) : Entry :=
  ⟨e.handle, permission e, e.incomingView, e.view, e.value, receiptKey e.formalReceipt⟩

def name (n : NativeName) : NameRead :=
  ⟨n.entry, n.resolvedFormal, siteKey n.site, receiptKey n.receipt⟩

/-- Native Use has no stored owner or Name receipt. Those come from the actual
result receipt and direct-Name constructor, never a family-name comparison. -/
def callbackUse (e : NativeEntry) (n : NativeName) (u : NativeUse) : CallbackUse :=
  ⟨u.handle, u.entry, u.resultReceipt.owner, u.sourceView,
   e.formalReceipt.handle, n.receipt.handle, siteKey u.callee, siteKey u.apply,
   u.resultView, receiptKey u.resultReceipt⟩

/-- Aggregate of distinct constructor/store checks. In particular the Name
checks belong to callback_entry_for_apply, not callback_grant. Exact original
receipt slots are retained in the raw records; only their keys are compared. -/
def ConstructorChecks (e : NativeEntry) (n : NativeName) (u : NativeUse) : Prop :=
  e.value = e.incomingValue ∧
  e.formalReceipt.owner = e.receiver ∧
  e.formalReceipt.view = e.view ∧
  siteKey e.formalReceipt.site = siteKey e.annotation.lambdaSite ∧
  e.formalReceipt.formal = some e.annotation.formal ∧
  n.entry = e.handle ∧ n.resolvedFormal = e.annotation.formal ∧
  n.receipt.owner = e.receiver ∧ n.receipt.view = e.view ∧
  siteKey n.receipt.site = siteKey n.site ∧ n.receipt.formal = none ∧
  u.entry = e.handle ∧ u.resultReceipt.owner = e.receiver ∧
  u.sourceView = e.view ∧ siteKey u.callee = siteKey n.site ∧
  u.resultReceipt.view = u.resultView ∧
  siteKey u.resultReceipt.site = siteKey u.apply ∧ u.resultReceipt.formal = none

instance (e : NativeEntry) (n : NativeName) (u : NativeUse) :
    Decidable (ConstructorChecks e n u) := by unfold ConstructorChecks; infer_instance

def validateConstructors (e : NativeEntry) (n : NativeName) (u : NativeUse) : Bool :=
  decide (ConstructorChecks e n u)

/-- Generic success inversion; actual Rust extraction is a separate premise. -/
theorem constructor_success_use {e : NativeEntry} {n : NativeName} {u : NativeUse}
    (success : validateConstructors e n u = true) :
    UseReady (entry e) (name n) (callbackUse e n u) := by
  have checks : ConstructorChecks e n u := of_decide_eq_true success
  rcases checks with ⟨_, fo, fv, fs, ff, ne, nf, no, nv, ns, nn, ue, uo, uv, uc, rv, rs, rn⟩
  exact ⟨rfl, fo, fv, fs, ff, ne, nf, no, nv, ns, nn, ue, uo, uv,
    rfl, rfl, uc, rfl, rv, rs, rn⟩

structure NativeObservation where
  entryRecord : NativeEntry
  nameRecord : NativeName
  useRecord : NativeUse
  execution : Execution
  /- The owning Receiving.executions table, indexed by occurrence. -/
  executionTable : List (Id .view × Id .receipt)
  observer : Nat
  nextObserver : Nat
  observedEvent : Id .event
  request : Request
  deriving DecidableEq, Repr

def ExecutionChecks (b : NativeObservation) : Prop :=
  b.executionTable[b.execution.occurrence]? = some (b.execution.view, b.execution.receipt) ∧
  b.observer < b.nextObserver ∧ b.observedEvent = b.request.event ∧
  b.execution.useHandle = b.useRecord.handle ∧
  b.execution.view = b.useRecord.resultView ∧
  b.execution.receipt = b.useRecord.resultReceipt.handle ∧
  b.request.origin = .callback b.execution

instance (b : NativeObservation) : Decidable (ExecutionChecks b) := by
  unfold ExecutionChecks; infer_instance

def validateExecution (b : NativeObservation) : Bool := decide (ExecutionChecks b)

/-- A finite slice of supplied records. Membership here does not establish a
native execution history, annotation formation, liveness or actual emission. -/
def portSlice (b : NativeObservation) : State :=
  { entries := [entry b.entryRecord], names := [name b.nameRecord],
    uses := [callbackUse b.entryRecord b.nameRecord b.useRecord],
    executions := [b.execution] }

theorem constructor_success_port {b : NativeObservation}
    (constructors : validateConstructors b.entryRecord b.nameRecord b.useRecord = true)
    (execution : validateExecution b = true) :
    PortReady (portSlice b) b.request (permission b.entryRecord) := by
  have useReady := constructor_success_use constructors
  have checks : ExecutionChecks b := of_decide_eq_true execution
  rcases checks with ⟨_, _, _, handle, view, receipt, origin⟩
  apply Or.inl
  refine ⟨entry b.entryRecord, by simp [portSlice], name b.nameRecord,
    by simp [portSlice], callbackUse b.entryRecord b.nameRecord b.useRecord,
    by simp [portSlice], b.execution, by simp [portSlice], rfl, ?_, handle, view, receipt, origin⟩
  simp only [checkedUse, if_pos useReady]

/-- Catch records are separate from result values and callback permission. -/
structure NativeCatch where
  consumer : Consumer
  installed : InstalledCatch
  arm : Arm
  activeOwners : List (Id .invocation)
  pendingRequests : List Request
  emittedRequests : List Request
  deriving DecidableEq, Repr

def CatchChecks (b : NativeObservation) (c : NativeCatch) : Prop :=
  b.request ∈ c.pendingRequests ∧ b.request ∈ c.emittedRequests ∧
  c.consumer.owner ∈ c.activeOwners ∧ c.consumer.owner = b.entryRecord.receiver ∧
  b.request.operation.family ∈ b.entryRecord.annotation.families ∧
  c.consumer.operation = b.request.operation ∧ c.consumer.event = b.request.event ∧
  c.consumer.payload = b.request.payload ∧
  c.consumer.handler = c.installed.handle ∧
  siteKey c.consumer.catchSite = siteKey c.installed.site ∧
  c.consumer.owner = c.installed.owner ∧ c.arm ∈ c.installed.arms ∧
  c.consumer.arm = c.arm.handle ∧ siteKey c.consumer.armSite = siteKey c.arm.site ∧
  c.consumer.operation = c.arm.operation

instance (b : NativeObservation) (c : NativeCatch) : Decidable (CatchChecks b c) := by
  unfold CatchChecks; infer_instance

def validateCatch (b : NativeObservation) (c : NativeCatch) : Bool := decide (CatchChecks b c)
def consumerKey (c : Consumer) : Consumer :=
  {c with catchSite := siteKey c.catchSite, armSite := siteKey c.armSite}
def armKey (a : Arm) : Arm := {a with site := siteKey a.site}
def installedKey (h : InstalledCatch) : InstalledCatch :=
  {h with site := siteKey h.site, arms := h.arms.map armKey}
def catchSlice (b : NativeObservation) (c : NativeCatch) : State :=
  {portSlice b with permissions := [permission b.entryRecord],
   active := c.activeOwners, installed := [installedKey c.installed],
   pending := c.pendingRequests, emitted := c.emittedRequests}

theorem constructor_success_catch {b : NativeObservation} {c : NativeCatch}
    (constructors : validateConstructors b.entryRecord b.nameRecord b.useRecord = true)
    (execution : validateExecution b = true) (caught : validateCatch b c = true) :
    CatchReady (catchSlice b c) b.request (consumerKey c.consumer) (permission b.entryRecord) := by
  have port := constructor_success_port constructors execution
  have checks : CatchChecks b c := of_decide_eq_true caught
  rcases checks with ⟨pending, _, active, owner, family, operation, event, payload,
    handler, catchSite, installedOwner, armMember, arm, armSite, armOperation⟩
  refine ⟨pending, by simp [catchSlice], active, owner, family, ?_, operation, event,
    payload, installedKey c.installed, by simp [catchSlice], handler, catchSite,
    installedOwner, armKey c.arm, ?_, arm, armSite, armOperation⟩
  · exact port
  · exact List.mem_map.mpr ⟨c.arm, armMember, rfl⟩

/-- Publishing permission leaves actual inflow untouched, even in this slice. -/
theorem permission_does_not_emit (s : State) (p : Permission) :
    ({s with permissions := p :: s.permissions} : State).pending = s.pending ∧
    ({s with permissions := p :: s.permissions} : State).emitted = s.emitted := ⟨rfl, rfl⟩

/-!
Parent application: the generic implications supply R26's checked callback-use,
PortReady and (if actual Catch records pass their independent check) CatchReady
premises for the finite slice. No native Grant, UseReady, PortReady, History or
result-value premise is assumed. The checks still need an authenticated native
instance, including constructor provenance, resolved effect-ID injection, exact
source schema/polarity/no-type-argument formation, active-owner and live
observation provenance. A successful Boolean on arbitrary records is not that
instance. No theorem here asserts the Rust callback_grant/local_grant result.
First remaining premise/owner: Rust lane emits authenticated records at these
owners; Luna supplies frozen JSON plus a serialized Lean audit window. Whole
History and the original shared source strategy remain separate OPEN premises.
-/
end YulangClosure.NativeCallbackGrantBridge
